Help
----

* Edit "settings.ini" to modify the default settings.

* left button for putting piece, right button for removing piece.

* F2: new game. It will also change the side of the computer.

* F10: change the mode between 3D/2D.

* F11: after pressing F11, you will enter editing mode where the computer does not play for either side. You can quit editing mode by press F11 again.

* In 3D mode, you can use direction key to change viewpoint.


Kai Sun 2012

www.aiexp.info