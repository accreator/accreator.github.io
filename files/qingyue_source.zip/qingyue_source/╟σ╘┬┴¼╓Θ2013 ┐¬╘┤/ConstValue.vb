﻿Public Class ConstValue

    '组合棋型，与LT_Val顺序一一对应。
    Public Enum CombinationChessType
        LWin____________ = 0
        L60_50__________ = 1
        L42_4141_4132___ = 2
        L4131_4122______ = 3
        L41_____________ = 4
        L3232___________ = 5
        L3231_3222______ = 6
        L32_____________ = 7
        L3131_2222_3122_ = 8
        L31_22__________ = 9
        L21_____________ = 10
    End Enum

    Public Const LWin____________ = 40960
    Public Const L60_50__________ = 256
    Public Const L42_4141_4132___ = 384
    Public Const L4131_4122______ = 48
    Public Const L41_____________ = 24
    Public Const L3232___________ = 256
    Public Const L3231_3222______ = 32
    Public Const L32_____________ = 12
    Public Const L3131_2222_3122_ = 4
    Public Const L31_22__________ = 1
    Public Const L21_____________ = 0

    'wd=8,6050=7,42\4242\4142\4132=6,41=5,3232=4,32=3,3131\3122\2222=2,31\22=1
    Public Shared LT_Val() As Integer = New Integer() {LWin____________, _
                                                       L60_50__________, _
                                                       L42_4141_4132___, _
                                                       L4131_4122______, _
                                                       L41_____________, _
                                                       L3232___________, _
                                                       L3231_3222______, _
                                                       L32_____________, _
                                                       L3131_2222_3122_, _
                                                       L31_22__________, _
                                                       L21_____________}
    '最高分值
    Public Const MATE_VALUE As Integer = LWin____________ * 32
    'vcf路线中断
    Public Const VCFNFal As Integer = MATE_VALUE * 2
    '获胜值
    Public Const WIN_VALUE As Integer = LWin____________ * 4
    '内部迭代加深深度
    Public Const IID_DEPTH As Integer = 2
    '最大搜索深度
    Public Shared LIMIT_DEPTH As Integer = 12
    '最大VCT,VCF深度
    Public Shared LIMIT_DEPTH_VCS As Integer = 64
    '置换表项标记
    Public Enum HASHType As Byte
        HASH_ALPHA = 0      'ALPHA节点的置换表项
        HASH_BETA = 1       'BETA节点的置换表项
        HASH_PV = 2         'PV节点的置换表项
    End Enum

    '置换表大小
    Public Shared HASH_SIZE As Integer = 1 << 20
    '置换表\开局库项未找到标记
    Public Const NFAL_VALUE As Integer = MATE_VALUE * 16
    '超时时间
    Public Shared OutTimePVS As Integer = 3000
    Public Shared OutTimeVCS As Integer = 5000
    Public Shared OutTimePVSOB As Integer = 9000
    Public Shared OutTimeVCSOB As Integer = 15000
    '搜索类型
    Enum SearchType
        PVS = 2
        VCT = 1
        VCF = 0
    End Enum

    '保存走法类型的位置（不得小于8）
    Public Const cpTypeMoveLen As Integer = 8
    '适合于走法类型保存位置的类型掩码
    Public Const cpTypeMask As Integer = &HFF00
    '适合于走法类型保存位置的走法掩码
    Public Const cpPointMask As Integer = &HFF

End Class
