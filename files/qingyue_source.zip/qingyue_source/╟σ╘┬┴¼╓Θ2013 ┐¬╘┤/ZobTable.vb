﻿Public Class ZobTable
    Public Shared ReadWriteLock As New System.Threading.ReaderWriterLock()
    '置换表项结构
    Private Structure mPosZobItem
        Public dwLock0 As Integer               '锁
        Public ucFlag As ConstValue.HASHType    '节点类型
        Public ucDepth As Byte                  '深度
        Public nDistance As Byte                '当前局面步数
        Public wmv As Integer                   '招法
        Public svl As Integer                   '分值
        Public dwLock1 As Integer               '锁
    End Structure
    '置换表
    Private Shared hstb(ConstValue.HASH_SIZE)() As mPosZobItem
    Public Shared save, load As Integer

    Sub New()
        Dim i As Integer
        '初始化置换表
        For i = 0 To ConstValue.HASH_SIZE
            ReDim hstb(i)(1)
            hstb(i)(0) = New mPosZobItem
            hstb(i)(1) = New mPosZobItem
        Next
    End Sub

    Public Shared Sub Clear()
        Dim i As Integer
        For i = 0 To ConstValue.HASH_SIZE
            hstb(i)(0).dwLock0 = 0
            hstb(i)(1).dwLock0 = 0
        Next
    End Sub
    '提取置换表项。
    Public Shared Function ProbeHash(ByVal curkey As Zobrist.PosKey, ByVal vlAlpha As Integer, ByVal vlBeta As Integer, ByVal nDepth As Integer, ByRef mv As Byte) As Integer
        ReadWriteLock.AcquireReaderLock(System.Threading.Timeout.Infinite)
        '杀棋标志：如果是杀棋，那么不需要满足深度条件
        Dim bMate As Boolean, hsh As mPosZobItem, idx As Integer = curkey.key And (ConstValue.HASH_SIZE - 1)
        hsh = hstb(idx)(0)                                  '获取置换表深度优先项
        If (hsh.dwLock0 <> curkey.dwLock0) OrElse (hsh.dwLock1 <> curkey.dwLock1) Then      '若深度项不符合则
            hsh = hstb(idx)(1)                              '获取置换表实时优先项
            If (hsh.dwLock0 <> curkey.dwLock0) OrElse (hsh.dwLock1 <> curkey.dwLock1) Then  '若实时项也不符合则未找到
                mv = &HFF
                ReadWriteLock.ReleaseReaderLock() ' 释放读取锁定。 
                Return -ConstValue.NFAL_VALUE
            End If
        End If
        load += 1
        mv = hsh.wmv
        bMate = False
        If hsh.svl > ConstValue.WIN_VALUE Then             '当前玩家胜利
            hsh.svl -= hsh.nDistance        '提取时恢复杀棋步
            bMate = True
        ElseIf hsh.svl < -ConstValue.WIN_VALUE Then        '对方胜利
            hsh.svl += hsh.nDistance
            bMate = True
        End If
        If (hsh.ucDepth >= nDepth) OrElse bMate Then
            If hsh.ucFlag = ConstValue.HASHType.HASH_BETA Then             'BETA截断时，要超出边界。
                ReadWriteLock.ReleaseReaderLock() ' 释放读取锁定。 
                Return IIf(hsh.svl >= vlBeta, hsh.svl, -ConstValue.MATE_VALUE)
            ElseIf (hsh.ucFlag = ConstValue.HASHType.HASH_ALPHA) Then      'ALPHA截断时，要在边界之内。
                ReadWriteLock.ReleaseReaderLock() ' 释放读取锁定。 
                Return IIf(hsh.svl <= vlAlpha, hsh.svl, -ConstValue.MATE_VALUE)
            End If
            ReadWriteLock.ReleaseReaderLock() ' 释放读取锁定。 
            Return hsh.svl
        End If
        '找到了，但是深度更小，这时没有意义。
        ReadWriteLock.ReleaseReaderLock() ' 释放读取锁定。 
        Return -ConstValue.NFAL_VALUE
    End Function

    '保存置换表项
    Public Shared Sub RecordHash(ByVal curkey As Zobrist.PosKey, ByVal nFlag As Integer, ByVal vl As Integer, ByVal nDepth As Integer, ByVal nDistance As Integer, ByVal mv As Byte)
        ReadWriteLock.AcquireWriterLock(System.Threading.Timeout.Infinite)
        Try
            save += 1
            Dim hsh As mPosZobItem, index As Integer, idx As Integer = curkey.key And (ConstValue.HASH_SIZE - 1)
            hsh = hstb(idx)(0)      '获取深度优先项
            If nDepth >= hsh.ucDepth Then                               '若深度大于等于深度优先项
                hstb(idx)(1) = hstb(idx)(0)                             '将深度优先项移动到实时项，更新时更新深度优先项
                index = 0
            Else                                                        '若深度小于深度优先项
                hsh = hstb(idx)(1)  '更新时更新实时项
                index = 1
            End If
            hsh.ucFlag = nFlag
            hsh.ucDepth = nDepth
            hsh.nDistance = nDistance
            If vl > ConstValue.WIN_VALUE Then
                hsh.svl = vl + nDistance        '存储时用杀棋步影响分值，从而使得覆盖过程可以存储到更快的杀棋。
            ElseIf vl < -ConstValue.WIN_VALUE Then
                hsh.svl = vl - nDistance
            Else
                hsh.svl = vl
            End If
            hsh.wmv = mv
            hsh.dwLock0 = curkey.dwLock0
            hsh.dwLock1 = curkey.dwLock1
            hstb(idx)(index) = hsh
        Finally
            ReadWriteLock.ReleaseWriterLock() ' 释放写入锁定。 
        End Try
    End Sub

End Class

Public Class Zobrist

    Public Structure PosKey
        Public key As Integer                   '用以计算存储位置的键
        Public dwLock0 As Integer               '锁
        Public dwLock1 As Integer
        Public Overrides Function ToString() As String
            Return "key " & Hex(key) & " dwLock0 " & Hex(dwLock0) & " dwLock1 " & Hex(dwLock1)
        End Function
        Public Function Clone() As PosKey
            Dim ret As New PosKey
            ret.key = Me.key
            ret.dwLock0 = Me.dwLock0
            ret.dwLock1 = Me.dwLock1
            Return ret
        End Function
    End Structure

    '密匙流
    Private Shared keytable(1)() As PosKey

    Sub New()
        '初始化密匙流
        ReDim keytable(0)(239)
        ReDim keytable(1)(239)
        Dim md5 As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim arr As Byte()
        Dim i As Integer
        For i = 0 To 239
            arr = md5.ComputeHash(New Byte() {0, i})
            keytable(0)(i).key = BitConverter.ToInt32(arr, 0)
            keytable(0)(i).dwLock0 = BitConverter.ToInt32(arr, 4)
            keytable(0)(i).dwLock1 = BitConverter.ToInt32(arr, 8)
            arr = md5.ComputeHash(New Byte() {1, i})
            keytable(1)(i).key = BitConverter.ToInt32(arr, 0)
            keytable(1)(i).dwLock0 = BitConverter.ToInt32(arr, 4)
            keytable(1)(i).dwLock1 = BitConverter.ToInt32(arr, 8)
        Next
    End Sub

    Public Sub SetPlayer(ByRef curkey As PosKey, player As Integer, point As Integer)
        curkey.key = curkey.key Xor keytable(player)(point).key
        curkey.dwLock0 = curkey.dwLock0 Xor keytable(player)(point).dwLock0
        curkey.dwLock1 = curkey.dwLock1 Xor keytable(player)(point).dwLock1
        'Return curkey
    End Sub

End Class
