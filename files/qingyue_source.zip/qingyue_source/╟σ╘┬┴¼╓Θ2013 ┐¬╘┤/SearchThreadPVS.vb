﻿Imports System.Threading
Public Class SearchThreadPVS
    Public pos As Position             '局面
    Public pvLine As PVLine             '走法路线
    Public vl As Integer
    Public idxpvs As Integer            '搜索的局面计数
    Private th As Thread
    Private arEvent As AutoResetEvent
    Private depth As Integer
    Private rootmvs() As Integer
    Private rootover As Boolean

    Sub New(ByVal position As Position, ByVal are As AutoResetEvent, ByVal Priority As ThreadPriority, ByVal nDepth As Integer, ByVal searchMoves() As Integer)
        pos = position
        arEvent = are
        pvLine = New PVLine
        th = New Thread(AddressOf Start)
        th.Priority = Priority
        depth = nDepth
        rootmvs = searchMoves
    End Sub

    ReadOnly Property mvBest As Byte
        Get
            Return pos.mvResult
        End Get
    End Property

    Public Sub Work()
        th.Start()
    End Sub

    Private Sub Start()
        vl = AlphaBeta_PVSFull(-ConstValue.MATE_VALUE, ConstValue.MATE_VALUE, depth, pvLine)
        arEvent.Set() ' 通知线程运行结束。 
    End Sub

    '主要变例完全搜索过程
    Private Function AlphaBeta_PVSFull(ByVal vlAlpha As Integer, ByVal vlBeta As Integer, ByVal nDepth As Integer, ByVal pLine As PVLine) As Integer
        idxpvs += 1
        Dim line As New PVLine                  'pvs走法
        Dim nGenMove As Integer                 '子节点数
        Dim newDepth As Integer                 '选择性延伸的深度记数
        Dim vl, vlBest As Integer               '评价分值，最佳分值
        Dim mvs(225) As Integer                 '子节点走法缓存
        Dim mv, mvBest As Byte                  '当前走法，最佳走法
        Dim nHashFlag As ConstValue.HASHType    '置换表标志
        Dim mvHash As Byte = &HFF               '哈希表走法

        '1、到达水平线，则返回局面评价。
        If nDepth <= 0 Then Return pos.Evaluate
        '2、查找置换表，应用剪裁。
        vl = ZobTable.ProbeHash(pos.curposkey, vlAlpha, vlBeta, nDepth, mvHash)
        If vl > -ConstValue.MATE_VALUE Then
            pos.mvResult = mvHash
            Return vl
        End If
        '3、到达极限深度，则返回局面评价
        If pos.nDistance = ConstValue.LIMIT_DEPTH Then Return pos.Evaluate

        '  pos.NullMove()
        '  vl = -AlphaBeta_PVSFull(-vlBeta, 1 - vlBeta, nDepth - 2 - 1, line)
        '  pos.UnNullMove()
        '  If (vl >= vlBeta) Then
        'Return vl
        '  End If

        '4、初始化最佳值和最佳走法
        mvBest = &HFF                                           '这样可以知道，是否搜索到了Beta走法或PV走法，以便保存到历史表
        nHashFlag = ConstValue.HASHType.HASH_ALPHA              '置换表标志项
        vlBest = -ConstValue.MATE_VALUE                         '这样可以知道，是否一个走法都没走过(杀棋)

        '5、内部迭代加深启发：当剩余深度大于2，置换表剪裁未发生时。
        If nDepth > ConstValue.IID_DEPTH AndAlso mvHash = &HFF Then
            vl = AlphaBeta_PVSFull(vlAlpha, vlBeta, nDepth / 2, line)
            If vl <= vlAlpha Then
                vl = AlphaBeta_PVSFull(-ConstValue.MATE_VALUE, vlBeta, nDepth / 2, line)
            End If
            If line.cmove > 0 Then mvHash = line.argmove(0)
        End If

        If pos.nDistance = 0 AndAlso rootover = False Then
            Array.Copy(rootmvs, 0, mvs, 0, rootmvs.Length)
            nGenMove = rootmvs.Length - 1
            rootover = True
        Else
            '6、生成走法
            pLine.back = pLine.cmove
            nGenMove = pos.NextPVSMove(mvs, mvHash, pLine)                '在pvs中当nGenMove为-1时，都是杀棋。
        End If

        '7、逐一走这些走法，并进行递归
        For i As Integer = 0 To nGenMove
            mv = mvs(i) And ConstValue.cpPointMask
            '8、冲棋延伸
            newDepth = IIf((mvs(i) And ConstValue.cpTypeMask) <> ConstValue.CombinationChessType.LWin____________, nDepth, nDepth - 1)
            pos.AddPiece(mv)            '下子
            '9、PVS
            If vlBest = -ConstValue.MATE_VALUE Then
                vl = -AlphaBeta_PVSFull(-vlBeta, -vlAlpha, newDepth, line)
            Else
                vl = -AlphaBeta_PVSFull(-vlAlpha - 1, -vlAlpha, newDepth, line)         '空窗探测
                If vl > vlAlpha AndAlso vl < vlBeta Then                                '<=alpha说明没有更好的棋，>=beta说明发生剪裁。
                    vl = -AlphaBeta_PVSFull(-vlBeta, -vlAlpha, newDepth, line)
                End If
            End If
            pos.RemovePiece(mv)         '撤销下子
            '10、进行Alpha-Beta大小判断和截断
            If (vl > vlBest) Then                               '找到最佳值(但不能确定是Alpha、PV还是Beta走法)
                vlBest = vl                                     '"vlBest"就是目前要返回的最佳值，可能超出Alpha-Beta边界
                If (vl >= vlBeta) Then                          '找到一个Beta走法
                    nHashFlag = ConstValue.HASHType.HASH_BETA
                    mvBest = mv                                 'Beta走法要保存到历史表
                    Exit For                                    'Beta cut-of
                End If
                If (vl > vlAlpha) Then                          '找到一个PV走法
                    nHashFlag = ConstValue.HASHType.HASH_PV
                    mvBest = mv                                 'PV走法要保存到置换表
                    vlAlpha = vl                                '缩小Alpha-Beta边界
                    pLine.argmove(0) = mvBest                   '记录最佳走法路径
                    Array.Copy(line.argmove, 0, pLine.argmove, 1, line.cmove + 1)   '加入后续走法
                    pLine.cmove = line.cmove + 1                '更新走法总数
                End If
            End If
        Next

        '11、如果是杀棋，就根据杀棋步数给出评价
        If vlBest = -ConstValue.MATE_VALUE Then
            Return pos.nDistance - ConstValue.MATE_VALUE
        End If

        If mvBest <> &HFF Then
            pos.mvResult = mvBest
            '12、记录到置换表
            ZobTable.RecordHash(pos.curposkey, nHashFlag, vlBest, nDepth, pos.nDistance, mvBest)
            If pos.killer1(pos.nDistance) <> &HFF Then pos.killer2(pos.nDistance) = pos.killer1(pos.nDistance)
            pos.killer1(pos.nDistance) = mvBest
        End If
        '13、返回最佳分值
        Return vlBest
    End Function
End Class
