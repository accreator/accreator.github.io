﻿Imports System.Threading
Public Class Search
    Public pos As Position              '局面
    Public pvLine As PVLine             '走法路线
    Public vcLine As PVLine
    Public pvWatch As Stopwatch         '计时器
    Public vcWatch As Stopwatch
    Public searPosCount As Integer            '搜索的局面计数
    Public Event SearchInfo(inf As String)

    Sub New()
        pos = New Position
        pvLine = New PVLine
        vcLine = New PVLine
        pvWatch = New Stopwatch
        vcWatch = New Stopwatch
    End Sub

    'PVS根节点搜索过程（多线程）
    Private Function AlphaBeta_PVSRootThreads(ByVal nDepth As Integer, ByVal pLine As PVLine) As Integer
        Dim nGenMove As Integer                 '子节点数
        Dim idx, vlBest As Integer              '评价分值，最佳分值
        Dim mvs(225) As Integer                 '子节点走法缓存
        Dim mvBest As Byte                      '当前走法，最佳走法
        Dim nHashFlag As ConstValue.HASHType    '置换表标志
        Dim mvHash As Byte = &HFF               '哈希表走法
        '1、到达水平线，则返回局面评价。
        If nDepth <= 0 Then Return pos.Evaluate

        '4、初始化最佳值和最佳走法
        mvBest = &HFF                                           '这样可以知道，是否搜索到了Beta走法或PV走法，以便保存到历史表
        nHashFlag = ConstValue.HASHType.HASH_ALPHA              '置换表标志项
        vlBest = -ConstValue.MATE_VALUE                         '这样可以知道，是否一个走法都没走过(杀棋)

        '6、生成走法
        nGenMove = pos.NextPVSMove(mvs, mvHash, pLine)                '在pvs中当nGenMove为-1时，都是杀棋。

        If nGenMove = 0 Then        '处理唯一走法。
            pos.mvResult = mvs(0) And ConstValue.cpPointMask
            pos.AddPiece(pos.mvResult)
            vlBest = -pos.Evaluate
            pos.RemovePiece(pos.mvResult)
        ElseIf nGenMove > 0 Then
            Dim sih As New SeaInsHelper
            Dim thsmvs()() As Integer = sih.MvsThread(mvs, nGenMove)
            Dim AsyncOpDones(thsmvs.Length - 1) As AutoResetEvent
            Dim sth(thsmvs.Length - 1) As SearchThreadPVS
            Dim i As Integer
            For i = 0 To thsmvs.Length - 1
                AsyncOpDones(i) = New AutoResetEvent(False)
                sth(i) = New SearchThreadPVS(pos.Clone, AsyncOpDones(i), ThreadPriority.AboveNormal, nDepth, thsmvs(i))
            Next

            For i = 0 To thsmvs.Length - 1
                sth(i).Work()
            Next
            AutoResetEvent.WaitAll(AsyncOpDones)
            For i = 0 To thsmvs.Length - 1
                'Debug.Print((sth(i).vl > vlBest) & "  " & sth(i).vl & " " & sth(i).pvLine.ToString)
                searPosCount += sth(i).idxpvs
                '10、进行Alpha-Beta大小判断和截断
                If sth(i).vl > vlBest Then
                    vlBest = sth(i).vl
                    idx = i
                End If
            Next
            Array.Copy(sth(idx).pos.killer1, pos.killer1, 240)
            Array.Copy(sth(idx).pos.killer2, pos.killer2, 240)
            pos.mvResult = sth(idx).mvBest And ConstValue.cpPointMask
            pvLine = sth(idx).pvLine
        End If

        '13、返回最佳分值
        Return vlBest
    End Function

    '主要变例完全搜索过程
    Private Function AlphaBeta_PVSFull(ByVal vlAlpha As Integer, ByVal vlBeta As Integer, ByVal nDepth As Integer, ByVal pLine As PVLine) As Integer
        searPosCount += 1
        Dim line As New PVLine                  'pvs走法
        Dim nGenMove As Integer                 '子节点数
        Dim newDepth As Integer                 '选择性延伸的深度记数
        Dim vl, vlBest As Integer               '评价分值，最佳分值
        Dim mvs(225) As Integer                 '子节点走法缓存
        Dim mv, mvBest As Byte                  '当前走法，最佳走法
        Dim nHashFlag As ConstValue.HASHType    '置换表标志
        Dim mvHash As Byte = &HFF               '哈希表走法

        '1、到达水平线，则返回局面评价。
        If nDepth <= 0 Then Return pos.Evaluate
        '2、查找置换表，应用剪裁。
        vl = ZobTable.ProbeHash(pos.curposkey, vlAlpha, vlBeta, nDepth, mvHash)
        If vl > -ConstValue.MATE_VALUE Then
            pos.mvResult = mvHash
            Return vl
        End If
        '3、到达极限深度，则返回局面评价
        If pos.nDistance = ConstValue.LIMIT_DEPTH Then Return pos.Evaluate

        '4、初始化最佳值和最佳走法
        mvBest = &HFF                                           '这样可以知道，是否搜索到了Beta走法或PV走法，以便保存到历史表
        nHashFlag = ConstValue.HASHType.HASH_ALPHA              '置换表标志项
        vlBest = -ConstValue.MATE_VALUE                         '这样可以知道，是否一个走法都没走过(杀棋)

        '5、内部迭代加深启发：当剩余深度大于2，置换表剪裁未发生时。
        If nDepth > ConstValue.IID_DEPTH AndAlso mvHash = &HFF Then
            vl = AlphaBeta_PVSFull(vlAlpha, vlBeta, nDepth / 2, line)
            If vl <= vlAlpha Then
                vl = AlphaBeta_PVSFull(-ConstValue.MATE_VALUE, vlBeta, nDepth / 2, line)
            End If
            If line.cmove > 0 Then mvHash = line.argmove(0)
        End If

        '6、生成走法
        pLine.back = pLine.cmove
        nGenMove = pos.NextPVSMove(mvs, mvHash, pLine)                '在pvs中当nGenMove为-1时，都是杀棋。
        '7、逐一走这些走法，并进行递归
        For i As Integer = 0 To nGenMove
            mv = mvs(i) And ConstValue.cpPointMask
            '8、冲棋延伸
            newDepth = IIf((mvs(i) And ConstValue.cpTypeMask) <> ConstValue.CombinationChessType.LWin____________, nDepth, nDepth - 1)
            pos.AddPiece(mv)            '下子
            '9、PVS
            If vlBest = -ConstValue.MATE_VALUE Then
                vl = -AlphaBeta_PVSFull(-vlBeta, -vlAlpha, newDepth, line)
            Else
                vl = -AlphaBeta_PVSFull(-vlAlpha - 1, -vlAlpha, newDepth, line)         '空窗探测
                If vl > vlAlpha AndAlso vl < vlBeta Then                                '<=alpha说明没有更好的棋，>=beta说明发生剪裁。
                    vl = -AlphaBeta_PVSFull(-vlBeta, -vlAlpha, newDepth, line)
                End If
            End If
            pos.RemovePiece(mv)         '撤销下子
            '10、进行Alpha-Beta大小判断和截断
            If (vl > vlBest) Then                               '找到最佳值(但不能确定是Alpha、PV还是Beta走法)
                vlBest = vl                                     '"vlBest"就是目前要返回的最佳值，可能超出Alpha-Beta边界
                If (vl >= vlBeta) Then                          '找到一个Beta走法
                    nHashFlag = ConstValue.HASHType.HASH_BETA
                    mvBest = mv                                 'Beta走法要保存到历史表
                    Exit For                                    'Beta cut-of
                End If
                If (vl > vlAlpha) Then                          '找到一个PV走法
                    nHashFlag = ConstValue.HASHType.HASH_PV
                    mvBest = mv                                 'PV走法要保存到置换表
                    vlAlpha = vl                                '缩小Alpha-Beta边界
                    pLine.argmove(0) = mvBest                   '记录最佳走法路径
                    Array.Copy(line.argmove, 0, pLine.argmove, 1, line.cmove + 1)   '加入后续走法
                    pLine.cmove = line.cmove + 1                '更新走法总数
                End If
            End If
        Next

        '11、如果是杀棋，就根据杀棋步数给出评价
        If vlBest = -ConstValue.MATE_VALUE Then
            Return pos.nDistance - ConstValue.MATE_VALUE
        End If

        If mvBest <> &HFF Then
            pos.mvResult = mvBest
            '12、记录到置换表
            ZobTable.RecordHash(pos.curposkey, nHashFlag, vlBest, nDepth, pos.nDistance, mvBest)
        End If
        '13、返回最佳分值
        Return vlBest
    End Function

    'VCF/VCT完全搜索过程
    Public Function AlphaBeta_VCSRoot(ByVal nDepth As Integer, ByVal pLine As PVLine, ByVal searchType As ConstValue.SearchType) As Integer
        searPosCount += 1
        Dim line As New PVLine                  'pvs走法
        Dim nGenMove As Integer                 '子节点数
        Dim vl, vlBest As Integer               '评价分值，最佳分值
        Dim mvs(225) As Integer                 '子节点走法缓存
        Dim mv, mvBest As Byte                  '当前走法，最佳走法
        Dim mvHash As Byte = &HFF               '哈希表走法

        '4、生成全部走法
        Select Case searchType
            Case ConstValue.SearchType.VCF
                nGenMove = pos.NextVCFMove(mvs, pos.aiPlayer)
            Case ConstValue.SearchType.VCT
                nGenMove = pos.NextVCTMove(mvs, pos.aiPlayer)
        End Select

        '5、初始化最佳值和最佳走法
        mvBest = &HFF                           '这样可以知道，是否搜索到了Beta走法或PV走法，以便保存到历史表
        If nGenMove = -1 Then vlBest = -ConstValue.VCFNFal Else vlBest = -ConstValue.MATE_VALUE '在vcs中当nGenMove为-1时，攻方无走法。为-2时是胜利局面。

        '6、逐一走这些走法，并进行递归
        For i As Integer = 0 To nGenMove
            mv = mvs(i) And ConstValue.cpPointMask
            pos.AddPiece(mv)
            'pvs
            If vlBest = -ConstValue.MATE_VALUE Then
                vl = -AlphaBeta_VCSFull(-ConstValue.MATE_VALUE, ConstValue.MATE_VALUE, nDepth - 1, line, searchType)
            Else
                vl = -AlphaBeta_VCSFull(-vlBest - 1, -vlBest, nDepth - 1, line, searchType)         '空窗探测
                If vl > vlBest Then                                '<=alpha说明没有更好的棋，>=beta说明发生剪裁。
                    vl = -AlphaBeta_VCSFull(-ConstValue.MATE_VALUE, -vlBest, nDepth - 1, line, searchType)
                End If
            End If
            pos.RemovePiece(mv)
            '8、进行Alpha-Beta大小判断和截断
            If (vl > vlBest) Then                               '找到最佳值(但不能确定是Alpha、PV还是Beta走法)
                vlBest = vl                                     '"vlBest"就是目前要返回的最佳值，可能超出Alpha-Beta边界
                mvBest = mv                                 'PV走法要保存到置换表
                pLine.argmove(0) = mvBest                   '记录最佳走法路径
                Array.Copy(line.argmove, 0, pLine.argmove, 1, line.cmove + 1)   '加入后续走法
                pLine.cmove = line.cmove + 1                '更新走法总数
            End If
        Next
        If mvBest <> &HFF Then
            pos.mvResult = mvBest
        End If

        '10、返回最佳分值.当进攻方走一个防守招法之后，没有进一步进攻路线，会返回一个必走走法，此时vlBest为mate_value。
        Return vlBest

    End Function

    'VCF/VCT完全搜索过程
    Public Function AlphaBeta_VCSFull(ByVal vlAlpha As Integer, ByVal vlBeta As Integer, ByVal nDepth As Integer, ByVal pLine As PVLine, ByVal searchType As ConstValue.SearchType) As Integer
        searPosCount += 1
        Dim line As New PVLine                  'pvs走法
        Dim nGenMove As Integer                 '子节点数
        Dim vl, vlBest As Integer               '评价分值，最佳分值
        Dim mvs(225) As Integer                 '子节点走法缓存
        Dim mv, mvBest As Byte                  '当前走法，最佳走法
        Dim mvHash As Byte = &HFF               '哈希表走法
        '1、到达水平线，则返回局面评价
        If nDepth <= 0 Then
            Return pos.Evaluate
        End If

        '2、查找置换表，应用剪裁。
        vl = ZobTable.ProbeHash(pos.curposkey, vlAlpha, vlBeta, nDepth, mvHash)
        If vl > -ConstValue.MATE_VALUE Then
            pos.mvResult = mvHash
            Return vl
        End If

        '3、到达极限深度，则返回局面评价
        If pos.nDistance = ConstValue.LIMIT_DEPTH_VCS Then Return pos.Evaluate

        '4、生成全部走法
        Select Case searchType
            Case ConstValue.SearchType.VCF
                nGenMove = pos.NextVCFMove(mvs, pos.aiPlayer)
            Case ConstValue.SearchType.VCT
                nGenMove = pos.NextVCTMove(mvs, pos.aiPlayer)
        End Select

        '5、初始化最佳值和最佳走法
        mvBest = &HFF                           '这样可以知道，是否搜索到了Beta走法或PV走法，以便保存到历史表
        If nGenMove = -1 Then vlBest = -ConstValue.VCFNFal Else vlBest = -ConstValue.MATE_VALUE '在vcs中当nGenMove为-1时，攻方无走法。为-2时是胜利局面。

        '6、逐一走这些走法，并进行递归
        For i As Integer = 0 To nGenMove
            mv = mvs(i) And ConstValue.cpPointMask
            pos.AddPiece(mv)
            '7、PVS
            If vlBest = -ConstValue.MATE_VALUE Then
                vl = -AlphaBeta_VCSFull(-vlBeta, -vlAlpha, nDepth - 1, line, searchType)
            Else
                vl = -AlphaBeta_VCSFull(-vlAlpha - 1, -vlAlpha, nDepth - 1, line, searchType)       '空窗探测
                If vl > vlAlpha AndAlso vl < vlBeta Then                                            '<=alpha说明没有更好的棋，>=beta说明发生剪裁。
                    vl = -AlphaBeta_VCSFull(-vlBeta, -vlAlpha, nDepth - 1, line, searchType)
                End If
            End If
            pos.RemovePiece(mv)
            '8、进行Alpha-Beta大小判断和截断
            If (vl > vlBest) Then                               '找到最佳值(但不能确定是Alpha、PV还是Beta走法)
                vlBest = vl                                     '"vlBest"就是目前要返回的最佳值，可能超出Alpha-Beta边界
                If (vl >= vlBeta) Then                          '找到一个Beta走法
                    mvBest = mv                                 'Beta走法要保存到历史表
                    Exit For                                    'Beta cut-of
                End If
                If (vl > vlAlpha) Then                          '找到一个PV走法
                    mvBest = mv                                 'PV走法要保存到置换表
                    vlAlpha = vl                                '缩小Alpha-Beta边界
                    pLine.argmove(0) = mvBest                   '记录最佳走法路径
                    Array.Copy(line.argmove, 0, pLine.argmove, 1, line.cmove + 1)   '加入后续走法
                    pLine.cmove = line.cmove + 1                '更新走法总数
                End If
            End If
        Next

        '9、如果是杀棋，根据步数给出评价。如果是beta截断，保存到置换表。
        If vlBest = -ConstValue.MATE_VALUE Then
            Return -ConstValue.MATE_VALUE
        End If

        If (vlBest > -ConstValue.VCFNFal) AndAlso (vl < ConstValue.VCFNFal) Then
            ZobTable.RecordHash(pos.curposkey, ConstValue.HASHType.HASH_BETA, vlBest, nDepth, pos.nDistance, mvBest)
        End If

        If mvBest <> &HFF Then
            pos.mvResult = mvBest
        End If
        '10、返回最佳分值
        Return vlBest
    End Function

    '===============================PV搜索===============================
    Function SearchPV(ByVal SearchType As ConstValue.SearchType, ByRef info As Integer, outTime As Integer) As Integer
        Dim LastDepthTime As Integer    '上一深度所耗时间
        Dim bctm As Integer             '过去的总时间
        Dim i, vl As Integer            '循环计数，分值
        searPosCount = 0
        pvLine.cmove = -1
        '迭代加深过程
        For i = 1 To ConstValue.LIMIT_DEPTH - 1
            Dim LastDepthPVSIdx As Integer = searPosCount
            pos.StartUp()
            pvWatch.Reset()
            pvWatch.Start()
            pvLine.back = pvLine.cmove
            pvLine.cmove = -1
            ZobTable.save = 0
            ZobTable.load = 0
            'vl = AlphaBeta_PVSFull(-ConstValue.MATE_VALUE, ConstValue.MATE_VALUE, i, vcLine)
            vl = AlphaBeta_PVSRootThreads(i, pvLine)
            pvWatch.Stop()
            LastDepthTime = pvWatch.ElapsedMilliseconds + 1  '本次运算所用时间
            bctm += LastDepthTime   '至今所用全部时间
            RaiseEvent SearchInfo("层" & i & " 耗时 " & LastDepthTime & "(ms) 最佳值 " & vl & vbCrLf & pvLine.ToString & vbCrLf & _
                        "扫描局面 " & searPosCount - LastDepthPVSIdx & " NPS " & (searPosCount - LastDepthPVSIdx) \ LastDepthTime & "k" & vbCrLf)
            '搜索到杀棋，就终止搜索
            If vl >= ConstValue.WIN_VALUE Then  '计算机胜利
                info = 1
                Exit For
            End If
            If vl <= -ConstValue.WIN_VALUE Then '玩家胜利
                info = 2
                Exit For
            End If
            If outTime < bctm Then
                info = 3
                Exit For
            End If
        Next
        RaiseEvent SearchInfo("总耗时 " & bctm & "(ms) 扫描局面 " & searPosCount & " 平均NPS " & searPosCount \ bctm & "k" & vbCrLf & "置换表保存次数 " & ZobTable.save & " 置换表命中次数 " & ZobTable.load & vbCrLf)
        Return pos.mvResult
    End Function

    '===============================VCT/VCF搜索===============================
    Function SearchVC(ByVal SearchType As ConstValue.SearchType, ByRef info As Integer, OutTime As Integer) As Integer
        Dim LastDepthTime As Integer
        Dim bctm As Integer
        Dim i, vl As Integer
        searPosCount = 0
        vcLine.cmove = -1
        '迭代加深过程
        For i = 1 To ConstValue.LIMIT_DEPTH_VCS - 1
            Dim LastDepthPVSIdx As Integer = searPosCount
            pos.StartUp()
            pvWatch.Reset()
            pvWatch.Start()
            vcLine.back = vcLine.cmove
            vcLine.cmove = -1
            ZobTable.save = 0
            ZobTable.load = 0
            vl = AlphaBeta_VCSRoot(i, vcLine, SearchType)
            '  vl = AlphaBeta_VCSFull(-ConstValue.MATE_VALUE, ConstValue.MATE_VALUE, i, vcLine, SearchType)
            pvWatch.Stop()
            LastDepthTime = pvWatch.ElapsedMilliseconds + 1  '本次运算所用时间
            bctm += LastDepthTime + 1   '至今所用全部时间
            RaiseEvent SearchInfo("层" & i & " 耗时 " & LastDepthTime & "(ms) 最佳值 " & vl & vbCrLf & vcLine.ToString & vbCrLf & _
                        "扫描局面 " & searPosCount - LastDepthPVSIdx & " NPS " & (searPosCount - LastDepthPVSIdx) \ LastDepthTime & "k" & vbCrLf)
            '搜索到路径中断、杀棋，就终止搜索
            If vl = -ConstValue.VCFNFal OrElse vl = ConstValue.MATE_VALUE Then
                info = 1
                Exit For
            End If
            If vl >= ConstValue.WIN_VALUE Then  '计算机胜利或者必堵走法
                info = 2
                Exit For
            End If
            If vl <= -ConstValue.WIN_VALUE Then '玩家胜利
                info = 3
                Exit For
            End If
            If OutTime < bctm Then
                info = 4
                Exit For
            End If
        Next
        RaiseEvent SearchInfo("总耗时 " & bctm & "(ms) 扫描局面 " & searPosCount & " 平均NPS " & searPosCount \ bctm & "k" & vbCrLf & "置换表保存次数 " & ZobTable.save & " 置换表命中次数 " & ZobTable.load & vbCrLf)
        Return pos.mvResult
    End Function

End Class

Public Class PVLine
    Public cmove As Integer = -1        '路线中着法的数量
    Public argmove(239) As Byte     '路线上的着法列表
    Public back As Integer

    Public Overrides Function ToString() As String
        Dim tmp As String = String.Empty
        Dim i As Integer, chroffset As Integer = Asc("A")
        For i = 0 To cmove
            tmp &= Chr((argmove(i) And &HF) + chroffset) & (15 - (argmove(i) >> 4)) & " "
        Next
        Return tmp
    End Function

    Public Function ToStringByBack() As String
        Dim tmp As String = cmove & " "  ' String.Empty
        Dim i As Integer, chroffset As Integer = Asc("A")
        For i = 0 To back - 1
            tmp &= Chr((argmove(i) And &HF) + chroffset) & (15 - (argmove(i) >> 4)) & " "
        Next
        Return tmp
    End Function

    Public Function Clone() As PVLine
        Dim ret As New PVLine
        ret.cmove = Me.cmove
        If ret.cmove > -1 Then Array.Copy(Me.argmove, 0, ret.argmove, 0, ret.cmove + 1)
        Return ret
    End Function

End Class