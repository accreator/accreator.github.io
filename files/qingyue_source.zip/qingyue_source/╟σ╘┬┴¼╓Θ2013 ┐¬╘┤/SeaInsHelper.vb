﻿Public Class SeaInsHelper
    Private Declare Sub GetSystemInfo Lib "kernel32" (ByRef lpSystemInfo As SYSTEM_INFO)
    Private Structure SYSTEM_INFO
        Dim dwOemID As Integer
        Dim dwPageSize As Integer
        Dim lpMinimumApplicationAddress As Integer
        Dim lpMaximumApplicationAddress As Integer
        Dim dwActiveProcessorMask As Integer
        Dim dwNumberOrfProcessors As Integer
        Dim dwProcessorType As Integer
        Dim dwAllocationGranularity As Integer
        Dim dwReserved As Integer
    End Structure

    Private CoreCount As Integer

    Sub New()
        Dim inf As New SYSTEM_INFO
        GetSystemInfo(inf)
        CoreCount = inf.dwNumberOrfProcessors
    End Sub

    Function MvsThread(ByVal mvs() As Integer, ByVal nGenMove As Integer) As Integer()()
        Dim maxidx As Integer
        If nGenMove < CoreCount Then
            maxidx = nGenMove
        Else
            maxidx = CoreCount - 1
        End If
        Dim ret(maxidx)() As Integer
        Dim n As Integer = nGenMove + 1
        Dim m As Integer
        Dim i As Integer
        Dim idx As Integer
        If n Mod CoreCount = 0 Then
            m = n \ CoreCount
        Else
            m = n \ CoreCount + 1
        End If
        For i = 0 To n - m - 1 Step m
            ReDim ret(idx)(m - 1)
            Array.Copy(mvs, i, ret(idx), 0, m)
            idx += 1
        Next
        ReDim ret(idx)(n - i - 1)
        Array.Copy(mvs, i, ret(idx), 0, n - i)
        Return ret
    End Function

End Class
