﻿
Imports System.Windows.Forms
Imports System.Drawing
Imports System.Runtime.InteropServices

Public Class frmHero
    '黑白棋子
    Private bb As Bitmap
    Private bw As Bitmap
    '棋子偏移
    Private co As Point = New Point(5, 5)
    '棋子大小
    Private cs As Size = New Size(25, 25)
    '棋子文字字体
    Private fnt As Font = New Font("宋体", 10)
    '棋盘前景
    Private curimg As Bitmap = New Bitmap(My.Resources.board.Width, My.Resources.board.Height)
    '下子记录
    Private lstpipe As New List(Of Byte)
    '显示棋盘记录
    Private showbit As Boolean = False
    '线程
    Private th As Threading.Thread
    '引擎
    Private WithEvents search As New Search
    '开局库
    Private WithEvents OpenBook As OpeningBook

    Private Sub frmhero_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CreateObject("InternetExplorer.Application").Navigate("http://vbdevelopers.org")
        'Dim adth As Threading.Thread
        'Dim adstr As String
        'Private Sub frmAd_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Shell("explorer http://vbdevelopers.org/forum.php")
        'adth = New Threading.Thread(AddressOf addown)
        'adth.Start()
        'End Sub

        'Private Sub addown()
        'Dim myWebclient As Net.WebClient
        'Dim remoteUri As String = "http://vbdevelopers.org/ad/adtop/ad_pagetop.txt"
        'myWebclient = New Net.WebClient()
        'adstr = myWebclient.DownloadString(New Uri(remoteUri))
        'End Sub
        OpenBook = New OpeningBook
        Dim si As New SeaInsHelper
        '初始化棋盘位图
        pnlBoard.BackgroundImage = My.Resources.board
        '初始化棋子
        Dim resbmp As Bitmap = New Bitmap(My.Resources.pipe, cs.Width * 4, cs.Height)
        Dim allbmp As Bitmap = New Bitmap(resbmp.Width \ 2, resbmp.Height)
        For y As Integer = 0 To allbmp.Height - 1
            For x As Integer = 0 To allbmp.Width - 1
                If resbmp.GetPixel(x + allbmp.Width, y).ToArgb = Color.Black.ToArgb Then allbmp.SetPixel(x, y, resbmp.GetPixel(x, y))
            Next
        Next
        bb = allbmp.Clone(New Rectangle(0, 0, allbmp.Width / 2, allbmp.Height), allbmp.PixelFormat)
        bw = allbmp.Clone(New Rectangle(allbmp.Width / 2, 0, allbmp.Width / 2, allbmp.Height), allbmp.PixelFormat)
        '关闭线程提示
        Control.CheckForIllegalCrossThreadCalls = False
        '标题
        Me.Text = My.Application.Info.ProductName
#If DEBUG Then
        Me.TopMost = False
#Else
        Me.TopMost = True
#End If
        th = New Threading.Thread(AddressOf OpenBook.ins)
        th.Start()
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        If th IsNot Nothing Then th.Abort()
    End Sub
    '绘制棋子
    Private Sub pnlBoard_Paint(sender As System.Object, e As System.Windows.Forms.PaintEventArgs) Handles pnlBoard.Paint
        Dim x, y As Integer
        Dim tpoint As Point
        Dim tbitmap As Bitmap
        Dim tbrush As Brush
        Dim stroffset As Point = New Point(0, 5)
        Dim i As Integer
        For i = 0 To lstpipe.Count - 1
            x = lstpipe(i) And &HF
            y = (lstpipe(i) And &HF0) >> 4
            If (i Mod 2) = 0 Then
                tbitmap = bb
                tbrush = Brushes.White
            Else
                tbitmap = bw
                tbrush = Brushes.Black
            End If
            If i = lstpipe.Count - 1 Then tbrush = Brushes.Red
            tpoint = New Point(x * cs.Width, y * cs.Height) + co
            e.Graphics.DrawImage(tbitmap, tpoint)
            If i < 9 Then
                stroffset.X = 7
            ElseIf i < 99 Then
                stroffset.X = 3
            Else
                stroffset.X = 0
            End If
            e.Graphics.DrawString(i + 1, fnt, tbrush, tpoint + stroffset)
        Next
#If DEBUG Then
        For y = 0 To 14
            For x = 0 To 14
                If showbit Then
                    Dim btv As Integer, btvfh As Integer
                    Dim fnt As New Font("宋体", 12, FontStyle.Bold)
                    btv = int2ind(search.pos.cpTable(0)(y * 16 + x))
                    btvfh = IIf(btv < 0, -1, 1)
                    ' btv = btv And &H7FFFFFFF
                    e.Graphics.DrawString(((btv >> 0) And &HF) * btvfh, fnt, Brushes.White, New Point(x * cs.Width, y * cs.Height) + co + New Point(0, 0))
                    e.Graphics.DrawString(((btv >> 8) And &HF) * btvfh, fnt, Brushes.White, New Point(x * cs.Width, y * cs.Height) + co + New Point(14, 0))
                    e.Graphics.DrawString(((btv >> 16) And &HF) * btvfh, fnt, Brushes.White, New Point(x * cs.Width, y * cs.Height) + co + New Point(0, 14))
                    e.Graphics.DrawString(((btv >> 24) And &HF) * btvfh, fnt, Brushes.White, New Point(x * cs.Width, y * cs.Height) + co + New Point(14, 14))
                    btv = int2ind(search.pos.cpTable(1)(y * 16 + x))
                    btvfh = IIf(btv < 0, -1, 1)
                    '   btv = btv And &H7FFFFFFF
                    e.Graphics.DrawString(((btv >> 0) And &HF) * btvfh, fnt, Brushes.Green, New Point(x * cs.Width, y * cs.Height) + co + New Point(7, 7))
                    e.Graphics.DrawString(((btv >> 8) And &HF) * btvfh, fnt, Brushes.Green, New Point(x * cs.Width, y * cs.Height) + co + New Point(21, 7))
                    e.Graphics.DrawString(((btv >> 16) And &HF) * btvfh, fnt, Brushes.Green, New Point(x * cs.Width, y * cs.Height) + co + New Point(7, 21))
                    e.Graphics.DrawString(((btv >> 24) And &HF) * btvfh, fnt, Brushes.Green, New Point(x * cs.Width, y * cs.Height) + co + New Point(21, 21))
                End If
            Next
        Next
#End If


    End Sub

    Private Function int2ind(int As Integer) As Integer
        Dim retval As Integer, tmp As Integer
        Dim i, j As Integer
        For i = 0 To 3
            tmp = (int >> i) And &H1111111
            For j = 7 To 0 Step -1
                If (tmp >> j * 4) And 1 = 1 Then
                    retval = retval Or (j << i * 8)
                    Exit For
                End If
            Next
        Next
        Return retval Or (int And &H80000000)
    End Function

    '下子
    Private Sub pnlBoard_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles pnlBoard.MouseDown
        Dim sdr = CType(sender, Panel)
        Dim p As Point = e.Location - co
        p.X \= cs.Width
        p.Y \= cs.Height
        If e.Button = Windows.Forms.MouseButtons.Middle Then
            search.pos.RemovePiece(lstpipe(lstpipe.Count - 1))
            lstpipe.RemoveAt(lstpipe.Count - 1)
            pnlBoard.Invalidate()
        Else
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso (th Is Nothing OrElse th.IsAlive = False) Then
                Dim pb As Byte = p.Y * 16 + p.X
                If search.pos.IsEmptyPoint(pb) = 2 AndAlso search.pos.IsGemeOverPos = 2 Then
                    search.pos.AddPiece(pb)
                    lstpipe.Add(pb)
                    txtSearchFen.Text = lstPipe2Str()
                    txtSearchFen.SelectionStart = txtSearchFen.TextLength
                    pnlBoard.Invalidate()
                End If
            ElseIf e.Button = Windows.Forms.MouseButtons.Right AndAlso (th Is Nothing OrElse th.IsAlive = False) Then
                If search.pos.IsGemeOverPos = 2 Then
                    If search.pos.aiPlayer = 2 Then search.pos.aiPlayer = search.pos.sdPlayer
                    If search.pos.aiPlayer <> search.pos.sdPlayer Then
                        If MsgBox("按确定改为引擎执" & IIf(search.pos.aiPlayer = 0, "黑", "白"), vbYesNo, "轮到玩家走棋") = MsgBoxResult.Yes Then
                            search = New Search
                            txtSearchFen_KeyDown(Nothing, New KeyEventArgs(Keys.Enter))
                        Else
                            Return
                        End If
                    End If
                    txtInfo.Clear()
                    th = New Threading.Thread(AddressOf AIWork)
                    th.Start()
                End If
            End If
        End If
        search.pos.aiPlayer = search.pos.sdPlayer
    End Sub

    Private Sub AIWork()
        search.pos.aiPlayer = search.pos.sdPlayer   'AI
        Dim inf As Integer
        Dim obLst As List(Of Integer) = Nothing
        Dim vcsTime As Integer = ConstValue.OutTimeVCS
        Dim pvsTime As Integer = ConstValue.OutTimePVS
        '1、开局库搜索
        txtInfo.AppendText("扫描开局库……" & vbCrLf)
        If search.pos.sdPlayer = 1 Then
            inf = OpenBook.SearchAllSamePosition(lstpipe.ToArray)
            If (inf And OpeningBook.OutPos) = OpeningBook.OutPos Then '开局库搜索失败或处于黑方VCT/VCF中，不处理了。
                txtInfo.AppendText("开局库中无此局面。" & vbCrLf & vbCrLf)
                If lstpipe.Count > 3 Then
                    Dim lastList() As Byte = lstpipe.ToArray
                    ReDim Preserve lastList(lastList.Length - 3)
                    inf = OpenBook.SearchAllSamePosition(lastList)
                    If inf <> OpeningBook.OutPos Then '到达VCF/VCT
                        vcsTime = ConstValue.OutTimeVCSOB
                        pvsTime = ConstValue.OutTimePVSOB
                    End If
                End If
            Else                        '找到一般性招法。
                txtInfo.AppendText("开局库指示走法: " & point2str(inf) & vbCrLf)
                search.pos.mvResult = inf
                search.pos.AddPiece(search.pos.mvResult)
                lstpipe.Add(search.pos.mvResult)
                txtSearchFen.Text = lstPipe2Str()
                txtSearchFen.SelectionStart = txtSearchFen.TextLength
                pnlBoard.Invalidate()
                Return
            End If
        Else
            obLst = OpenBook.findall(lstpipe.ToArray)
            Dim i As Integer
            For i = 0 To obLst.Count - 1
                If (obLst(i) And OpeningBook.Best) = OpeningBook.Best Then
                    inf = obLst(i) >> 8
                    txtInfo.AppendText("开局库指示走法: " & inf & vbCrLf)
                    search.pos.mvResult = inf
                    search.pos.AddPiece(search.pos.mvResult)
                    lstpipe.Add(search.pos.mvResult)
                    txtSearchFen.Text = lstPipe2Str()
                    txtSearchFen.SelectionStart = txtSearchFen.TextLength
                    pnlBoard.Invalidate()
                    Return
                End If
            Next
            txtInfo.AppendText("开局库无大优走法。" & vbCrLf & vbCrLf)
        End If
        '2、vcf
        txtInfo.AppendText("启动VCF引擎……" & vbCrLf)
        search.pos.mvResult = search.SearchVC(ConstValue.SearchType.VCF, inf, vcsTime)
        If inf = 1 Then
            txtInfo.AppendText("VCF引擎返回进攻中断。" & vbCrLf & vbCrLf)
        ElseIf inf = 2 Then
            txtInfo.AppendText("VCF引擎返回搜索结果: " & vbCrLf & search.vcLine.ToString & vbCrLf)
            search.pos.AddPiece(search.pos.mvResult)
            lstpipe.Add(search.pos.mvResult)
            txtSearchFen.Text = lstPipe2Str()
            txtSearchFen.SelectionStart = txtSearchFen.TextLength
            pnlBoard.Invalidate()
            Return
        ElseIf inf = 3 Then
            txtInfo.AppendText("VCF引擎返回防守成功。" & vbCrLf & vbCrLf)
        Else
            txtInfo.AppendText("VCF引擎返回搜索超时。" & vbCrLf & vbCrLf)
        End If
        '3、vct
        txtInfo.AppendText("启动VCT引擎……" & vbCrLf)
        search.pos.mvResult = search.SearchVC(ConstValue.SearchType.VCT, inf, vcsTime)
        If inf = 1 Then
            txtInfo.AppendText("VCT引擎返回进攻中断。" & vbCrLf & vbCrLf)
        ElseIf inf = 2 Then
            txtInfo.AppendText("VCT引擎返回搜索结果: " & vbCrLf & search.vcLine.ToString & vbCrLf)
            search.pos.AddPiece(search.pos.mvResult)
            lstpipe.Add(search.pos.mvResult)
            txtSearchFen.Text = lstPipe2Str()
            txtSearchFen.SelectionStart = txtSearchFen.TextLength
            pnlBoard.Invalidate()
            Return
        ElseIf inf = 3 Then
            txtInfo.AppendText("VCT引擎返回防守成功。" & vbCrLf & vbCrLf)
        ElseIf inf = 4 Then
            txtInfo.AppendText("VCT引擎返回搜索超时。" & vbCrLf & vbCrLf)
        End If

        '4、pvs
        txtInfo.AppendText("启动PVS混合引擎……" & vbCrLf)
        search.pos.mvResult = search.SearchPV(ConstValue.SearchType.PVS, inf, pvsTime)
        If inf = 1 Then
            txtInfo.AppendText("PVS引擎返回电脑胜利: " & point2str(search.pos.mvResult))
        ElseIf inf = 2 Then
            txtInfo.AppendText("PVS引擎返回玩家胜利: " & point2str(search.pos.mvResult))
        ElseIf inf = 3 Then
            txtInfo.AppendText("PVS引擎返回搜索超时: " & point2str(search.pos.mvResult))
        End If
        search.pos.AddPiece(search.pos.mvResult)
        lstpipe.Add(search.pos.mvResult)
        txtSearchFen.Text = lstPipe2Str()
        txtSearchFen.SelectionStart = txtSearchFen.TextLength
        pnlBoard.Invalidate()
    End Sub

    Function point2str(p As Byte) As String
        Return Chr((p And &HF) + Asc("A")) & (15 - ((p And &HF0) >> 4))
    End Function

    Private Sub txtSearchFen_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles txtSearchFen.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.A Then
            txtSearchFen.SelectAll()
        End If
        If (e.KeyCode = Keys.Enter) AndAlso (th Is Nothing OrElse th.IsAlive = False) Then
            Dim i As Integer
            Dim str As String = txtSearchFen.Text.ToUpper.Replace(" ", String.Empty)
            search = New Search()
            If str.Length > 0 Then
                Dim tmpstr As String = String.Empty
                For i = 0 To str.Length - 2
                    tmpstr &= str(i)
                    If IsNumeric(str(i)) AndAlso Not IsNumeric(str(i + 1)) Then tmpstr &= " "
                    If Not IsNumeric(str(i)) AndAlso IsNumeric(str(i + 1)) Then tmpstr &= "|"
                Next
                tmpstr &= str(str.Length - 1)
                txtSearchFen.Text = tmpstr.Replace("|", String.Empty)
                txtSearchFen.SelectAll()
                Dim tmplst() As String = tmpstr.Replace("|", " ").Split(" ")
                If tmplst.Length Mod 2 = 1 Then
                    MsgBox("请检查输入坐标是否成对")
                    Return
                End If
                lstpipe.Clear()
                For i = 0 To tmplst.Length - 1 Step 2
                    Dim tmpx As Integer = Asc(tmplst(i)) - Asc("A")
                    Dim tmpy As Integer = CInt(tmplst(i + 1)) - 1
                    If tmpx < 0 OrElse tmpx > 15 OrElse tmpy < 0 OrElse tmpy > 15 Then
                        MsgBox("所输入字符" & txtSearchFen.Text & "中" & tmplst(i) & tmplst(i + 1) & "无法解析")
                        Return
                    End If
                    lstpipe.Add((14 - tmpy) * 16 + tmpx)
                Next
                txtSearchFen.SelectionStart = txtSearchFen.TextLength
                For i = 0 To lstpipe.Count - 1
                    search.pos.AddPiece(lstpipe(i))
                Next
                search.pos.aiPlayer = search.pos.sdPlayer
            Else
                lstpipe.Clear()
            End If
            pnlBoard.Invalidate()
        End If
    End Sub

    Private Function lstPipe2Str() As String
        Dim i As Integer, str As String = String.Empty, chroffset As Integer = Asc("A")
        For i = 0 To lstpipe.Count - 1
            str &= Chr((lstpipe(i) And &HF) + chroffset) & (15 - (lstpipe(i) >> 4)) & " "
        Next
        Return str
    End Function

    Private Sub txtSearchFen_MouseDoubleClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles txtSearchFen.MouseDoubleClick
        txtSearchFen.SelectAll()
    End Sub

    Private Sub OpenBook_OpenBookInfo(inf As String) Handles OpenBook.OpenBookInfo
        txtInfo.AppendText(inf & vbCrLf)
        txtInfo.Select(txtInfo.Text.Length, 0)
        txtInfo.ScrollToCaret()
    End Sub

    Private Sub search_SearchInfo(inf As String) Handles search.SearchInfo
        txtInfo.AppendText(inf & vbCrLf)
        txtInfo.Select(txtInfo.Text.Length, 0)
        txtInfo.ScrollToCaret()
    End Sub

End Class