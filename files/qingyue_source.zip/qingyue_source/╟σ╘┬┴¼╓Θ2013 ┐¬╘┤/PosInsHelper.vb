﻿''' <summary>
''' 初始化向量表、向量key、棋型模板
''' </summary>
''' <remarks></remarks>
Public Class PosInsHelper
    '→、↓、↙、↘四个方向上的向量起点坐标
    Private pStart()() As Integer = New Integer()() {New Integer() {&H0, &H10, &H20, &H30, &H40, &H50, &H60, &H70, &H80, &H90, &HA0, &HB0, &HC0, &HD0, &HE0}, _
                                                     New Integer() {&H0, &H1, &H2, &H3, &H4, &H5, &H6, &H7, &H8, &H9, &HA, &HB, &HC, &HD, &HE}, _
                                                     New Integer() {&H4, &H5, &H6, &H7, &H8, &H9, &HA, &HB, &HC, &HD, &HE, &H1E, &H2E, &H3E, &H4E, &H5E, &H6E, &H7E, &H8E, &H9E, &HAE}, _
                                                     New Integer() {&HA, &H9, &H8, &H7, &H6, &H5, &H4, &H3, &H2, &H1, &H0, &H10, &H20, &H30, &H40, &H50, &H60, &H70, &H80, &H90, &HA0}}
    '→、↓、↙、↘四个方向上的向量长度
    Private kLen()() As Integer = New Integer()() {New Integer() {&HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF}, _
                                                   New Integer() {&HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF, &HF}, _
                                                   New Integer() {&H5, &H6, &H7, &H8, &H9, &HA, &HB, &HC, &HD, &HE, &HF, &HE, &HD, &HC, &HB, &HA, &H9, &H8, &H7, &H6, &H5}, _
                                                   New Integer() {&H5, &H6, &H7, &H8, &H9, &HA, &HB, &HC, &HD, &HE, &HF, &HE, &HD, &HC, &HB, &HA, &H9, &H8, &H7, &H6, &H5}}
    '→、↓、↙、↘四个方向上的向量增量
    Private vDir() As Integer = New Integer() {&H1, &H10, &HF, &H11}

    '向量表
    Private vr(239)() As Integer     '下标为坐标。第二维个数为4（方向个数）。对应key=31-24,方向=23-16,距离终点=15-8,距离起点=7-0
    '各个向量的key
    Private vecKey(71) As Integer    '下标为行数。31-30空，每2位表示一个棋，11为空，10为黑，01为白即player+1（与模板表第一维下标一致）。



    '==========================================================以下为调用模块===============================================================
    Sub New()
        insVector()
        FullDmAllType()
    End Sub

    ''' <summary>
    ''' 坐标到向量信息转换表
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property VectorTeble As Integer()()
        Get
            Return vr
        End Get
    End Property

    ''' <summary>
    ''' 向量对应的初始key
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property VectorKey As Integer()
        Get
            Dim ret(71) As Integer
            Array.Copy(vecKey, ret, 72)
            Return ret
        End Get
    End Property

    ''' <summary>
    ''' 冲棋模板表
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property cpModTable As Byte()()
        Get
            Return dm
        End Get
    End Property

    ''' <summary>
    ''' 初始化向量表、向量key
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub insVector()
        Dim psvs(71)() As Byte
        Dim cnt As Integer
        Dim i, j, k As Integer
        '遍历按方向和起点遍历72向量
        For i = 0 To 3
            For j = 0 To pStart(i).Length - 1
                ReDim psvs(cnt)(kLen(i)(j) - 1)
                vecKey(cnt) = 2 ^ (kLen(i)(j) * 2) - 1          '获取向量对应的key初始值
                For k = 0 To kLen(i)(j) - 1
                    psvs(cnt)(k) = pStart(i)(j) + k * vDir(i)   '获取向量上的全部点
                Next
                cnt += 1
            Next
        Next
        '获取每个点对应的向量
        Dim point As Byte
        Dim tmpidx As Integer
        Dim tmp As Integer
        Dim x, y As Integer
        For x = 0 To 14             '外层循环用于生成坐标和控制cnt即psvs\veckey这种展开表的下标
            For y = 0 To 14
                cnt = 0
                point = x Or (y << 4)       '点坐标
                ReDim vr(point)(3)          '向量信息
                For i = 0 To 3              '内层循环用于控制按方向和起点顺序查询所有点数组
                    For j = 0 To pStart(i).Length - 1
                        tmpidx = Array.IndexOf(psvs(cnt), point)        '查询点所处位置
                        cnt += 1
                        If tmpidx > -1 Then
                            tmp = (cnt - 1) << 24                       '对应向量编号
                            tmp = tmp Or (vDir(i) << 16)                '方向
                            tmp = tmp Or (kLen(i)(j) - 1 - tmpidx << 8) '距离终点距离
                            tmp = tmp Or tmpidx                         '距离起点距离
                            vr(point)(i) = tmp
                            cnt += pStart(i).Length - j - 1             '退出循环时加入增量，使得cnt的值与循环正常结束时相同
                            Exit For
                        End If
                    Next
                Next
            Next
        Next
    End Sub

    Private Enum LinkType As Byte
        lemp = 0              '空点
        l21 = 1               '能形成冲2  
        l22 = 2               '能形成活2  
        l31 = 3               '能形成冲3
        l32 = 4               '能形成活3   
        l41 = 5               '能形成冲4   
        l42 = 6               '能形成活4
        l50 = 7               '能形成连5
        l60 = 8               '能形成长连
        lwin = 9              '胜利标志
        llng = 10             '长连标志
        lnll = 11             '有子标志
    End Enum

    '记录棋型对应冲棋值的模板表
    Private dm(163839)() As Byte    '下标与key对应。第二维个数为实际冲棋点个数。
    '某一长度对应的dm下标的范围，如长度1的模板都保存在64,65之间。
    Private keySpaceMin As Integer() = New Integer() {0, 64, 120, 224, 416, 768, 1408, 2560, 4608, 8192, 14336, 24576, 40960, 65536, 98304, 131072}
    Private keySpaceMax As Integer() = New Integer() {0, 65, 123, 231, 431, 799, 1471, 2687, 4863, 8703, 15359, 26623, 45055, 73727, 114687, 163839}
    '某一长度对应的将棋型长度信息从dm下标中去掉的掩码，例如5长度需要的掩码就是&H11111，亦即2^5-1。
    'Private keyMask As Integer() = New Integer() {0, 2 ^ 1 - 1, 2 ^ 2 - 1, 2 ^ 3 - 1, 2 ^ 4 - 1, 2 ^ 5 - 1, 2 ^ 6 - 1, 2 ^ 7 - 1, 2 ^ 8 - 1, 2 ^ 9 - 1, 2 ^ 10 - 1, 2 ^ 11 - 1, 2 ^ 12 - 1, 2 ^ 13 - 1, 2 ^ 14 - 1, 2 ^ 15 - 1}

    '此函数以idxkey为下标填充单方棋型表dm，并计算每个元素的byte()（以下均以cline表示dm的元素），使之能够表示对应的bitkey中的棋型类型。
    '其实现原理是：
    '0、遍历全部可能棋型，即无子、有子的全部组合（根据二进制特性，未采用递归而采用i++的方式来遍历），填充至dm。
    '1、根据定义：成五即连续5个本方子、长连即连续5个以上本方子修改dm使之能够查询成五、长连。
    '2、根据上面相同定义：扫描key中为0的点p，将0修改为1得到newkey，以newkey进行查询，若查询结果中cline(p)为lwin则原key对应的cline(p)为l50、为llng则为l60。
    '   这一步至关重要，实现了从五子棋定义到程序表示的转换，有了l50,l60表示之后，即可进行后续推断。
    '3、根据定义：有两个可以成l50(l60)的点的棋型就是42、一个的就是41。
    '   那么，形成42或41棋型时的点即l42或l41，亦即在p下子，形成2个l50(l60)点则p为l42、形成1个l50(l60)点则p为l41，否则转入下次推断。具体算法参考2。
    '4、根据定义：下一子形成42的棋型是32；下一子形成41的棋型是31。
    '   可以推断，在点p下一子，形成l42的点就是l32；形成l41的点就是l31。
    '5、根据4推断，在点p下一子，形成l32的就是l22；形成l31的就是l21。
    '至此，全部有意义棋型推断完毕。
    ''' <summary>
    ''' 枚举全部棋型并计算棋型冲棋值
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub FullDmAllType()
        '0、生成全部基本模型，即有子位置为lnl，其他均为0。其中1的点可能是lwin、lnll、llng，0的点可能是60、50、42、41、32、31、22、21（12,11和无意义点同论）。
        Dim i, j, len, bitkey, idxkey As Integer
        For len = 1 To 15                       '遍历所有长度
            'Debug.Print((17 - len) << (len + 1))   '输出模板下标下限
            For bitkey = 0 To 2 ^ len - 1       '遍历长度下的每一个数据。因为二进制恰好是两种情况，1代表有子，0代表无子。
                '1.1、由于0、1只能表示无子、有子两种情况，所以导致不同长度公用一个位置的情况存在，在key上同时记录长度即可解决这个问题。
                idxkey = bitkey Or ((17 - len) << (len + 1))
                If dm(idxkey) IsNot Nothing Then Throw New Exception("位置冲突避免算法错误，或重复调用填充函数")
                '1.2、定义保存数组，bitkey为1的位对应的cline设置为lnll。
                Dim cline(len - 1) As Byte
                For i = 0 To len - 1
                    If ((bitkey >> i) And 1) = 1 Then
                        cline(i) = LinkType.lnll
                    End If
                Next
                dm(idxkey) = cline
                'If (idxkey And keyMask(len)) <> bitkey Then Throw New Exception("key逆转换算法错误")
                If idxkey > keySpaceMax(len) OrElse idxkey < keySpaceMin(len) Then Throw New Exception("key空间算法错误")
            Next
            'Debug.Print(idxkey) '输出模板下标上限
        Next

        '1、根据定义：连续长度为5的棋型为成5，超过5的为长连。对key为1的点进行检测，若连接长度为5则修改为lwin，若为6则修改为llng。
        For len = 5 To 15                                           '遍历每个长度
            For idxkey = keySpaceMin(len) To keySpaceMax(len)     '长度内的元素，idxkey经过逆转换即可得到bitkey
                '2.1获取真实key
                Dim linkcount As Integer
                '2.2对真实key进行扫描，找到连接长度以决定是否使用新值
                For i = 0 To len - 1
                    linkcount = 1
                    If ((idxkey >> i) And 1) = 1 Then   '发现有子位
                        For j = i + 1 To len - 1        '向低位检测连接长度
                            If ((idxkey >> j) And 1) = 1 Then
                                linkcount += 1
                            Else
                                Exit For
                            End If
                        Next
                        For j = i - 1 To 0 Step -1       '向高位检测连接长度
                            If ((idxkey >> j) And 1) = 1 Then
                                linkcount += 1
                            Else
                                Exit For
                            End If
                        Next
                        If linkcount = 5 Then
                            dm(idxkey)(i) = LinkType.lwin
                        ElseIf linkcount > 5 Then
                            dm(idxkey)(i) = LinkType.llng
                        End If
                    End If
                Next
                If linkcount >= 5 Then
                    'Debug.Print(BitConverter.ToString(dm(idxkey)))
                End If
            Next
        Next

        '2、对key为0的点p进行检测，若修改为1后，cline(p)为lwin则修改为l50，为llng则修改为l60。
        For len = 5 To 15                                           '遍历每个长度
            For idxkey = keySpaceMin(len) To keySpaceMax(len)     '长度内的元素，idxkey经过逆转换即可得到bitkey
                '2.1遍历key中表示棋型的部分
                '  Dim ch As Boolean = False
                Dim cline() As Byte
                For i = 0 To len - 1
                    If ((idxkey >> i) And 1) = 0 Then   '发现空位
                        Dim findkey As Integer = idxkey Or (1 << i) '查询用key
                        cline = dm(findkey)
                        If cline(i) = LinkType.lwin Then
                            dm(idxkey)(i) = LinkType.l50
                            ' ch = True
                        ElseIf cline(i) = LinkType.llng Then
                            'ch = True
                            dm(idxkey)(i) = LinkType.l60
                        End If
                    End If
                Next
                'If ch Then Debug.Print(BitConverter.ToString(dm(idxkey)) & vbCrLf & BitConverter.ToString(cline) & vbCrLf)
            Next
        Next

        '3、检测l42,l41
        For len = 5 To 15                                         '遍历每个长度
            For idxkey = keySpaceMin(len) To keySpaceMax(len)     '长度内的元素，idxkey经过逆转换即可得到bitkey
                Dim cnt As Integer = 0
                Dim cntdm As Integer = 0
                Dim cline() As Byte
                For i = 0 To len - 1
                    If ((idxkey >> i) And 1) = 0 Then   '发现空位
                        Dim findkey As Integer = idxkey Or (1 << i) '查询用key
                        cline = dm(findkey)
                        cnt = 0
                        cntdm = 0
                        For j = 0 To len - 1    '遍历修改后的棋型，统计下子后和下子前的l50,l60个数
                            If ((cline(j) = LinkType.l50) OrElse (cline(j) = LinkType.l60)) Then cnt += 1
                            If ((dm(idxkey)(j) = LinkType.l50) OrElse (dm(idxkey)(j) = LinkType.l60)) Then cntdm += 1
                        Next
                        cnt -= cntdm        '取多出来的l50、l60以判别是l42还是l41
                        If cnt = 1 AndAlso dm(idxkey)(i) < LinkType.l41 Then '个数大于的同时，还要防止覆盖当前位置更高层判定
                            dm(idxkey)(i) = LinkType.l41
                        ElseIf cnt = 2 AndAlso dm(idxkey)(i) < LinkType.l42 Then
                            dm(idxkey)(i) = LinkType.l42
                        ElseIf cnt > 2 Then         '下一子最多多形成2个50或60点，不可能再多了。
                            Throw New Exception("42\41识别算法错误")
                        End If
                    End If
                Next
                'If cnt > 0 Then Debug.Print(BitConverter.ToString(dm(idxkey)) & vbCrLf & BitConverter.ToString(cline) & vbCrLf)
            Next
        Next

        '4、检测l32,l31
        For len = 5 To 15                                         '遍历每个长度
            For idxkey = keySpaceMin(len) To keySpaceMax(len)     '长度内的元素，idxkey经过逆转换即可得到bitkey
                Dim cnt32 As Integer
                Dim cntdm32 As Integer
                Dim cnt31 As Integer
                Dim cntdm31 As Integer
                Dim cline() As Byte
                For i = 0 To len - 1
                    If ((idxkey >> i) And 1) = 0 Then   '发现空位
                        Dim findkey As Integer = idxkey Or (1 << i) '查询用key
                        cline = dm(findkey)
                        cnt32 = 0
                        cntdm32 = 0
                        cnt31 = 0
                        cntdm31 = 0
                        For j = 0 To len - 1    '遍历修改后的棋型，统计双方的l42\l41个数
                            If cline(j) = LinkType.l42 Then cnt32 += 1
                            If cline(j) = LinkType.l41 Then cnt31 += 1
                            If dm(idxkey)(j) = LinkType.l42 Then cntdm32 += 1
                            If dm(idxkey)(j) = LinkType.l41 Then cntdm31 += 1
                        Next
                        cnt32 -= cntdm32        '取多出来的l42
                        cnt31 -= cntdm31        '取多出来的l41
                        '不能根据个数检测错误的存在（下一子最多可形成4个41或42），例如在8长度上就可以形成下一子形成4个41，而11长度上下一子可形成3个42。
                        '例如：0B-03-03-0B-03-00-00-0B的第四位，0B-0B-0B-05-05-04-0B-04-0B-00-00的第七位。
                        If cnt32 > 0 AndAlso dm(idxkey)(i) < LinkType.l32 Then
                            dm(idxkey)(i) = LinkType.l32
                        End If
                        If cnt31 > 0 AndAlso dm(idxkey)(i) < LinkType.l31 Then
                            dm(idxkey)(i) = LinkType.l31
                        End If
                    End If
                Next
                'If cnt32 > 0 orelse cnt32 > 0 Then Debug.Print("32 31" & vbCrLf & BitConverter.ToString(dm(idxkey)) & vbCrLf & BitConverter.ToString(cline) & vbCrLf)
            Next
        Next

        '5、检测l22,l21
        For len = 5 To 15                                         '遍历每个长度
            For idxkey = keySpaceMin(len) To keySpaceMax(len)     '长度内的元素，idxkey经过逆转换即可得到bitkey
                Dim cnt22 As Integer
                Dim cntdm22 As Integer
                Dim cnt21 As Integer
                Dim cntdm21 As Integer
                Dim cline() As Byte
                For i = 0 To len - 1
                    If ((idxkey >> i) And 1) = 0 Then   '发现空位
                        Dim findkey As Integer = idxkey Or (1 << i) '查询用key
                        cline = dm(findkey)
                        cnt22 = 0
                        cntdm22 = 0
                        cnt21 = 0
                        cntdm21 = 0
                        For j = 0 To len - 1    '遍历修改后的棋型，统计双方的l31\l32个数
                            If cline(j) = LinkType.l32 Then cnt22 += 1
                            If cline(j) = LinkType.l31 Then cnt21 += 1
                            If dm(idxkey)(j) = LinkType.l32 Then cntdm22 += 1
                            If dm(idxkey)(j) = LinkType.l31 Then cntdm21 += 1
                        Next
                        cnt22 -= cntdm22        '取多出来的l32
                        cnt21 -= cntdm21        '取多出来的l31
                        '同生成l32\l31一样，不能从个数判别算法是否正确。
                        If cnt22 > 0 AndAlso dm(idxkey)(i) < LinkType.l22 Then
                            dm(idxkey)(i) = LinkType.l22
                        End If
                        If cnt21 > 0 AndAlso dm(idxkey)(i) < LinkType.l21 Then
                            dm(idxkey)(i) = LinkType.l21
                        End If
                    End If
                Next
                'If cnt22 > 0 OrElse cnt21 > 0 Then Debug.Print("22 21" & vbCrLf & BitConverter.ToString(dm(idxkey)) & vbCrLf & BitConverter.ToString(cline) & vbCrLf)
            Next
        Next

        '至此，所有棋型类型分辨完成。其中包括了：
        'lemp = 0、l21 = 1、l22 = 2、l31 = 3、l32 = 4、l41 = 5、l42 = 6、l50 = 7、l60 = 8、lwin = 9、llng = 10、lnll = 11
        '但由于后续编写过程中，需要在32位以内存放所有棋型类型，所以将上述表示法压缩为：
        'lnll=7,lwin=6,l6050=5,l42=4,l41=3,l32=2,l3122=1,l21emp=0

        '6、棋型压缩表示
        For len = 1 To 15                                         '遍历每个长度
            For idxkey = keySpaceMin(len) To keySpaceMax(len)     '长度内的元素，idxkey经过逆转换即可得到bitkey
                Dim cline() As Byte = dm(idxkey)
                For i = 0 To len - 1
                    Select Case CType(cline(i), LinkType)
                        Case LinkType.lemp
                            cline(i) = 0
                        Case LinkType.l21
                            cline(i) = 1
                        Case LinkType.l31, LinkType.l22
                            cline(i) = 2
                        Case LinkType.l32
                            cline(i) = 3
                        Case LinkType.l41
                            cline(i) = 4
                        Case LinkType.l42
                            cline(i) = 5
                        Case LinkType.l50, LinkType.l60
                            cline(i) = 6
                        Case LinkType.lwin, LinkType.llng
                            cline(i) = 7
                        Case LinkType.lnll
                            cline(i) = 8
                    End Select
                Next
            Next
        Next
    End Sub


End Class
