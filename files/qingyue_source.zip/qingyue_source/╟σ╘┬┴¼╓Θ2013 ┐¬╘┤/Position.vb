﻿Public Class Position
    '负责初始化模板表、坐标向量对应表、向量key表的类。
    Private Shared posins As PosInsHelper
    '模板表
    Private Shared dm()() As Byte           '下标与key对应。第二维个数为实际冲棋点个数。nl=7,wd=6,6050=5,42=4,41=3,32=2,3122=1,21121100=0。
    '向量表
    Private Shared vr()() As Integer        '下标为坐标。第二维个数为4（方向个数）。对应key=31-24,方向=23-16,距离终点=15-8,距离起点=7-0
    '各个向量的key
    Private vecKey(71) As Integer            '下标为行数。31-30空，每2位表示一个棋，11为空，10为黑，01为白即player+1（与模板表第一维下标一致）。
    '局面哈希
    Private Shared zob As Zobrist
    '置换表
    Private Shared ht As ZobTable
    '局面key
    Public curposkey As Zobrist.PosKey
    '轮到谁走，0=白方，1=黑方
    Public sdPlayer As Byte
    'AI走的颜色
    Public aiPlayer As Byte
    '距离根节点的步数
    Public nDistance As Byte
    '电脑走的棋
    Public mvResult As Byte
    '各点的冲棋值表引用                                
    Public cpTable(1)() As Integer
    '冲棋点排序表
    Private cpSort(1)() As Integer           '0-7位为left节点，8-15位为right节点,16-19位为所属头类型
    '冲棋点排序表头
    Private cpSortHead(1)() As Integer       '下标为冲棋点类型，值0-7位为该类型的第一个点对应的cpSort元素编号，8-15位为该类型有多少个元素。
    '下子的影响量
    ' Private cpAddPice As New Dictionary(Of Zobrist.PosKey, List(Of Integer))
    Public killer1(239) As Byte
    Public killer2(239) As Byte

    Sub New()
        '初始化72向量对应的key。这些key按照4个5,、4个6、4个7……4个14、32个15长度的顺序排列（子序为方向）。
        If zob Is Nothing Then zob = New Zobrist
        If ht Is Nothing Then
            ht = New ZobTable
        Else
            ZobTable.Clear()
        End If
        If posins Is Nothing Then
            posins = New PosInsHelper
            dm = posins.cpModTable
            vr = posins.VectorTeble
        End If
        vecKey = posins.VectorKey
        curposkey = New Zobrist.PosKey
        Dim i As Integer
        '初始化冲棋值表
        ReDim cpTable(0)(239)
        ReDim cpTable(1)(239)
        '初始化冲棋排序表
        ReDim cpSort(0)(239)
        ReDim cpSort(1)(239)
        For i = 0 To 239
            cpSort(0)(i) = &HFFFFF
            cpSort(1)(i) = &HFFFFF
        Next
        '初始化冲棋排序表头
        ReDim cpSortHead(0)(ConstValue.CombinationChessType.L21_____________)
        ReDim cpSortHead(1)(ConstValue.CombinationChessType.L21_____________)
        For i = 0 To ConstValue.CombinationChessType.L21_____________
            cpSortHead(0)(i) = &HFF
            cpSortHead(1)(i) = &HFF
        Next
        For i = 0 To 239
            killer1(i) = &HFF
            killer2(i) = &HFF
        Next
        '初始化走棋方
        sdPlayer = 1
        aiPlayer = 2
        '初始化走法步数和最佳走法
        StartUp()
    End Sub

    Public Sub StartUp()
        nDistance = 0
        mvResult = &HFF
    End Sub

    Public Sub AddPiece(point As Byte)
        '初始化本次更新的冲棋表
        Dim i As Integer
        '取对应向量
        Dim vs() As Integer = vr(point)
        Dim vec, vkindex, dir, dend, dstart, newkey As Integer
        '更新key
        If cpTable(0)(point) < 0 OrElse cpTable(1)(point) < 0 Then Throw New Exception("当前位置有子")
        zob.SetPlayer(curposkey, sdPlayer, point)
        nDistance += 1
        cpTable(0)(point) = &H80000000     '加入有子标志
        cpTable(1)(point) = &H80000000
        '      chTable.Set(point, True)                               '记录有子点
        UpCpSortDate(&H80000000, point, 0)
        UpCpSortDate(&H80000000, point, 1)

        ' Dim curAdd As New List(Of Integer)
        'If Not cpAddPice.ContainsKey(curposkey) Then
        'cpAddPice.Add(curposkey, curAdd)
        ' End If

        For i = 0 To 3
            ' Debug.Print(i & " --------------------------- " & Hex(point))
            vec = vs(i)                                 '取得对应向量信息
            If vec <> 0 Then                            '若存在对应向量
                vkindex = (vec And &HFF000000) >> 24    '分离对应key编号
                dir = (vec And &HFF0000) >> 16          '分离对应方向
                dend = (vec And &HFF00) >> 8            '分离距离终点长度
                dstart = (vec And &HFF)                 '分离距离起点长度
                newkey = vecKey(vkindex) And (Not (3 << dstart * 2))    '获取key原值并清理当前位置原始值
                newkey = newkey Or ((sdPlayer + 1) << dstart * 2)       '在当前位置写入新值
                vecKey(vkindex) = newkey                                '更新key
                '由向量key分别向左右统计本方棋型（达到5才有意义），计算查表用key得到更新信息，然后更新冲棋值表。
                '同时要记录本方最低位棋子和最高位棋子分别作为对方向右的起位和向左的止位。
                '此时无论对方的长度为多少都需要给予更新
                '例如：11 11 01 01 01 11 11 11棋型变为11 11 01 01 01 10 11 11时，最后2位的冲棋信息要更新
                UpPlayerDate(newkey, dstart, dend, sdPlayer, point, i, dir) ', curAdd)
                'UpPlayerDate(newkey, tv And &HF, (tv >> 8) And &HF, 1 - player, point - (dstart - (tv And &HF)) * dir, i, dir)
                'UpPlayerDate(newkey, (tv >> 16) And &HF, (tv >> 24) And &HF, 1 - player, point + (((tv >> 16) And &HF) - dstart) * dir, i, dir)
            End If
        Next
        '最后，交换走棋方。
        sdPlayer = 1 - sdPlayer
    End Sub

    Public Sub RemovePiece(point As Byte)
        '初始化本次更新的冲棋表
        Dim i As Integer
        '取对应向量
        Dim vs() As Integer = vr(point)
        Dim vec, vkindex, dir, dend, dstart, newkey As Integer
        '更新key
        zob.SetPlayer(curposkey, 1 - sdPlayer, point)        '更新局面KEY
        nDistance -= 1                                                  '更新走棋步数
        cpTable(0)(point) = 0            '去掉有子标志
        cpTable(1)(point) = 0
        '    chTable.Set(point, False)                                       '消除有子记录
        For i = 0 To 3
            '    Debug.Print(i & " --------------------------- " & Hex(point))
            vec = vs(i)                                 '取得对应向量信息
            If vec <> 0 Then                            '若存在对应向量
                vkindex = (vec And &HFF000000) >> 24    '分离对应key编号
                dir = (vec And &HFF0000) >> 16          '分离对应方向
                dend = (vec And &HFF00) >> 8            '分离距离终点长度
                dstart = (vec And &HFF)                 '分离距离起点长度
                newkey = vecKey(vkindex) And (Not (3 << dstart * 2))    '获取key原值并清理当前位置原始值
                newkey = newkey Or (3 << dstart * 2)         '在当前位置写入新值
                vecKey(vkindex) = newkey                                '更新key
                '由向量key分别向左右统计双方棋型（达到5才有意义），计算查表用key得到更新信息，然后更新冲棋值表。
                UpEmptyDate(newkey, dstart, dend, 0, point, i, dir)
                UpEmptyDate(newkey, dstart, dend, 1, point, i, dir)
            End If
        Next
        '最后，交换走棋方。
        sdPlayer = 1 - sdPlayer
    End Sub

    Private Sub UpPlayerDate(Key As Integer, dstart As Integer, dend As Integer, player As Integer, point As Integer, kdiridx As Integer, kdir As Integer) ', curadd As List(Of Integer))
        Dim i As Integer
        Dim bitval As Integer           '当前2位上的key值
        Dim tmpkey As Integer           '用于查询冲棋值的key
        Dim spaceidx As Integer         '空格数/tmpkey当中的棋长度
        Dim mstart, mend As Integer     '己方棋型的起止位（向量实际坐标）
        Dim fmpoint As Integer          '最后一个次发现本方点的位置

        Dim vs As Byte()                '冲棋信息查询结果
        Dim pstart As Integer           '更新时棋盘上的实际起点坐标
        Dim tv As Integer               '查询结果中当前位的冲棋值
        Dim kdirmk As Integer           '当前方向上的冲棋值消除掩码

        If kdiridx = 0 Then
            kdirmk = &HFEEEEEEE
        ElseIf kdiridx = 1 Then
            kdirmk = &HFDDDDDDD
        ElseIf kdiridx = 2 Then
            kdirmk = &HFBBBBBBB
        ElseIf kdiridx = 3 Then
            kdirmk = &HF7777777
        End If

        tmpkey = 1 << dstart            '设置本位
        mstart = dstart                 '本方起点假定
        mend = dstart                   '本方终点假定

        '向低位（起点）
        fmpoint = dstart - 1
        For i = dstart - 1 To 0 Step -1
            bitval = (Key >> i * 2) And 3       '截取2位
            If bitval = player + 1 Then         '己方
                tmpkey = tmpkey Or (1 << i)     '设置key
                spaceidx = 0                    '记录空格
                mstart = i                      '当前发现的最后一个本方子位置
                fmpoint = i - 1                 '对方扫描起点
            ElseIf bitval = 3 Then              '空
                spaceidx += 1
                mstart = i
                If spaceidx = 5 Then            '空格达到5个
                    Exit For
                End If
            ElseIf bitval = 2 - player Then     '对方
                mstart = i + 1
                Exit For
            End If
        Next
        If fmpoint >= 0 Then UpLeftDate(Key, fmpoint, 1 - player, point - (dstart - fmpoint) * kdir, kdiridx, kdir)
        '向高位
        spaceidx = 0
        fmpoint = dstart + 1
        For i = dstart + 1 To dend + dstart
            bitval = (Key >> i * 2) And 3
            If bitval = player + 1 Then         '己方
                tmpkey = tmpkey Or (1 << i)
                spaceidx = 0
                mend = i
                fmpoint = i + 1
            ElseIf bitval = 3 Then              '空
                spaceidx += 1
                mend = i
                If spaceidx = 5 Then
                    Exit For
                End If
            ElseIf bitval = 2 - player Then     '对方
                mend = i - 1
                Exit For
            End If
        Next
        If fmpoint <= dend + dstart Then UpRightDate(Key, fmpoint, dend - fmpoint + dstart, 1 - player, point + (fmpoint - dstart) * kdir, kdiridx, kdir)

        'mstart,mend之间就是本方棋型了
        spaceidx = mend - mstart + 1    '长度
        If spaceidx >= 5 Then           '计算查询用key
            tmpkey = tmpkey >> mstart
            tmpkey = tmpkey Or ((17 - spaceidx) << (spaceidx + 1))
            '查询，更新
            vs = dm(tmpkey)   '查询当前key对应的冲棋信息
            '按冲棋信息更新棋盘点
            '冲棋信息0下标对应向量mstart位置，所以更新时冲棋值信息0下标对应棋盘点p-mstart*dir，随着冲棋值下标+1棋盘点步长为dir。
            pstart = point - (dstart - mstart) * kdir
            Dim tmppoint As Integer
            Dim tmpval As Integer
            For i = 0 To spaceidx - 1
                'nl=7,wd=6,6050=5,42=4,41=3,32=2,3122=1,21121100=0
                tmppoint = pstart + i * kdir
                tv = vs(i) - 1
                If tv = -1 Then
                    tmpval = cpTable(player)(tmppoint) And kdirmk
                    cpTable(player)(tmppoint) = tmpval
                    UpCpSortDate(tmpval, tmppoint, player)
                ElseIf tv > -1 AndAlso tv < 7 Then
                    tmpval = (1 << tv * 4 + kdiridx) Or (cpTable(player)(tmppoint) And kdirmk)
                    cpTable(player)(tmppoint) = tmpval
                    UpCpSortDate(tmpval, tmppoint, player)
                    'curadd.Add(cpSort(player)(tmppoint))
                End If
            Next
            '   Debug.Print("upplayer " & tmpstr & vbCrLf & "         " & tmpstrex)
        End If
    End Sub

    Private Sub UpLeftDate(Key As Integer, dstart As Integer, player As Integer, point As Integer, kdiridx As Integer, kdir As Integer)
        Dim i As Integer
        Dim bitval As Integer
        Dim tmpkey As Integer
        Dim spaceidx As Integer

        Dim mstart As Integer
        Dim vs As Byte()                '冲棋信息查询结果
        Dim pstart As Integer           '更新时棋盘上的实际起点坐标
        Dim tv As Integer               '查询结果中当前位的冲棋值
        Dim kdirmk As Integer           '当前方向上的冲棋值消除掩码

        If kdiridx = 0 Then
            kdirmk = &HFEEEEEEE
        ElseIf kdiridx = 1 Then
            kdirmk = &HFDDDDDDD
        ElseIf kdiridx = 2 Then
            kdirmk = &HFBBBBBBB
        ElseIf kdiridx = 3 Then
            kdirmk = &HF7777777
        End If

        mstart = dstart

        '根据对方扫描起点和空格个数，扫描对方棋型
        For i = dstart To 0 Step -1
            bitval = (Key >> i * 2) And 3       '截取2位
            If bitval = player + 1 Then         '己方
                tmpkey = tmpkey Or (1 << i)     '设置key
                spaceidx = 0
                mstart = i
            ElseIf bitval = 3 Then              '空
                spaceidx += 1
                mstart = i
                If spaceidx = 5 Then            '空格达到5个
                    Exit For
                End If
            ElseIf bitval = 2 - player Then     '对方
                mstart = i + 1
                Exit For
            End If
        Next
        '此时，mstart与dstart之间就是对方低位方向棋型
        '计算查询用key
        spaceidx = dstart - mstart + 1        '棋型长度
        tmpkey = tmpkey >> mstart
        tmpkey = tmpkey Or ((17 - spaceidx) << (spaceidx + 1))
        '查询
        vs = dm(tmpkey)
        '计算更新起点
        pstart = point - (dstart - mstart) * kdir
        Dim tmppoint As Integer
        Dim tmpval As Integer
        For i = 0 To spaceidx - 1
            tmppoint = pstart + i * kdir
            tv = vs(i) - 1
            If tv = -1 Then
                tmpval = cpTable(player)(tmppoint) And kdirmk
                cpTable(player)(tmppoint) = tmpval
                UpCpSortDate(tmpval, tmppoint, player)
            ElseIf tv > -1 AndAlso tv < 7 Then
                tmpval = (1 << tv * 4 + kdiridx) Or (cpTable(player)(tmppoint) And kdirmk)
                cpTable(player)(tmppoint) = tmpval
                UpCpSortDate(tmpval, tmppoint, player)
            End If
        Next
        '   Debug.Print("up left " & tmpstr & vbCrLf & "        " & tmpstrex)
    End Sub

    Private Sub UpRightDate(Key As Integer, dstart As Integer, dend As Integer, player As Integer, point As Integer, kdiridx As Integer, kdir As Integer)
        Dim i As Integer
        Dim bitval As Integer
        Dim tmpkey As Integer
        Dim spaceidx As Integer

        Dim mend As Integer
        Dim vs As Byte()                '冲棋信息查询结果
        Dim pstart As Integer           '更新时棋盘上的实际起点坐标
        Dim tv As Integer               '查询结果中当前位的冲棋值
        Dim kdirmk As Integer           '当前方向上的冲棋值消除掩码

        If kdiridx = 0 Then
            kdirmk = &HFEEEEEEE
        ElseIf kdiridx = 1 Then
            kdirmk = &HFDDDDDDD
        ElseIf kdiridx = 2 Then
            kdirmk = &HFBBBBBBB
        ElseIf kdiridx = 3 Then
            kdirmk = &HF7777777
        End If

        mend = dstart
        '根据对方扫描起点和空格个数，扫描对方棋型
        For i = dstart To dstart + dend
            bitval = (Key >> i * 2) And 3       '截取2位
            If bitval = player + 1 Then         '己方
                tmpkey = tmpkey Or (1 << i)     '设置key
                spaceidx = 0
                mend = i
            ElseIf bitval = 3 Then              '空
                spaceidx += 1
                mend = i
                If spaceidx = 5 Then            '空格达到5个
                    Exit For
                End If
            ElseIf bitval = 2 - player Then     '对方
                mend = i - 1
                Exit For
            End If
        Next
        '此时，mstart与dstart之间就是对方低位方向棋型
        '计算查询用key
        spaceidx = mend - dstart + 1        '棋型长度
        tmpkey = tmpkey >> dstart
        tmpkey = tmpkey Or ((17 - spaceidx) << (spaceidx + 1))
        '查询
        vs = dm(tmpkey)
        '计算更新起点
        pstart = point ' - (mend - dstart) * kdir
        Dim tmppoint As Integer
        Dim tmpval As Integer
        For i = 0 To spaceidx - 1
            tv = vs(i) - 1
            tmppoint = pstart + i * kdir
            If tv = -1 Then
                tmpval = cpTable(player)(tmppoint) And kdirmk
                cpTable(player)(tmppoint) = tmpval
                UpCpSortDate(tmpval, tmppoint, player)
            ElseIf tv > -1 AndAlso tv < 7 Then
                tmpval = (1 << tv * 4 + kdiridx) Or (cpTable(player)(tmppoint) And kdirmk)
                cpTable(player)(tmppoint) = tmpval
                UpCpSortDate(tmpval, tmppoint, player)
            End If
        Next
        '   Debug.Print("up right " & tmpstr & vbCrLf & "          " & tmpstrex)
    End Sub

    Private Sub UpEmptyDate(Key As Integer, dstart As Integer, dend As Integer, player As Integer, point As Integer, kdiridx As Integer, kdir As Integer)
        Dim i As Integer
        Dim bitval As Integer           '当前2位上的key值
        Dim tmpkey As Integer           '用于查询冲棋值的key
        Dim spaceidx As Integer         '空格数/tmpkey当中的棋长度
        Dim mstart, mend As Integer     '己方棋型的起止位（向量实际坐标）
        mstart = dstart                 '本方起点假定
        mend = dstart            '本方终点假定
        '向低位（起点）
        For i = dstart - 1 To 0 Step -1
            bitval = ((Key >> i * 2) And 3) - 1 '截取2位
            If bitval = player Then             '己方
                tmpkey = tmpkey Or (1 << i)     '设置key
                spaceidx = 0                    '记录空格
                mstart = i
            ElseIf bitval = 2 Then              '空
                spaceidx += 1
                mstart = i
                If spaceidx = 5 Then            '空格达到5个
                    Exit For
                End If
            ElseIf bitval = 1 - player Then     '对方
                mstart = i + 1
                Exit For
            End If
        Next
        '向高位
        spaceidx = 0
        For i = dstart + 1 To dend + dstart
            bitval = ((Key >> i * 2) And 3) - 1
            If bitval = player Then         '己方
                tmpkey = tmpkey Or (1 << i)
                spaceidx = 0
                mend = i
            ElseIf bitval = 2 Then              '空
                spaceidx += 1
                mend = i
                If spaceidx = 5 Then            '空格达到5个
                    Exit For
                End If
            ElseIf bitval = 1 - player Then     '对方
                mend = i - 1
                Exit For
            End If
        Next
        Dim kdirmk As Integer
        If kdiridx = 0 Then
            kdirmk = &HFEEEEEEE
        ElseIf kdiridx = 1 Then
            kdirmk = &HFDDDDDDD
        ElseIf kdiridx = 2 Then
            kdirmk = &HFBBBBBBB
        ElseIf kdiridx = 3 Then
            kdirmk = &HF7777777
        End If
        '清理当前下子点，因为这个点若查表后为0，则不被清理。
        'cpTable(player)(point).val = cpTable(player)(point).val And kdirmk
        'mstart,mend之间就是本方棋型了
        spaceidx = mend - mstart + 1    '长度
        If spaceidx >= 5 Then           '计算查询用key，撤销时只长度达到5时其中的空格才有意义。
            tmpkey = tmpkey >> mstart
            tmpkey = tmpkey Or ((17 - spaceidx) << (spaceidx + 1))
            '查询，更新
            Dim vs As Byte() = dm(tmpkey)   '查询当前key对应的冲棋信息
            '按冲棋信息更新棋盘点
            '冲棋信息0下标对应向量mstart位置，所以更新时冲棋值信息0下标对应棋盘点p-mstart*dir，随着冲棋值下标+1棋盘点步长为dir。
            Dim pstart As Integer = point - (dstart - mstart) * kdir
            Dim tv As Integer
            Dim tmppoint As Integer
            Dim tmpval As Integer
            For i = 0 To spaceidx - 1
                tmppoint = pstart + i * kdir
                tv = vs(i) - 1
                If tv = -1 Then
                    tmpval = cpTable(player)(tmppoint) And kdirmk
                ElseIf tv = 7 Then
                    tmpval = &H80000000
                ElseIf tv > -1 AndAlso tv < 7 Then
                    tmpval = (1 << tv * 4 + kdiridx) Or (cpTable(player)(tmppoint) And kdirmk)
                End If
                cpTable(player)(tmppoint) = tmpval
                UpCpSortDate(tmpval, tmppoint, player)
            Next
            '   Debug.Print("up empty " & tmpstr & vbCrLf & "         " & tmpstrex)
        End If
    End Sub

    Sub UpCpSortDate(Val As Integer, point As Integer, player As Integer)
        Dim tmpval As Integer
        '1、把原值前后的值连接起来。
        tmpval = cpSort(player)(point)
        If tmpval = &HFFFFF Then
            '1.1若为未分配节点，无需进行操作。
        ElseIf (tmpval And &HFFFF) = &HFFFF Then
            '1.2若为独节点，则只更新cpHead
            cpSortHead(player)((tmpval >> 16) And &HFF) = &HFF
        ElseIf (tmpval And &HFF) = &HFF Then
            '1.3若为非独头结点，更新下一个节点的left为&HFF、cpHead为下一个节点
            Dim rightindex As Integer = (cpSort(player)(point) >> 8) And &HFF                       '下一个节点的编号
            cpSort(player)(rightindex) = cpSort(player)(rightindex) Or &HFF                         '将下一个节点的left设置为&HFF
            Dim cptype As Integer = (tmpval >> 16)                                                  '所属冲棋类型
            cpSortHead(player)(cptype) = rightindex                                                 '将头结点设置为下一个节点
        ElseIf (tmpval And &HFF00) = &HFF00 Then
            '1.4若为非独尾节点，更新上一节点的right为&HFF
            Dim leftindex As Integer = cpSort(player)(point) And &HFF                               '上一个节点的编号
            cpSort(player)(leftindex) = cpSort(player)(leftindex) Or &HFF00                         '将上一个节点的right设置为&HFF
        Else
            '1.5若为中间节点，更新上一个节点的right为下一个节点，更新下一个节点的left为上一个节点
            Dim leftindex As Integer = cpSort(player)(point) And &HFF                               '上一个节点的编号
            Dim rightindex As Integer = (cpSort(player)(point) >> 8) And &HFF                       '下一个节点的编号
            cpSort(player)(leftindex) = cpSort(player)(leftindex) And &HF00FF Or (rightindex << 8)  '将上一个节点的right设置为下一个节点
            cpSort(player)(rightindex) = cpSort(player)(rightindex) And &HFFF00 Or leftindex        '将下一个节点的left设置为上一个
        End If
        '2、计算新值所处节点，并把它作为头结点。
        'wd=8,6050=7,42\4242\4142\4132=6,41=5,3232=4,32=3,3131\3122\2222=2,31\22=1
        Dim type As ConstValue.CombinationChessType
        If Val = 0 OrElse (Val = &H80000000) Then
            '2.1若新值为0，说明以前下子但未成胜利棋型或者是评价为0的点，若为&H80000000说明才下上子但未形成胜利棋型此时归结为未分配节点。
            cpSort(player)(point) = &HFFFFF
            Return
        ElseIf Val < 0 Then
            '2.2否则需要计算节点真实类别
            If (Val And &HF000000) <> 0 Then type = ConstValue.CombinationChessType.LWin____________ Else Throw New Exception("set player err")
        Else
            tmpval = ((Val And &H1111111) + ((Val And &H2222222) >> 1) + ((Val And &H4444444) >> 2) + ((Val And &H8888888) >> 3))
            If tmpval > &HFFFFF Then  '60,50
                type = ConstValue.CombinationChessType.L60_50__________
                'ElseIf tmpval > &H1FFFF Then  '42*2                 
                'type = 8
                'ElseIf tmpval > &HFFFF Then  '42
                'type = 8
            ElseIf tmpval > &H1FFF Then  '41*2                 
                type = ConstValue.CombinationChessType.L42_4141_4132___
            ElseIf tmpval > &HFFF Then  '41
                If (tmpval And &HFFF) > &HFF Then  '41+32
                    type = ConstValue.CombinationChessType.L42_4141_4132___
                ElseIf (tmpval And &HFF) > &HF Then    '41+31,22
                    type = ConstValue.CombinationChessType.L4131_4122______
                Else
                    type = ConstValue.CombinationChessType.L41_____________
                End If
            ElseIf tmpval > &H1FF Then  '32*2
                type = ConstValue.CombinationChessType.L3232___________
            ElseIf tmpval > &HFF Then  '32
                If (tmpval And &HFF) > &HF Then    '32+31,22
                    type = ConstValue.CombinationChessType.L3231_3222______
                Else
                    type = ConstValue.CombinationChessType.L32_____________
                End If
            ElseIf tmpval > &H1F Then  'double 31,22
                type = ConstValue.CombinationChessType.L3131_2222_3122_
            ElseIf tmpval > &HF Then '31,22
                type = ConstValue.CombinationChessType.L31_22__________
            ElseIf tmpval > 0 Then  '21
                type = ConstValue.CombinationChessType.L21_____________
            End If
        End If

        '2.3按真实类别把数据加入链表，但类型为0的不予理会。
        ' If type > 0 Then
        '2.3.1设置当前节点type\left\right信息
        If cpSortHead(player)(type) = &HFF Then
            '2.3.2.1若形成独节点，将节点的left,right设置为&HFF
            cpSort(player)(point) = (type << 16) Or &HFFFF
        Else
            '2.3.2.2若形成非独节点，将原来头结点的left设置为当前节点；将当前节点的left设置为&HFF，right设置为原来的头结点
            Dim headindex As Integer = cpSortHead(player)(type)     '原头结点的编号
            cpSort(player)(headindex) = cpSort(player)(headindex) And &HFFF00 Or point    '将原头结点的left设置为当前点
            cpSort(player)(point) = (type << 16) Or &HFF Or (cpSortHead(player)(type) << 8)  '设置当前节点
        End If
        '2.3.2将当前节点设置为头结点
        cpSortHead(player)(type) = point
        'Else
        ' Throw New Exception("类型分辨错误")
        ' End If
    End Sub

#If DEBUG Then
    Function PositionKey() As Integer()
        Dim ret(14) As Integer
        Dim i As Integer
        For i = 0 To 14
            ret(i) = vecKey(i)
        Next
        Return ret
    End Function
#End If

    Function IsEmptyPoint(p As Byte) As Byte
        Dim y As Byte = p >> 4
        Dim x As Byte = p And &HF
        Return ((vecKey(y) >> x * 2) And 3) - 1
    End Function

    Function IsGemeOverPos() As Byte
        If cpSortHead(0)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then Return 0
        If cpSortHead(1)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then Return 1
        Return 2
    End Function

    Function Evaluate() As Integer
        Dim EvaluateVal, i As Integer
        Dim cptmpnew As Integer
        Dim cntnew As Integer
        If cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then Return -ConstValue.WIN_VALUE '对方已经成5
        If cpSortHead(sdPlayer)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then Return ConstValue.WIN_VALUE '本方已经成5

        If cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L60_50__________) <> &HFF Then Return ConstValue.WIN_VALUE '本方可成5
        cptmpnew = cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.L60_50__________)
        If cptmpnew <> &HFF Then
            If ((cpSort(1 - sdPlayer)(cptmpnew) >> 8) And &HFF) <> &HFF Then  '对方有两个成5点
                Return -ConstValue.WIN_VALUE
            Else
                EvaluateVal = -ConstValue.LT_Val(ConstValue.CombinationChessType.L60_50__________)
            End If
        End If

        For i = ConstValue.CombinationChessType.L42_4141_4132___ To ConstValue.CombinationChessType.L31_22__________
            cntnew = 0
            cptmpnew = cpSortHead(sdPlayer)(i)
            Do Until cptmpnew = &HFF
                cntnew += 1
                cptmpnew = (cpSort(sdPlayer)(cptmpnew) >> 8) And &HFF
            Loop
            EvaluateVal += cntnew * ConstValue.LT_Val(i)
        Next
        For i = ConstValue.CombinationChessType.L42_4141_4132___ To ConstValue.CombinationChessType.L31_22__________
            cntnew = 0
            cptmpnew = cpSortHead(1 - sdPlayer)(i)
            Do Until cptmpnew = &HFF
                cntnew += 1
                cptmpnew = (cpSort(1 - sdPlayer)(cptmpnew) >> 8) And &HFF
            Loop
            EvaluateVal -= cntnew * ConstValue.LT_Val(i)
        Next
        Return EvaluateVal
    End Function

    Function NextPVSMove(ByRef nextMove() As Integer, ByVal iiddepthmv As Byte, pv As PVLine) As Integer
        '遍历冲棋值表，归并同类后进行排序
        Dim tmpidx, cnt, i As Integer
        Dim overpoint As New BitArray(240)  '记录已经添加过的点
        Dim cmbType As ConstValue.CombinationChessType
        '分类生成 wd=8,6050=7,42\4242\4142\4132=6,41=5,3232=4,32=3,3131\3122\2222=2,31\22=1
        '1、已经胜利一方，这里的处理需要注意，对方胜利这会处于一部分冲棋延伸过程中，所以应返回无走法；本方胜利这仅应处于未进行0深度搜索时。
        cmbType = ConstValue.CombinationChessType.LWin____________
        If cpSortHead(1 - sdPlayer)(cmbType) <> &HFF Then
            'Throw New Exception("对方已经胜利")
            Return -1
        End If
        If cpSortHead(sdPlayer)(cmbType) <> &HFF Then
            Throw New Exception("本方已经胜利")
        End If
        '2、存在50,60点，本方优先。
        cmbType = ConstValue.CombinationChessType.L60_50__________
        If cpSortHead(sdPlayer)(cmbType) <> &HFF Then
            nextMove(0) = cpSortHead(sdPlayer)(cmbType)
            Return 0
        End If
        If cpSortHead(1 - sdPlayer)(cmbType) <> &HFF Then
            nextMove(0) = cpSortHead(1 - sdPlayer)(cmbType)
            Return 0
        End If

        '本方必胜棋型44、43、42
        cmbType = ConstValue.CombinationChessType.L42_4141_4132___
        If cpSortHead(sdPlayer)(cmbType) <> &HFF Then
            tmpidx = cpSortHead(sdPlayer)(cmbType)
            Do Until tmpidx = &HFF
                If overpoint.Get(tmpidx) = False Then
                    overpoint.Set(tmpidx, True)
                    nextMove(cnt) = tmpidx
                    cnt += 1
                End If
                tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
            Loop
            Return cnt - 1
        End If
        '对方44、43、42
        If cpSortHead(1 - sdPlayer)(cmbType) <> &HFF Then
            tmpidx = cpSortHead(1 - sdPlayer)(cmbType)
            Do Until tmpidx = &HFF
                If overpoint.Get(tmpidx) = False Then
                    overpoint.Set(tmpidx, True)
                    nextMove(cnt) = tmpidx 'Or (cmbType << ConstValue.cpTypeMoveLen)
                    cnt += 1
                End If
                tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
            Loop
            '41棋型可能为解
            For i = ConstValue.CombinationChessType.L4131_4122______ To ConstValue.CombinationChessType.L41_____________
                tmpidx = cpSortHead(sdPlayer)(i)
                If cpSortHead(sdPlayer)(i) <> &HFF Then
                    Do Until tmpidx = &HFF
                        If overpoint.Get(tmpidx) = False Then
                            overpoint.Set(tmpidx, True)
                            nextMove(cnt) = tmpidx 'Or (cmbType << ConstValue.cpTypeMoveLen)
                            cnt += 1
                        End If
                        tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
                    Loop
                End If
            Next
            Return cnt - 1
        End If

        '33棋型，只识别对方没有41，本方有33的棋型。
        If (cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.L4131_4122______) = &HFF) AndAlso _
           (cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.L41_____________) = &HFF) Then
            cmbType = ConstValue.CombinationChessType.L3232___________
            If cpSortHead(sdPlayer)(cmbType) <> &HFF Then
                tmpidx = cpSortHead(sdPlayer)(cmbType)
                Do Until tmpidx = &HFF
                    If overpoint.Get(tmpidx) = False Then
                        overpoint.Set(tmpidx, True)
                        nextMove(cnt) = tmpidx 'Or (cmbType << ConstValue.cpTypeMoveLen)
                        cnt += 1
                    End If
                    tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
                Loop
                Return cnt - 1
            End If
        End If

        If cnt <> 0 Then Throw New Exception("cnt<>0")
        '3、添加置换表或内部迭代加深启发结果
        If iiddepthmv <> &HFF Then
            If overpoint.Get(iiddepthmv) = False Then
                nextMove(cnt) = iiddepthmv
                overpoint.Set(iiddepthmv, True)
                cnt += 1
            End If
        End If

        '杀手启发
        tmpidx = killer1(nDistance)
        If tmpidx <> &HFF Then
            If overpoint.Get(tmpidx) = False AndAlso (cpTable(0)(tmpidx) > 0) AndAlso (cpTable(1)(tmpidx) > 0) Then
                overpoint.Set(tmpidx, True)
                nextMove(cnt) = tmpidx
                cnt += 1
            End If
        End If
        tmpidx = killer2(nDistance)
        If tmpidx <> &HFF Then
            If overpoint.Get(tmpidx) = False AndAlso (cpTable(0)(tmpidx) > 0) AndAlso (cpTable(1)(tmpidx) > 0) Then
                overpoint.Set(tmpidx, True)
                nextMove(cnt) = tmpidx
                cnt += 1
            End If
        End If

        '4、添加pv走法启发
        If (nDistance = 0) Then '在根节点处添加整个走法列表
            If (pv IsNot Nothing) AndAlso (pv.back > 0) Then
                For i = pv.back \ 2 To pv.back - 1
                    If overpoint.Get(pv.argmove(i)) = False Then
                        nextMove(cnt) = pv.argmove(i)
                        overpoint.Set(pv.argmove(i), True)
                        cnt += 1
                    End If
                Next
            End If
        Else                '在枝节点处添加上次扫描的优先走法路径上的走法。
            If pv.back >= nDistance Then
                Dim t As Byte = pv.argmove(pv.back)
                If (overpoint(t) = False) AndAlso (cpTable(0)(t) > 0) AndAlso (cpTable(1)(t) > 0) Then
                    overpoint.Set(t, True)
                    nextMove(cnt) = t
                    cnt += 1
                End If
            End If
        End If

        '从41开始向后生成
        For i = ConstValue.CombinationChessType.L4131_4122______ To ConstValue.CombinationChessType.L3131_2222_3122_
            tmpidx = cpSortHead(sdPlayer)(i)
            Do Until tmpidx = &HFF
                If overpoint.Get(tmpidx) = False Then
                    overpoint.Set(tmpidx, True)
                    nextMove(cnt) = tmpidx
                    cnt += 1
                End If
                tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
            Loop
            tmpidx = cpSortHead(1 - sdPlayer)(i)
            Do Until tmpidx = &HFF
                If overpoint.Get(tmpidx) = False Then
                    overpoint.Set(tmpidx, True)
                    nextMove(cnt) = tmpidx
                    cnt += 1
                End If
                tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
            Loop
        Next

        If iiddepthmv <> &HFF AndAlso cnt > 0 Then Return cnt - 1

        cmbType = ConstValue.CombinationChessType.L31_22__________
        tmpidx = cpSortHead(sdPlayer)(cmbType)
        Do Until tmpidx = &HFF
            If overpoint.Get(tmpidx) = False Then
                overpoint.Set(tmpidx, True)
                nextMove(cnt) = tmpidx
                cnt += 1
            End If
            tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
        Loop
        tmpidx = cpSortHead(1 - sdPlayer)(cmbType)
        Do Until tmpidx = &HFF
            If overpoint.Get(tmpidx) = False Then
                overpoint.Set(tmpidx, True)
                nextMove(cnt) = tmpidx
                cnt += 1
            End If
            tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
        Loop
        If cnt > 0 Then Return cnt - 1

        cmbType = ConstValue.CombinationChessType.L21_____________
        tmpidx = cpSortHead(sdPlayer)(cmbType)
        Do Until tmpidx = &HFF
            If overpoint.Get(tmpidx) = False Then
                overpoint.Set(tmpidx, True)
                nextMove(cnt) = tmpidx
                cnt += 1
            End If
            tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
        Loop
        tmpidx = cpSortHead(1 - sdPlayer)(cmbType)
        Do Until tmpidx = &HFF
            If overpoint.Get(tmpidx) = False Then
                overpoint.Set(tmpidx, True)
                nextMove(cnt) = tmpidx
                cnt += 1
            End If
            tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
        Loop
        Return cnt - 1
    End Function

    Function NextVCFMove(ByRef nextMove() As Integer, AttackPlayer As Integer) As Integer
        '遍历冲棋值表，归并同类后进行排序
        Dim i, tmpidx, cnt As Integer
        Dim overpoint As New BitArray(240)  '记录已经添加过的点
        '分类生成 wd=8,6050=7,42\4242\4142\4132=6,41=5,3232=4,32=3,3131\3122\2222=2,31\22=1
        '1、已经胜利一方，这里的处理需要注意，对方胜利这会处于一部分冲棋延伸过程中，所以应返回无走法；本方胜利这仅应处于未进行0深度搜索时。
        If cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then
            Return -2
        End If
        If cpSortHead(sdPlayer)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then
            Throw New Exception("本方已经胜利")
        End If
        '2、存在50,60点，本方优先。
        If cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L60_50__________) <> &HFF Then
            nextMove(0) = cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L60_50__________)
            Return 0
        End If

        '3
        If AttackPlayer = sdPlayer Then '进攻方生成器，进攻方只能进攻，不能防守。
            For i = ConstValue.CombinationChessType.L42_4141_4132___ To ConstValue.CombinationChessType.L41_____________
                If cpSortHead(sdPlayer)(i) <> &HFF Then
                    tmpidx = cpSortHead(sdPlayer)(i)
                    Do Until tmpidx = &HFF
                        If overpoint.Get(tmpidx) = False Then
                            overpoint.Set(tmpidx, True)
                            nextMove(cnt) = tmpidx Or (i << ConstValue.cpTypeMoveLen)
                            cnt += 1
                        End If
                        tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
                    Loop
                End If
            Next
            Return cnt - 1
        Else                    '防守方生成器，防守方只能防守。（可能乘手但一定是防守乘手，不能单冲）
            For i = ConstValue.CombinationChessType.L60_50__________ To ConstValue.CombinationChessType.L42_4141_4132___
                If cpSortHead(1 - sdPlayer)(i) <> &HFF Then
                    tmpidx = cpSortHead(1 - sdPlayer)(i)
                    Do Until tmpidx = &HFF
                        If overpoint.Get(tmpidx) = False Then
                            overpoint.Set(tmpidx, True)
                            nextMove(cnt) = tmpidx
                            cnt += 1
                        End If
                        tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
                    Loop
                End If
            Next
            Return cnt - 1
        End If
    End Function

    Function NextVCTMove(ByRef nextMove() As Integer, AttackPlayer As Integer) As Integer
        '遍历冲棋值表，归并同类后进行排序
        Dim i, tmpidx, cnt As Integer
        Dim overpoint As New BitArray(240)  '记录已经添加过的点
        '分类生成 wd=8,6050=7,42\4242\4142\4132=6,41=5,3232=4,32=3,3131\3122\2222=2,31\22=1
        '1、已经胜利一方，这里的处理需要注意，对方胜利这会处于一部分冲棋延伸过程中，所以应返回无走法；本方胜利这仅应处于未进行0深度搜索时。
        If cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then
            Return -2
        End If
        If cpSortHead(sdPlayer)(ConstValue.CombinationChessType.LWin____________) <> &HFF Then
            Throw New Exception("本方已经胜利")
        End If
        '2、存在50,60点，本方优先。
        If cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L60_50__________) <> &HFF Then
            nextMove(0) = cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L60_50__________)
            Return 0
        End If
        '3
        If AttackPlayer = sdPlayer Then '进攻方生成器，进攻方只能进攻，不能防守。
            '防守方胜利棋型
            If cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.L60_50__________) <> &HFF Then
                tmpidx = cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.L60_50__________)
                Do Until tmpidx = &HFF
                    If overpoint.Get(tmpidx) = False Then
                        overpoint.Set(tmpidx, True)
                        nextMove(cnt) = tmpidx
                        cnt += 1
                    End If
                    tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
                Loop
            End If
            If cnt = 0 Then
            ElseIf cnt = 1 Then
                Return 0
            ElseIf cnt > 1 Then
                Return -2
            End If
            '攻击方无进攻棋型，返回
            If (cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L42_4141_4132___) = &HFF) AndAlso _
                (cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L4131_4122______) = &HFF) AndAlso _
                (cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L41_____________) = &HFF) AndAlso _
                (cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L3232___________) = &HFF) AndAlso _
                (cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L3231_3222______) = &HFF) AndAlso _
                (cpSortHead(sdPlayer)(ConstValue.CombinationChessType.L32_____________) = &HFF) Then
                Return -2
            End If
            '攻击方强制棋型
            For i = ConstValue.CombinationChessType.L42_4141_4132___ To ConstValue.CombinationChessType.L41_____________
                If cpSortHead(sdPlayer)(i) <> &HFF Then
                    tmpidx = cpSortHead(sdPlayer)(i)
                    Do Until tmpidx = &HFF
                        If overpoint.Get(tmpidx) = False Then
                            overpoint.Set(tmpidx, True)
                            nextMove(cnt) = tmpidx Or (i << ConstValue.cpTypeMoveLen)
                            cnt += 1
                        End If
                        tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
                    Loop
                End If
            Next
            '防守方强制棋型
            If cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.L42_4141_4132___) <> &HFF Then
                tmpidx = cpSortHead(1 - sdPlayer)(ConstValue.CombinationChessType.L42_4141_4132___)
                Do Until tmpidx = &HFF
                    If overpoint.Get(tmpidx) = False Then
                        overpoint.Set(tmpidx, True)
                        nextMove(cnt) = tmpidx Or &H80000000
                        cnt += 1
                    End If
                    tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
                Loop
            End If
            '攻击方32棋型
            For i = ConstValue.CombinationChessType.L3232___________ To ConstValue.CombinationChessType.L32_____________
                If cpSortHead(sdPlayer)(i) <> &HFF Then
                    tmpidx = cpSortHead(sdPlayer)(i)
                    Do Until tmpidx = &HFF
                        If overpoint.Get(tmpidx) = False Then
                            overpoint.Set(tmpidx, True)
                            nextMove(cnt) = tmpidx Or (i << ConstValue.cpTypeMoveLen)
                            cnt += 1
                        End If
                        tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
                    Loop
                End If
            Next
            Return cnt - 1
        Else                    '防守方生成器，防守方防守进攻均可。
            '攻击方胜利、强制棋型
            For i = ConstValue.CombinationChessType.L60_50__________ To ConstValue.CombinationChessType.L42_4141_4132___
                If cpSortHead(1 - sdPlayer)(i) <> &HFF Then
                    tmpidx = cpSortHead(1 - sdPlayer)(i)
                    Do Until tmpidx = &HFF
                        If overpoint.Get(tmpidx) = False Then
                            overpoint.Set(tmpidx, True)
                            nextMove(cnt) = tmpidx
                            cnt += 1
                        End If
                        tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
                    Loop
                End If
            Next
            '守方全部棋型
            For i = ConstValue.CombinationChessType.L42_4141_4132___ To ConstValue.CombinationChessType.L32_____________
                If cpSortHead(sdPlayer)(i) <> &HFF Then
                    tmpidx = cpSortHead(sdPlayer)(i)
                    Do Until tmpidx = &HFF
                        If overpoint.Get(tmpidx) = False Then
                            overpoint.Set(tmpidx, True)
                            nextMove(cnt) = tmpidx
                            cnt += 1
                        End If
                        tmpidx = (cpSort(sdPlayer)(tmpidx) >> 8) And &HFF
                    Loop
                End If
            Next
            '攻方32、32
            i = ConstValue.CombinationChessType.L3232___________
            If cpSortHead(1 - sdPlayer)(i) <> &HFF Then
                tmpidx = cpSortHead(1 - sdPlayer)(i)
                Do Until tmpidx = &HFF
                    If overpoint.Get(tmpidx) = False Then
                        overpoint.Set(tmpidx, True)
                        nextMove(cnt) = tmpidx
                        cnt += 1
                    End If
                    tmpidx = (cpSort(1 - sdPlayer)(tmpidx) >> 8) And &HFF
                Loop
            End If
            Return cnt - 1
        End If
    End Function

    Function Clone() As Position
        Dim ret As New Position
        Array.Copy(Me.vecKey, ret.vecKey, 72)
        ret.curposkey = Me.curposkey.Clone
        ret.sdPlayer = Me.sdPlayer
        ret.aiPlayer = Me.aiPlayer
        ret.nDistance = Me.nDistance
        ret.mvResult = Me.mvResult
        ReDim ret.cpTable(0)(239)
        ReDim ret.cpTable(1)(240)
        Array.Copy(Me.cpTable(0), ret.cpTable(0), 240)
        Array.Copy(Me.cpTable(1), ret.cpTable(1), 240)
        ReDim ret.cpSort(0)(239)
        ReDim ret.cpSort(1)(239)
        Array.Copy(Me.cpSort(0), ret.cpSort(0), 240)
        Array.Copy(Me.cpSort(1), ret.cpSort(1), 240)
        ReDim ret.cpSortHead(0)(ConstValue.CombinationChessType.L21_____________)
        ReDim ret.cpSortHead(1)(ConstValue.CombinationChessType.L21_____________)
        Array.Copy(Me.cpSortHead(0), ret.cpSortHead(0), 11)
        Array.Copy(Me.cpSortHead(1), ret.cpSortHead(1), 11)
        Array.Copy(Me.killer1, ret.killer1, 239)
        Array.Copy(Me.killer2, ret.killer2, 239)
        Return ret
    End Function

    Function dex2bin(ByVal dex As Integer, ByVal len As Integer) As String
        Dim tmp As String = String.Empty
        Dim i As Integer
        For i = 0 To 31
            tmp = ((dex >> i) And 1) & IIf((i Mod len) = 0, " ", String.Empty) & tmp
        Next
        Return tmp
    End Function

    Function dex2OX(dex As Integer) As String
        Dim tmp As String = dex2bin(dex, 2)
        Return tmp.Replace("11", ".").Replace("10", "1").Replace("01", "0").Replace("00", String.Empty)
    End Function

End Class

