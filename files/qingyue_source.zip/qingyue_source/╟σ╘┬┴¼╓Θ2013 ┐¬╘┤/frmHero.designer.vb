﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHero
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmHero))
        Me.pnlBoard = New System.Windows.Forms.Panel
        Me.txtSearchFen = New System.Windows.Forms.TextBox
        Me.txtInfo = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'pnlBoard
        '
        Me.pnlBoard.BackgroundImage = CType(resources.GetObject("pnlBoard.BackgroundImage"), System.Drawing.Image)
        Me.pnlBoard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pnlBoard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlBoard.Location = New System.Drawing.Point(1, 2)
        Me.pnlBoard.Name = "pnlBoard"
        Me.pnlBoard.Size = New System.Drawing.Size(387, 387)
        Me.pnlBoard.TabIndex = 3
        '
        'txtSearchFen
        '
        Me.txtSearchFen.Location = New System.Drawing.Point(393, 2)
        Me.txtSearchFen.Name = "txtSearchFen"
        Me.txtSearchFen.Size = New System.Drawing.Size(384, 21)
        Me.txtSearchFen.TabIndex = 1
        Me.txtSearchFen.Text = "H8 I9 I8 J8 H10 H9 G9 I7 G8 F8 "
        '
        'txtInfo
        '
        Me.txtInfo.Location = New System.Drawing.Point(393, 26)
        Me.txtInfo.Multiline = True
        Me.txtInfo.Name = "txtInfo"
        Me.txtInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtInfo.Size = New System.Drawing.Size(384, 360)
        Me.txtInfo.TabIndex = 4
        Me.txtInfo.Text = resources.GetString("txtInfo.Text")
        '
        'frmHero
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(780, 388)
        Me.Controls.Add(Me.txtInfo)
        Me.Controls.Add(Me.txtSearchFen)
        Me.Controls.Add(Me.pnlBoard)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(796, 426)
        Me.MinimumSize = New System.Drawing.Size(796, 426)
        Me.Name = "frmHero"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "清月连珠"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlBoard As System.Windows.Forms.Panel
    Friend WithEvents txtSearchFen As System.Windows.Forms.TextBox
    Friend WithEvents txtInfo As System.Windows.Forms.TextBox

End Class
