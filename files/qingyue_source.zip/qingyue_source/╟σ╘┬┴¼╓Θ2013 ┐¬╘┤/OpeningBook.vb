﻿
Public Class OpeningBook

    Private Const Right = &H1   '达到叶节点
    Private Const Down = &H2    '有右侧兄弟
    Private Const Good = &H4    '较好的节点
    Public Const Best = &H8     '最好的节点
    Private Const Unknown = 16  '==================未注释节点==================

    Public Const OutPos As Integer = &H80000000     '未找到

    '委托，这样可以少写不少代码。。。
    Public Delegate Function ConvertPoint(p As Byte) As Byte
    Public ConvertFuns() As ConvertPoint = New ConvertPoint() {New ConvertPoint(AddressOf RotatePoint0), _
                                                         New ConvertPoint(AddressOf RotatePoint90), _
                                                         New ConvertPoint(AddressOf RotatePoint180), _
                                                         New ConvertPoint(AddressOf RotatePoint270), _
                                                         New ConvertPoint(AddressOf vFlipPoint), _
                                                         New ConvertPoint(AddressOf hFlipPoint), _
                                                         New ConvertPoint(AddressOf dlFlipPoint), _
                                                         New ConvertPoint(AddressOf drFlipPoint)}

    '委托调用顺序控制，这样可以在再次搜索时优先使用上次成功匹配book的委托。
    Private CallSequence As New List(Of ConvertPoint)
    '局面旋转\对称后，查找到相应的结果也是旋转\对称的，所以需要这个表，记录调用一个转换函数后，应该调用哪个函数进行逆转换。
    Private InverseConversion As New List(Of ConvertPoint)
    '
    Dim zob As New Zobrist
    Public NodeDict As New Dictionary(Of Zobrist.PosKey, List(Of Integer))
    Public Event OpenBookInfo(inf As String)


    Sub New()
        Dim i As Integer
        '初始化调用顺序表
        For i = 0 To ConvertFuns.Length - 1
            CallSequence.Add(ConvertFuns(i))
        Next
        '初始化逆转换表
        InverseConversion.Add(ConvertFuns(0))    '未旋转的逆转换就是自身
        InverseConversion.Add(ConvertFuns(3))    '旋转90度的逆转换是继续旋转270
        InverseConversion.Add(ConvertFuns(2))  '同上
        InverseConversion.Add(ConvertFuns(1))   '同上
        InverseConversion.Add(ConvertFuns(4))   '对称的逆转换就是自身
        InverseConversion.Add(ConvertFuns(5))   '同上
        InverseConversion.Add(ConvertFuns(6))   '同上
        InverseConversion.Add(ConvertFuns(7))   '同上
    End Sub

    Sub ins()
        '初始化开局库
        RaiseEvent OpenBookInfo("解压开局库……")
        Dim t As Integer = My.Computer.Clock.TickCount
        Dim buff = zobDeZip(My.Resources.t14)
        RaiseEvent OpenBookInfo("解压开局库耗时:" & My.Computer.Clock.TickCount - t & vbCrLf)
        RaiseEvent OpenBookInfo("解析开局库……")
        t = My.Computer.Clock.TickCount
        file2hash(buff)
        RaiseEvent OpenBookInfo("解析开局库耗时:" & My.Computer.Clock.TickCount - t)
    End Sub

    Private Sub file2hash(buff As Byte())
        Dim sdPlayer As Integer = 1
        Dim movelist(239) As Byte
        Dim moveptr As Byte
        Dim start As Integer    '当前字节
        Dim LastDownNodePtr As New Stack(Of Byte)  '上一个有右节点的节点
        Dim LastIsRightNode As Boolean    '上一个节点是否是叶节点
        Dim txtcoune As Integer         '读取注释个数
        Dim backNode As List(Of Integer) = New List(Of Integer)   '上一个读取的节点
        Dim curKey As New Zobrist.PosKey
        Dim mpoint As Integer
        Dim minfo As Integer
        '分析文件内容
        Do Until start >= buff.Length - 1   '按字节扫描
            Dim Node As New List(Of Integer)         '当前节点
            '棋子坐标（renlib纵坐标从0开始，横坐标从1开始）
            mpoint = buff(start)
            start += 1
            minfo = buff(start)
            start += 1

            If minfo > (Down Or Right) Then
                txtcoune += 1
            Else
                minfo = minfo Or Unknown
            End If

            '注意几组IF的先后顺序。根据这一次读取的节点是否是尾节点，还决定如何连接这个节点。上一个节点是尾节点，那么当前节点就要连接到最近一个有兄弟的节点上。
            If LastIsRightNode Then                     '之前达到叶节点，现在进行的操作是下子回滚。
                Dim downpoint As Byte = LastDownNodePtr.Pop                 '之前存在右侧节点的点。
                Dim exitdo As Boolean
                Do
                    moveptr -= 1
                    exitdo = movelist(moveptr) = downpoint
                    sdPlayer = 1 - sdPlayer
                    zob.SetPlayer(curKey, sdPlayer, movelist(moveptr))
                Loop Until exitdo
            End If
            If (minfo And Down) = Down Then
                LastDownNodePtr.Push(mpoint)   '右侧有兄弟，记录走法
            End If

            If (minfo And Right) = Right Then  '是否达到叶节点
                LastIsRightNode = True
            Else
                LastIsRightNode = False
            End If

            If NodeDict.ContainsKey(curKey) Then
                NodeDict(curKey).Add((mpoint << 8) Or minfo)
            Else
                Node = New List(Of Integer)
                Node.Add((mpoint << 8) Or minfo)
                NodeDict.Add(curKey, Node)
            End If
            backNode = Node
            movelist(moveptr) = mpoint
            moveptr += 1
            zob.SetPlayer(curKey, sdPlayer, mpoint)
            sdPlayer = 1 - sdPlayer
            If (start Mod 1000000) = 0 Then RaiseEvent OpenBookInfo("已读取开局库:" & Format(start / buff.Length, "p"))
        Loop
        RaiseEvent OpenBookInfo("已读取开局库:100%" & vbCrLf & vbCrLf & _
                                "局面数:" & NodeDict.Count & " 节点数:" & buff.Length / 2 & " 注释数:" & txtcoune)
    End Sub

    '解压缩文件，因为T14.ZOB是使用GZIP压缩的，所以要把它解压之后才能分析关系树进而初始化开局库。
    Private Function zobDeZip(data() As Byte) As Byte()
        Dim ret() As Byte   '返回值
        Dim sms As New IO.MemoryStream(data)    '未解压的数据流
        Dim gzip As New IO.Compression.GZipStream(sms, IO.Compression.CompressionMode.Decompress, True)
        Dim ms As New IO.MemoryStream           '解压后的数据流
        Dim DeZipBuffLen As Integer = &HFF      '每次解压的字节数
        Dim buf(DeZipBuffLen - 1) As Byte, i As Integer = 0 '解压缓冲区
        While True  '循环解压
            i = gzip.Read(buf, 0, DeZipBuffLen)
            If i = 0 Then Exit While
            ms.Write(buf, 0, i)
        End While
        ret = ms.ToArray    '返回值
        sms.Close()     '清理工作
        ms.Close()
        gzip.Close()
        Return ret
    End Function

    '局面在开局库中的全部走法。
    Function findall(mv() As Byte) As List(Of Integer)
        '坐标转换结果
        Dim ret As New List(Of Integer)
        Dim SearchMvs(mv.Length - 1) As Byte
        Dim SearchResults As List(Of Integer)    '返回值
        Dim SearchOutBook As Integer = OutPos
        Dim key As Zobrist.PosKey
        Dim sdplayer As Integer
        '逐个测试转换
        For j As Integer = CallSequence.Count - 1 To 0 Step -1      '按照转换函数优先顺序依次调用它们
            key = New Zobrist.PosKey
            sdplayer = 1
            Dim i As Integer
            '转换坐标
            For i = 0 To mv.Length - 1
                SearchMvs(i) = CallSequence(j)(mv(i))
                zob.SetPlayer(key, sdplayer, SearchMvs(i))
                sdplayer = 1 - sdplayer
            Next
            '用转换后的坐标查询book

            If NodeDict.ContainsKey(key) Then         '未找到，继续
                SearchResults = NodeDict(key)
                Dim tmparr() As Integer = SearchResults.ToArray
                For i = 0 To tmparr.Length - 1    '将坐标转换回来
                    Dim tmppoint As Integer = tmparr(i) >> 8
                    Dim tmpinfo As Integer = tmparr(i) And &HFF
                    tmppoint = InverseConversion(j)(tmppoint)
                    tmparr(i) = (tmppoint << 8) Or tmpinfo
                Next
                ret.AddRange(tmparr)
            Else                                '找到路线，但不是VCF/VCT解，返回值vctbook位为0。
            End If
        Next
        ' If (SearchResults And UnknownPos) = UnknownPos Then Throw New Exception("err")
        '没有找到匹配截断局面。
        Return ret
    End Function

    '按一个招法路线扫描开局库，找不到时返回值小于0；找到时若路径中某一个位置达到VCF/VCT即叶节点，那么返回&H40000000 or 该位置（mv的下标），若未达到叶节点则返回走法。
    Private Function SearchBook(key As Zobrist.PosKey, sdPlayer As Integer) As Integer
        Dim tt As List(Of Integer)
        If NodeDict.ContainsKey(key) Then
            tt = (NodeDict(key))
            '保存标志为best、good的点，然后按顺序随机化选取返回值，而不关心多少步之后终结。
            Dim ta As New List(Of Integer)    '标志为a的点
            Dim tc As New List(Of Integer)    '标志位c的点
            Dim tu As New List(Of Integer)
            Dim i As Integer
            For i = 0 To tt.Count - 1
                If (tt(i) And Best) = Best Then ta.Add(tt(i) >> 8)
                If (tt(i) And Good) = Good Then tc.Add(tt(i) >> 8)
                If (tt(i) And Unknown) = Unknown Then tu.Add(tt(i) >> 8)
            Next

            If ta.Count > 0 Then
                Randomize()
                Return ta((ta.Count - 1) * Rnd()) '无论黑白，先选择标志为a的点。
            End If

            If tc.Count > 0 Then
                Randomize()
                Return tc((tc.Count - 1) * Rnd())
            End If

            If tu.Count > 0 Then
                Randomize()
                Return tu((tu.Count - 1) * Rnd())
            End If
        End If
        Return OutPos
    End Function

    '这个函数与上面的函数功能相近，返回值意义相同。这个函数会先把招法路线按照上一次查找到局面时的转换函数转换，若找到则返回，若没有则根据其他转换函数转换，并依次查找。
    Function SearchAllSamePosition(mv() As Byte) As Integer
        '坐标转换结果
        Dim SearchMvs(mv.Length - 1) As Byte
        Dim SearchResults As Integer    '返回值
        Dim SearchOutBook As Integer = OutPos
        Dim key As Zobrist.PosKey
        Dim sdplayer As Integer
        '逐个测试转换
        For j As Integer = CallSequence.Count - 1 To 0 Step -1      '按照转换函数优先顺序依次调用它们
            key = New Zobrist.PosKey
            sdplayer = 1
            Dim i As Integer
            '转换坐标
            For i = 0 To mv.Length - 1
                SearchMvs(i) = CallSequence(j)(mv(i))
                zob.SetPlayer(key, sdplayer, SearchMvs(i))
                sdplayer = 1 - sdplayer
            Next
            '用转换后的坐标查询book
            SearchResults = SearchBook(key, sdplayer)
            If (SearchResults And OutPos) = OutPos Then         '未找到，继续
            Else                                '找到路线，但不是VCF/VCT解，返回值vctbook位为0。
                SearchResults = InverseConversion(j)(SearchResults)    '下面那句注释掉的等效于这句。（位置不要变）
                Dim tmp As ConvertPoint
                '因为找到的是一个index，所以只要记录转换顺序表就可以了。
                tmp = CallSequence(j)
                CallSequence.RemoveAt(j)      '把找到结果的转换方式放在最后，下次查找时第一个调用它。
                CallSequence.Add(tmp)
                '逆转换表也要进行同样操作以保证一致性
                tmp = InverseConversion(j)
                InverseConversion.RemoveAt(j)
                InverseConversion.Add(tmp)
                'SearchResults = ConvertFuns(InverseConversion(InverseConversion.Count - 1))(SearchResults) 
                Return SearchResults
            End If
        Next
        ' If (SearchResults And UnknownPos) = UnknownPos Then Throw New Exception("err")
        '没有找到匹配截断局面。
        Return SearchOutBook
    End Function

    '顺时针旋转0度…………呃，这个只是为了编码少一点（其实逻辑也看起来清晰一点），不用单独写不旋转招法路线的搜索。
    '虽然效率上有所降低，不过开局库的查找远比搜索博弈树快得多……何况五子棋严格来说是地毯普，不是开局库。
    Private Function RotatePoint0(p As Byte) As Byte
        Return p
    End Function

    '顺时针旋转90度
    Private Function RotatePoint90(p As Byte) As Byte
        Return ((p And &HF) << 4) Or (&HE - (p >> 4))
    End Function

    '顺时针旋转180度
    Private Function RotatePoint180(p As Byte) As Byte
        Return (&HE - (p And &HF)) Or (&HE0 - (p And &HF0))
    End Function

    '顺时针旋转270度
    Private Function RotatePoint270(p As Byte) As Byte
        Return ((&HE - (p And &HF)) << 4) Or ((p >> 4))
    End Function

    '竖直翻转
    Private Function vFlipPoint(p As Byte) As Byte
        Return (p And &HF) Or (&HE0 - (p And &HF0))
    End Function

    '水平翻转
    Private Function hFlipPoint(p As Byte) As Byte
        Return (&HE - (p And &HF)) Or (p And &HF0)
    End Function

    '左上右下对角线
    Private Function dlFlipPoint(p As Byte) As Byte
        Return ((p And &HF) << 4) Or ((p And &HF0) >> 4)
    End Function

    '右上左下对角线
    Private Function drFlipPoint(p As Byte) As Byte
        Return (&HE - (p And &HF) << 4) Or (&HE0 - (p And &HF0) >> 4)
    End Function

End Class
