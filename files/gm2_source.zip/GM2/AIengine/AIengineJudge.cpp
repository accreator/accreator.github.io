 /*#####################################################
 * file:	AIengineJudge.cpp
 *
 * ���ã�	��cppʵ�ֵ�ǰ���͵Ļ����жϺ���
 *
 *
 ######################################################*/


#include "StdAfx.h"
#include "BoardN.h"

#include <cassert>
#include <iostream>

using namespace std;


int BoardN::GLobal_DEPTH=7; //VCT��������

/************************************************************************/
/*  �жϺ����Ƿ�����ܵ���                                              */
/************************************************************************/
bool BoardN::AttackH(int gdepth,CPos &pos) 
{
	GLobal_DEPTH=gdepth;

	/*��������*/
	first_hand=CType::BLACK;
	
	for(int i=1;i<=1;i++)
	{
		MaxSearchDepth=16*i;

		GetH_G(current,true);
		GetW_G(current,true);
		
		int i,j;
		int k,r;
		int c=current;
		
		/*����*/
		if(listNnr[0][c][T4::Q5])
		{
			pos.i=listN[0][c][T4::Q5][0].i;
			pos.j=listN[0][c][T4::Q5][0].j;
			return true;
		}
		/*�Է�����*/
		else if(listNnr[1][c][T4::Q5])
		{
			return false;
		}
		/*����*/
		else if(listNnr[0][c][T4::Q4d])
		{
			pos.i=listN[0][c][T4::Q4d][0].i;
			pos.j=listN[0][c][T4::Q4d][0].j;
			return true;
		}
		else
		{
			for(r=0;r<listNnr[0][c][T4::Q43];r++)
			{
				i=listN[0][c][T4::Q43][r].i;
				j=listN[0][c][T4::Q43][r].j;
				if(VCTH(i,j))
				{
					pos.i=i;
					pos.j=j;
					return true;
				}		
			}
			for(k=T4::Q3d_d;k<=T4::Q3d;k++) 
			{
				for(r=0;r<listNnr[0][c][k];r++)
				{
					i=listN[0][c][k][r].i;
					j=listN[0][c][k][r].j;
					if(VCTH(i,j))
					{
						pos.i=i;
						pos.j=j;
						return true;
					}		
				}
			}
			for(k=T4::Q4s;k<=T4::Q4;k++) 
			{
				for(r=0;r<listNnr[0][c][k];r++)
				{
					i=listN[0][c][k][r].i;
					j=listN[0][c][k][r].j;
					if(VCTH(i,j))
					{
						pos.i=i;
						pos.j=j;
						return true;
					}		
				}
			}
		}
	}
	return false;
}


/************************************************************************/
/* �жϰ����Ƿ�����ܵ���                                               */
/************************************************************************/
bool BoardN::AttackW(int gdepth,CPos &pos) 
{
	GLobal_DEPTH=gdepth;

	/*��������*/
	first_hand=CType::WHITE;

	for(int i=1;i<=1;i++)
	{
		MaxSearchDepth=16*i;

		GetH_G(current,true);
		GetW_G(current,true);
		
		int i,j;
		int k,r;
		int c=current;
		
		/*����*/
		if(listNnr[1][c][T4::Q5])
		{
			pos.i=listN[1][c][T4::Q5][0].i;
			pos.j=listN[1][c][T4::Q5][0].j;
			return true;
		}
		/*�Է�����*/
		else if(listNnr[0][c][T4::Q5])
		{
			return false;
		}
		/*����*/
		else if(listNnr[1][c][T4::Q4d])
		{
			pos.i=listN[1][c][T4::Q4d][0].i;
			pos.j=listN[1][c][T4::Q4d][0].j;
			return true;
		}
		else
		{
			for(r=0;r<listNnr[1][c][T4::Q43];r++)
			{
				i=listN[1][c][T4::Q43][r].i;
				j=listN[1][c][T4::Q43][r].j;
				if(VCTW(i,j))
				{
					pos.i=i;
					pos.j=j;
					return true;
				}		
			}
			for(k=T4::Q3d_d;k<=T4::Q3d;k++) 
			{
				for(r=0;r<listNnr[1][c][k];r++)
				{
					i=listN[1][c][k][r].i;
					j=listN[1][c][k][r].j;
					if(VCTW(i,j))
					{
						pos.i=i;
						pos.j=j;
						return true;
					}		
				}
			}
			for(k=T4::Q4s;k<=T4::Q4;k++) 
			{
				for(r=0;r<listNnr[1][c][k];r++)
				{
					i=listN[1][c][k][r].i;
					j=listN[1][c][k][r].j;
					if(VCTW(i,j))
					{
						pos.i=i;
						pos.j=j;
						return true;
					}		
				}
			}
		}
	}

	return false;
}

/************************************************************************/
/*��̬����                                                              */
/************************************************************************/
/*
 ��̬������ָ��ԭ��
	��Ҫ��ǿ��֮�����ͨ�ԣ�������ǿ��ĸ�����
	�ĺͻ�������ǿ�㣬����û�����𣬼�������������λ2���Է���λΪ1
	���һ��ǿ������ǹ���ǿ��ķ���������ǿ�㣬��õ��ֵҪ�������棨����ϵ������
	���磺
	Q3d Q3d
	Q3d
	���һ��Q3d��ֵΪ3*Q3d
	��̬�������Ǵ�����ǰ���ֽ����жϡ�
 */
int BoardN::StaticEvaluate()
{
	int value=0;
	int k,r,d,x,y;
	int factor; //����������˵������ϵ��
	
	int t=step&0x1;

	GetCands_ALL_W(current);
	GetCands_ALL_H(current);

	for(k=T4::Q4s;k<=T4::Q3d;k++){
		for(r=0;r<listNnr[t][current][k];r++){
			x=listN[t][current][k][r].i;
			y=listN[t][current][k][r].j;
			factor=1;
			if(k<=T4::Q4){
				for(d=0;d<4;d++) if(qType[t][x][y].qtype[d]==T1::Q4) break;
			}else{
				for(d=0;d<4;d++) if(qType[t][x][y].qtype[d]==T1::Q3d) break;
			}
			for(int dd=0;dd<4;dd++){
				if(dd!=d){
					for(int n=1;n<=4;n++){
						if(boardT[1-t][1+x+n*xl[dd]][1+y+n*yl[dd]]) break;
						if(qType[t][x+n*xl[dd]][y+n*yl[dd]].qTYPE<=T4::Q3d) factor++;
					}
					for(n=1;n<=4;n++){
						if(boardT[1-t][1+x+n*xr[dd]][1+y+n*yr[dd]]) break;
						if(qType[t][x+n*xr[dd]][y+n*yr[dd]].qTYPE<=T4::Q3d) factor++;
					}
				}
			}	
			//value+=2*factor;
			value+=factor;
		}
		for(r=0;r<listNnr[1-t][current][k];r++){
			x=listN[1-t][current][k][r].i;
			y=listN[1-t][current][k][r].j;
			factor=1;
			if(k<=T4::Q4){
				for(d=0;d<4;d++) if(qType[1-t][x][y].qtype[d]==T1::Q4) break;
			}else{
				for(d=0;d<4;d++) if(qType[1-t][x][y].qtype[d]==T1::Q3d) break;
			}
			for(int dd=0;dd<4;dd++){
				if(dd!=d){
					for(int n=1;n<=4;n++){
						if(boardT[t][1+x+n*xl[dd]][1+y+n*yl[dd]]) break;
						if(qType[1-t][x+n*xl[dd]][y+n*yl[dd]].qTYPE<=T4::Q3d) factor++;
					}
					for(n=1;n<=4;n++){
						if(boardT[t][1+x+n*xr[dd]][1+y+n*yr[dd]]) break;
						if(qType[1-t][x+n*xr[dd]][y+n*yr[dd]].qTYPE<=T4::Q3d) factor++;
					}
				}
			}	
			value-=factor;
		}
	}
	return value;
}

void BoardN::DumpStaticEvaluate()
{
	fout<<" "<<step<<" - static: "<<StaticEvaluate()<<endl;
}



