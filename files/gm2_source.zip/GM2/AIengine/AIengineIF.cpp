#include "StdAfx.h"

#include "BoardN.h"
#include "AIengineIF.h"


AIengineIF AI;

/************************************************************************/
/* ���캯������������                                                   */
/************************************************************************/
AIengineIF::AIengineIF()
{


}


AIengineIF::~AIengineIF()
{

	
}


/************************************************************************/
/* ����ӿ�			                                                    */
/************************************************************************/
void AIengineIF::ReSet()
{
	boardN.reset();
}
void AIengineIF::PutStone(int i,int j)
{
	boardN.PutOne(i,j);
	//����
	boardN.DumpStaticEvaluate();
}
void AIengineIF::AIgo()
{
	boardN.AiGo();
}
bool AIengineIF::Back()
{
	return boardN.StepBack();
}
bool AIengineIF::Forward()
{
	return boardN.StepForward();
}
int AIengineIF::GetStoneNum()
{
	return boardN.GetCurrentStep();
}
CPos AIengineIF::GetCurrentPos()
{
	return boardN.GetCurrentP();
}
CPos AIengineIF::GetPos(int step)
{
	return boardN.GetPos(step);
}
bool AIengineIF::IsFill(int i,int j)
{
	return boardN.IsFill(i,j);
}
void AIengineIF::Hflip()
{
	boardN.Hflip();
}
void AIengineIF::Vflip()
{
	boardN.Vflip();
}
void AIengineIF::Rotate()
{
	boardN.Rotate();
}	
void AIengineIF::InitHashTable()
{
	boardN.inithashTable();
}
int AIengineIF::GetCurrentStep()
{
	return boardN.GetCurrentStep();
}

void AIengineIF::GetGameState(bool &gameover,bool &blackfoul)
{
	boardN.GetGameState(gameover,blackfoul);
}