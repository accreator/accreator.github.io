/*
 * ������
 */

/* c++ header */
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>


/* sel defined */
#include "History_Table.h"
#include "Pattern.h"
#include "HashPattern.h"
#include "Q8Pattern.h"
#include "SmartUnit.h"
#include "Board.h"
#include "BoardN.h"

#include "windows.h"


using namespace std;


void genstr(char *str)
{
	/*�õ�һ��5~15����*/
	int i=rand();
	i=i%11+5;

	for(int j=0;j<i;j++)
	{
		int r=rand()%2;
		if(r==0) str[j]='o';
		else str[j]='+';
	}
	
	str[i]=0;
}


int main()
{
	hash_pattern.GenerateHash();
//////////////////////////////////////////////////////////////////////////
//	������ʷ��
//////////////////////////////////////////////////////////////////////////
/*
	History_Table::Singleton();
	
	int rd;
	int totalnr=history_tbl->NodeNum();
	for(int i=0;i<totalnr/10;i++){
		rd=rand()*rand();
		History_Item *hitem=history_tbl->FindItem(rd,1);
		hitem->SetPHash(1);
	}
	history_tbl->GetStatistic();
*/

//////////////////////////////////////////////////////////////////////////
//	��������ģʽ�����
//////////////////////////////////////////////////////////////////////////
/*
	patternQ.Dump();
	//���Բ�ѯ
	int buf[256];
	int nr=patternQ.GetAllPattern(buf);
	for(int i=0;i<nr;i++)
	{
		PatternItem *it=patternQ.MatchPattern(buf[i]);
		if(it){
			cout<<i<<"\t";
			it->PrintPattern();
			cout<<"ok"<<endl;
		}
	}
	PatternItem *it=patternQ.MatchPattern("h+oho++h");
	if(it) it->PrintPattern();
*/
	
//////////////////////////////////////////////////////////////////////////
//	��������hash��
//////////////////////////////////////////////////////////////////////////

	//int start=GetTickCount();
	//int end=GetTickCount();
	//cout<<end-start<<endl;
	
/*
	ofstream fout("out.txt");	
	char strf[32]="h";
	char strh[32]="";
	//srand(100);
	for(int r=0;r<100;r++)
	{
		genstr(strh);
		strf[1]=0;
		strcat(strf,strh);
		strcat(strf,"h");
		fout<<strf<<endl;
		HashItem *hi=hash_pattern.QueryHuman(strh);
		int len=strlen(strh);
		for(int i=0;i<len;i++)
		{
			//cout<<(int)hi->qtype[i]<<" ";
			fout<<Q8Pattern::alias[hi->qtype[i]]<<" ";
		}
		fout<<endl<<endl;
	}
	fout.close();
*/
/*	
	//����Ե���
	//hash_pattern.GenerateHash();
	char strf[32]="h";
	char strh[32]="+++++++o+++++++";
	strf[1]=0;
	strcat(strf,strh);
	strcat(strf,"h");
	cout<<strf<<endl;
	//start=GetTickCount();
	for(int r=0;r<1;r++)
	{
		//HashItem *hi=hash_pattern.QueryHuman(strh);
		HashItem *hi=hash_pattern.Query(128,15);
		int len=strlen(strh);
		for(int i=0;i<len;i++)
		{
			cout<<Q8Pattern::alias[hi->qtype[i]]<<" ";
		}
		cout<<endl<<endl;
	}
	//end=GetTickCount();
	//cout<<end-start<<endl;
*/

//////////////////////////////////////////////////////////////////////////
//	����Board
//////////////////////////////////////////////////////////////////////////
/*
	for(int i=0;i<15;i++)
	{
		SmartUnit *unit=&board.unit[i][0];
		while(unit)
		{
			cout<<"* ";
			unit=unit->base_net.right;
		}
		cout<<endl;
	}
	for(i=0;i<15;i++)
	{
		SmartUnit *unit=&board.unit[0][i];
		while(unit)
		{
			cout<<"* ";
			unit=unit->base_net.down;
		}
		cout<<endl;
	}
*/

//////////////////////////////////////////////////////////////////////////
//	���Է��Ӻͻ����߼�
//////////////////////////////////////////////////////////////////////////
	/*
	board.reset();
	board.Putone(7,7);
	board.Putone(6,8);
	board.Putone(8,8);
	int start=GetTickCount(); 
	for(int i=0;i<10000;i++)
	{
		board.Putone(8,7);
		board.Back();
	}
	int end=GetTickCount();
	cout<<end-start<<endl;
	board.Putone(8,7);
	board.Putone(7,8);
	*/
	
	boardN.reset();
	boardN.Putone(7,7);
	boardN.Putone(6,8);
	boardN.Putone(8,8);
	int start=GetTickCount(); 
	for(int i=0;i<100000;i++)
	{
		boardN.Putone(8,7);
		boardN.Back();
	}
	int end=GetTickCount();
	cout<<end-start<<endl;
	boardN.Putone(8,7);
	boardN.Putone(7,8);

	boardN.dumpboard();
	boardN.dumpqtypeH();

	

	system("pause");

	return 0;
}


