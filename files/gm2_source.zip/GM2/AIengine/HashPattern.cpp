#include "StdAfx.h"

#include "HashPattern.h"
#include "Q8Pattern.h"

#include <iostream>
#include <cassert>
#include <cstdlib>

HashPattern hash_pattern;



using namespace std;

/************************************************************************/
/*          ������������                                                */
/************************************************************************/

int get1nr(int p)
{
	int num=0;
	while(p)
	{
		p&=(p-1);
		num++;
	}
	return num;
}
bool test1(int p,int index)
{
	return (p&(1<<index))>0;
}

/************************************************************************/
/*          HashItem                                                    */
/************************************************************************/
void HashItem::Print()
{
	for(int i=0;i<15;i++)
	{
		cout<<T1::alias[qtype[i]]<<" ";
	}
	cout<<endl;
}
void HashItem::Print(int len)
{
	for(int i=0;i<len;i++)
	{
		cout<<T1::alias[qtype[i]]<<" ";
	}
	cout<<endl;
}


/************************************************************************/
/*          HashPattern                                                 */
/************************************************************************/

HashPattern::HashPattern()
{
	phash[0]=hash1;
	phash[1]=hash2;
	phash[2]=hash3;
	phash[3]=hash4;
	phash[4]=hash5;
	phash[5]=hash6;
	phash[6]=hash7;
	phash[7]=hash8;
	phash[8]=hash9;
	phash[9]=hash10;
	phash[10]=hash11;
	phash[11]=hash12;
	phash[12]=hash13;
	phash[13]=hash14;
	phash[14]=hash15;

	memset(phash[0],0,sizeof(hash1));
	memset(phash[1],0,sizeof(hash2));
	memset(phash[2],0,sizeof(hash3));
	memset(phash[3],0,sizeof(hash4));
	memset(phash[4],0,sizeof(hash5));
	memset(phash[5],0,sizeof(hash6));
	memset(phash[6],0,sizeof(hash7));
	memset(phash[7],0,sizeof(hash8));
	memset(phash[8],0,sizeof(hash9));
	memset(phash[9],0,sizeof(hash10));
	memset(phash[10],0,sizeof(hash11));
	memset(phash[11],0,sizeof(hash12));
	memset(phash[12],0,sizeof(hash13));
	memset(phash[13],0,sizeof(hash14));
	memset(phash[14],0,sizeof(hash15));
}

HashPattern::~HashPattern()
{

}
void HashPattern::GenerateHash()
{
	/*hash1~hash4*/
	for(int pl=1;pl<=4;pl++)
	{
		int itemsnum=2;
		for(int i=1;i<pl;i++) itemsnum*=2;
		for(int pattern=0;pattern<itemsnum;pattern++){
			for(i=0;i<pl;i++)
			{
				if(test1(pattern,i)){
					phash[pl-1][pattern].qtype[pl-1-i]=T1::QFill;
				}else{
					phash[pl-1][pattern].qtype[pl-1-i]=T1::QNohope;
				}
			}			
		}
		
	}

	/*hash5����*/
	/*����hash5,hash5ֻ��32��*/
	for(int pattern=0;pattern<32;pattern++)
	{
		int nr=get1nr(pattern);

		int type;
		if(nr==0) type=T1::Q1;
		else if(nr==1) type=T1::Q2;
		else if(nr==2) type=T1::Q3;
		else if(nr==3) type=T1::Q4;
		else if(nr==4) type=T1::Q5;
		else if(nr==5) type=T1::Qx;
		else assert(0);

		for(int i=0;i<5;i++)
		{
			if(test1(pattern,i)){
				hash5[pattern].qtype[4-i]=T1::QFill;
			}
			else
			{
				hash5[pattern].qtype[4-i]=type;
			}
		}
	}

	
	int index[16];
	/*Ϊ���߼��������ҵ�������hash6*/
	/*hash6*/
	for(pattern=0;pattern<64;pattern++)
	{
		index[0]=pattern*3+2*64*3+2;
		Q8Item * it=q8pattern.GetQ8Item(index[0]);
		for(int i=1,j=0;i<=6;i++,j++)
		{
			hash6[pattern].qtype[j]=it->qtype[i];
		}
	}

	/* hash7 -- hash15 */
	for(int plen=7,itnr=2,size=128;plen<=15;plen++,itnr++,size=size*2)
	{
		for(pattern=0;pattern<size;pattern++)
		{
			/* ��ͷ��hxxxxxxx */
			int x=pattern>>(plen-7);
			index[0]=2*64*3+(x>>1)*3+(x&0x1); /* 2*192+x[6:1]*3+x[0]*/
			
			/* ��β��xxxxxxxh */
			x=pattern&0x7f;
			index[itnr-1]=(x>>6)*64*3+(x&0x3f)*3+2; /* x[6]*192+x[5:0]*3+x[0]+2*/
			
			/* �м����е�xxxxxxxx */
			for(int i=1;i<itnr-1;i++){
				x=(pattern>>(itnr-2-i))&0xff;
				index[i]=(x>>7)*192+((x>>1)&0x3f)*3+(x&0x01);	/* x[7]*192+x[6:1]*3+x[0] */
			}
			
			/* ��"��"*/
			CLEAR_MASK();
			for(i=0;i<itnr;i++)
			{
				Q8Item * it=q8pattern.GetQ8Item(index[i]);
				for(int j=0;j<8;j++)
				{
					qmask[i+j] |= q8pattern.GetQ8Mask(it->qtype[j]);
				}
			}
			for(i=1;i<=plen;i++)
			{
				phash[plen-1][pattern].qtype[i-1]=q8pattern.GetQ8Type(qmask[i]);
			}
		}
	}
	HashItem *it;
	//�м�������
	//?o+o+o+o? :+o+o+o+o+ 170 ho+o+o+oh 85 ho+o+o+o+ +o+o+o+oh  hash7~hash15
	//?o++oo+o? :+o++oo+o+ 154 ho++oo+oh 77 ho++oo+o+ +o++oo+oh 
	//?o+oo++o? :+o+oo++o+ 178 ho+oo++oh 89 ho+oo++o+ +o+oo++oh
	//hash7 
	//h..h
	it=Query(85,7);it->qtype[3]=T1::QFoul44;
	it=Query(77,7);it->qtype[2]=T1::QFoul44;
	it=Query(89,7);it->qtype[4]=T1::QFoul44;
	//hash8~hash15
	//x...h
	int ihash;
	for(int len=8;len<=15;len++){
		int k=1;
		for(int i=0;i<len-8;i++) k*=2;
		for(i=0;i<k;i++){
			ihash=(i<<8)+85;
			it=Query(ihash,len);
			it->qtype[4+len-8]=T1::QFoul44;

			ihash=(i<<8)+77;
			it=Query(ihash,len);
			it->qtype[3+len-8]=T1::QFoul44;

			ihash=(i<<8)+89;
			it=Query(ihash,len);
			it->qtype[5+len-8]=T1::QFoul44;
		}
	}
	//h...x
	for(len=8;len<=15;len++){
		int k=1;
		for(int i=0;i<len-8;i++) k*=2;
		for(i=0;i<k;i++){
			ihash=i+(170<<(len-8));
			it=Query(ihash,len);
			it->qtype[3]=T1::QFoul44;

			ihash=i+(154<<(len-8));
			it=Query(ihash,len);
			it->qtype[2]=T1::QFoul44;

			ihash=i+(178<<(len-8));
			it=Query(ihash,len);
			it->qtype[4]=T1::QFoul44;
		}
	}
	//x...x
	ihash=170;
	it=Query(ihash,9);
	it->qtype[4]=T1::QFoul44;
	
	ihash=154;
	it=Query(ihash,9);
	it->qtype[3]=T1::QFoul44;
	
	ihash=178;
	it=Query(ihash,9);
	it->qtype[5]=T1::QFoul44;	
	for(len=10;len<=15;len++){
		int ex=len-9;
		
		int kl,kr;
		int nl,nr;
		for(kl=0;kl<ex;kl++){
			kr=ex-kl;
			nl=1;
			nr=1;
			for(int kk=0;kk<kl;kk++) nl*=2;
			for(kk=0;kk<kr;kk++) nr*=2;
			
			for(int i=0;i<nl;i++){
				for(int j=0;j<nr;j++){
					ihash=j+(170<<kr)+(i<<(kr+9));
					it=Query(ihash,len);
					it->qtype[4+kl]=T1::QFoul44;

					ihash=j+(154<<kr)+(i<<(kr+9));
					it=Query(ihash,len);
					it->qtype[3+kl]=T1::QFoul44;

					ihash=j+(178<<kr)+(i<<(kr+9));
					it=Query(ihash,len);
					it->qtype[5+kl]=T1::QFoul44;
				}
			}
		}
	}
	
	//cout<<" calc completed! "<<endl;
}

HashItem* HashPattern::Query(int ihash,int level)	/*ͨ��һ������hashֵ��ѯ�������ģʽ*/
{
	assert(level>=1 && level<=15);
	//phash[level-5][ihash].Print(level);
	return &phash[level-1][ihash];
}
HashItem* HashPattern::QueryHuman(char *strhash) /*ͨ�����������strhash��ѯ��Ӧ��ģʽ*/
{
	int ihash=0;
	int level=strlen(strhash);
	assert(level>=1 && level<=15);
	for(int i=0;i<level;i++)
	{
		ihash=ihash<<1;
		if(strhash[i]=='o') ihash|=1;
	}
	return &phash[level-1][ihash];
}


/*
 hash pattern�о���

---hash5---
	����ģʽ��hxxxxxh
	���������߶����ˣ�Ҫô�ǶԷ�����Ҫô�Ǳ߽硣
	�����ڻ���������Ŀ��ܡ�
	������������1�ĸ������������Ϊ3
	��ô���������п�λ��qtype��ΪQ3������ʵ�ִ�ΪQFill

---hash6~hash15---
	��Ϊ����Ԥ�Ƚ�����Q8Pattern������hash6��hash15�Ĺ�������һ��

	hash6:
	hash6��Q8Pattern��һ������:
	hxxxxxxh

	hash7:
	hash7����ֱ�Ӵ�Q8Pattern�л��������𣬵��ǿ��Էֽ�����Σ�ÿ�ζ����Դ�Q8Pattern��ֱ�ӻ��
	hxxxxxxxh=
	hxxxxxxx	//��1
	 xxxxxxxh	//��2

	���Ƶģ�
	��hash8:
	hxxxxxxxxh
	hxxxxxxx
	 xxxxxxxx
	  xxxxxxxh

	��������

 */




