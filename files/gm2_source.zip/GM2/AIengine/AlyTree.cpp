 #include "StdAfx.h"
#include "BoardN.h"

#include <cassert>


#define WIN 1000	  //WinӮ
#define LOST -1000	  //��
#define MAYBE_WIN 500	  //Certain�ر�������Ψһ�⣬������������Ȳ�������ȷ��
#define MAYBE_LOST -500 
#define VAGUE	0
//����֮�ⶼ�Ǿ�̬����ֵ


#define TreeDepth 1
/************************************************************************/
/* Search                                                               */
/************************************************************************/
bool BoardN::Search(CPos &pos)
{
	ResetTree();
	//���ڵ�
	AlyNode *root=GetNode();;
	BuildTree(root);
	root->Evalucate();
	
	
	AlyNode *child=root->child;
	while(child){
		if(child->value==0-root->value) break;
		child=child->next;
	}
	assert(child!=0);

	pos.i=child->i;
	pos.j=child->j;

	return true;
}

/*���������غϵĻ�����������Ȼ��ʹ������������������õ�ͳ����Ϣ���ٶ������������չ*/
void BoardN::BuildTree(AlyNode *pnode)
{
	GetCands_ALL_H(current);
	GetCands_ALL_W(current);
	
	int k,r;
	AlyNode *node1=pnode;
	AlyNode *node2;
	bool firstchild=true;
	
	int t=step&01;
	
	if(listNnr[t][current][T4::Q5]){
		node2=GetNode();
		node2->i=listN[t][current][T4::Q5][t].i;
		node2->j=listN[t][current][T4::Q5][t].j;
		node2->value=WIN;
		Child(node1,node2);
		return;
	}else if(listNnr[1-t][current][T4::Q5]){
		node2=GetNode();
		node2->i=listN[1-t][current][T4::Q5][0].i;
		node2->j=listN[1-t][current][T4::Q5][0].j;
		node2->value=VAGUE;
		Child(node1,node2);
		return;
	}else if(listNnr[t][current][T4::Q4d]){
		node2=GetNode();
		node2->i=listN[t][current][T4::Q4d][0].i;
		node2->j=listN[t][current][T4::Q4d][0].j;
		node2->value=WIN;
		Child(node1,node2);
		return;
	}else{  /*˳�򣺼���Q43->Q4s,�Է�Q4d->Q4s,����Q4->Q3d���Է�Q4->Q3d*/
		for(k=T4::Q43;k<=T4::Q4s;k++){
			for(r=0;r<listNnr[t][current][k];r++){
				node2=GetNode();
				node2->i=listN[t][current][k][r].i;
				node2->j=listN[t][current][k][r].j;
				node2->value=VAGUE;
				if(firstchild==false){
					Chain(node1,node2);	
				}else{
					Child(node1,node2);
					firstchild=false;					
				}
				node1=node2;
			}
		}
		for(k=T4::Q43;k<=T4::Q4s;k++){
			for(r=0;r<listNnr[1-t][current][k];r++){
				node2=GetNode();
				node2->i=listN[1-t][current][k][r].i;
				node2->j=listN[1-t][current][k][r].j;
				node2->value=VAGUE;
				if(firstchild==false){
					Chain(node1,node2);	
				}else{
					Child(node1,node2);
					firstchild=false;					
				}
				node1=node2;
			}
		}
		for(k=T4::Q4;k<=T4::Q3d;k++){
			for(r=0;r<listNnr[t][current][k];r++){
				node2=GetNode();
				node2->i=listN[t][current][k][r].i;
				node2->j=listN[t][current][k][r].j;
				node2->value=VAGUE;
				if(firstchild==false){
					Chain(node1,node2);	
				}else{
					Child(node1,node2);
					firstchild=false;					
				}
				node1=node2;
			}
		}
		for(k=T4::Q4;k<=T4::Q3d;k++){
			for(r=0;r<listNnr[1-t][current][k];r++){
				node2=GetNode();
				node2->i=listN[1-t][current][k][r].i;
				node2->j=listN[1-t][current][k][r].j;
				node2->value=VAGUE;
				if(firstchild==false){
					Chain(node1,node2);	
				}else{
					Child(node1,node2);
					firstchild=false;					
				}
				node1=node2;
			}
		}
		//�����Ȳ�����
		for(k=T4::Q3;k<=T4::Q2d;k++){
			for(r=0;r<listNnr[t][current][k];r++){
				node2=GetNode();
				node2->i=listN[t][current][k][r].i;
				node2->j=listN[t][current][k][r].j;
				node2->value=VAGUE;
				if(firstchild==false){
					Chain(node1,node2);	
				}else{
					Child(node1,node2);
					firstchild=false;					
				}
				node1=node2;
			}
		}
//		for(k=T4::Q3;k<=T4::Q2d;k++){
//			for(r=0;r<listNnr[1-t][current][k];r++){
//				node2=GetNode();
//				node2->i=listN[1-t][current][k][r].i;
//				node2->j=listN[1-t][current][k][r].j;
//				node2->value=VAGUE;
//				if(firstchild==false){
//					Chain(node1,node2);	
//				}else{
//					Child(node1,node2);
//					firstchild=false;					
//				}
//				node1=node2;
//			}
//		}
	}


	if(search_depth<TreeDepth){
		node1=pnode->child;
		while(node1){
			Putone(node1->i,node1->j);
			BuildTree(node1);
			Back();
			node1=node1->next;
		}
	}
	//ָ���غ�֮�󣬵��þ�̬����������VCT����
	else{ 
		CPos pos;
		node1=pnode->child;
		while(node1){
			Putone(node1->i,node1->j);
//			if(t==1 && AttackH(pos)){
//				pnode->value=WIN;
//			}else if(t==0 && AttackW(pos)){
//				pnode->value=WIN;
//			}else{
				node1->value=StaticEvaluate();
//			}
			Back();
			node1=node1->next;
		}
	}
}




/************************************************************************/
/* GetCandidates                                                        */
/************************************************************************/
void BoardN::GetCands_ALL_H(int c)
{
	int i,j,t;
	for(i=0;i<T4::Q2;i++) listNnr[0][c][i]=0;
	for(i=0;i<=14;i++){
		for(j=0;j<=14;j++){	
			assert(TESTVALID(i,j));
			t=qType[0][i][j].qTYPE;
			if(t<T4::Q2) listN[0][c][t][listNnr[0][c][t]++]=CPos(i,j);
		}
	}
}
void BoardN::GetCands_ALL_W(int c)
{
	int i,j,t;
	for(i=0;i<T4::Q2;i++) listNnr[1][c][i]=0;
	for(i=0;i<=14;i++){
		for(j=0;j<=14;j++){	
			assert(TESTVALID(i,j));
			t=qType[1][i][j].qTYPE;
			if(t<T4::Q2) listN[1][c][t][listNnr[1][c][t]++]=CPos(i,j);
		}
	}	
}


