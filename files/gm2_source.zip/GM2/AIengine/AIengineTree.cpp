#include "StdAfx.h"
#include "BoardN.h"

#include <cassert>


#define TreeDepth 1
/************************************************************************/
/* Search                                                               */
/************************************************************************/
bool BoardN::Search(CPos &pos)
{
	ResetTree();
	//���ڵ�
	AlyNode *root=GetNode();;
	BuildTree(root);
	root->Evalucate();
	
	
	AlyNode *child=root->child;
	while(child){
		if(child->value==0-root->value) break;
		child=child->next;
	}
	assert(child!=0);

	pos.i=child->i;
	pos.j=child->j;

	return true;
}

/*���������غϵĻ�����������Ȼ��ʹ������������������õ�ͳ����Ϣ���ٶ������������չ*/
void BoardN::BuildTree(AlyNode *pnode)
{

}

/************************************************************************/
/* GetCandidates                                                        */
/************************************************************************/
void BoardN::GetCands_ALL_H(int c)
{
	int i,j,t;
	for(i=0;i<T4::Q2;i++) listNnr[0][c][i]=0;
	for(i=0;i<=14;i++){
		for(j=0;j<=14;j++){	
			assert(TESTVALID(i,j));
			t=qType[0][i][j].qTYPE;
			if(t<T4::Q2) listN[0][c][t][listNnr[0][c][t]++]=CPos(i,j);
		}
	}
}
void BoardN::GetCands_ALL_W(int c)
{
	int i,j,t;
	for(i=0;i<T4::Q2;i++) listNnr[1][c][i]=0;
	for(i=0;i<=14;i++){
		for(j=0;j<=14;j++){	
			assert(TESTVALID(i,j));
			t=qType[1][i][j].qTYPE;
			if(t<T4::Q2) listN[1][c][t][listNnr[1][c][t]++]=CPos(i,j);
		}
	}	
}


