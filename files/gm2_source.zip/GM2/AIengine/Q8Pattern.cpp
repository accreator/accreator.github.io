#include "StdAfx.h"

#include "Q8Pattern.h"

#include <iostream>
#include <fstream>
#include <cassert>
#include <string>
#include <cstdlib>
#include <cstring>

using namespace std;


Q8Pattern q8pattern;

Q8Pattern::Q8Pattern()
{
	for(int i=0;i<16;i++) qmask[i]=0xffff>>(16-i);
}

Q8Pattern::~Q8Pattern()
{
	
}

UINT_16 Q8Pattern::GetQ8Type(UINT_16 mask)
{
	int num=0;
	while(mask)
	{
		num++;
		mask=mask>>1;
	}
	//assert();
	if(num==Qx) num=QLong;
	return num;
}

/************************************************************************/
/* ������ܽ���Ĵ�˵�е�576�ֻ�������                                  */
/************************************************************************/
Q8Item Q8Pattern::q8items[]=
{
	{"++++++++",{Qx,Q1,Q1,Q1,Q1,Q1,Q1,Qx}},
	{"+++++++o",{Qx,Q1,Q1,Q1,Q1,Q1,Qx,QFill}},
	{"+++++++h",{Qx,Q1,Q1,Q1,Q1,Q1,Q1,QFill}},
	{"++++++o+",{Qx,Qx,Q2,Q2,Q2,Q2,QFill,Qx}},
	{"++++++oo",{Qx,Qx,Qx,Qx,Qx,Qx,QFill,QFill}},
	{"++++++oh",{Qx,Qx,Q2,Q2,Q2,Q2,QFill,QFill}},
	{"+++++o++",{Qx,Q2,Q2d,Q2d,Q2d,QFill,Q2,Qx}},
	{"+++++o+o",{Qx,Q2,Q2,Q2,Q2,QFill,Qx,QFill}},
	{"+++++o+h",{Qx,Q2,Q2d,Q2d,Q2d,QFill,Q2,QFill}},
	{"+++++oo+",{Qx,Qx,Q3,Q3,Q3,QFill,QFill,Qx}},
	{"+++++ooo",{Qx,Qx,Qx,Qx,Qx,QFill,QFill,QFill}},
	{"+++++ooh",{Qx,Qx,Q3,Q3,Q3,QFill,QFill,QFill}},
	{"++++o+++",{Qx,Q2,Q2d,Q2d,QFill,Q2d,Q2,Qx}},
	{"++++o++o",{Qx,Q2,Q2,Q2,QFill,Q2,Qx,QFill}},
	{"++++o++h",{Qx,Q2,Q2d,Q2d,QFill,Q2d,Q2,QFill}},
	{"++++o+o+",{Qx,Qx,Q3,Q3,QFill,Q3,QFill,Qx}},
	{"++++o+oo",{Qx,Qx,Qx,Qx,QFill,Qx,QFill,QFill}},
	{"++++o+oh",{Qx,Qx,Q3,Q3,QFill,Q3,QFill,QFill}},
	{"++++oo++",{Qx,Q3,Q3d,Q3d,QFill,QFill,Q3,Qx}},
	{"++++oo+o",{Qx,Q3,Q3,Q3,QFill,QFill,Qx,QFill}},
	{"++++oo+h",{Qx,Q3,Q3d,Q3d,QFill,QFill,Q3,QFill}},
	{"++++ooo+",{Qx,Qx,Q4,Q4,QFill,QFill,QFill,Qx}},
	{"++++oooo",{Qx,Qx,Qx,Qx,QFill,QFill,QFill,QFill}},
	{"++++oooh",{Qx,Qx,Q4,Q4,QFill,QFill,QFill,QFill}},
	{"+++o++++",{Qx,Q2,Q2d,QFill,Q2d,Q2d,Q2,Qx}},
	{"+++o+++o",{Qx,Q2,Q2,QFill,Q2,Q2,Qx,QFill}},
	{"+++o+++h",{Qx,Q2,Q2d,QFill,Q2d,Q2d,Q2,QFill}},
	{"+++o++o+",{Qx,Qx,Q3,QFill,Q3,Q3,QFill,Qx}},
	{"+++o++oo",{Qx,Qx,Qx,QFill,Qx,Qx,QFill,QFill}},
	{"+++o++oh",{Qx,Qx,Q3,QFill,Q3,Q3,QFill,QFill}},
	{"+++o+o++",{Qx,Q3,Q3d,QFill,Q3d,QFill,Q3,Qx}},
	{"+++o+o+o",{Qx,Q3,Q3,QFill,Q3,QFill,Qx,QFill}},
	{"+++o+o+h",{Qx,Q3,Q3d,QFill,Q3d,QFill,Q3,QFill}},
	{"+++o+oo+",{Qx,Qx,Q4,QFill,Q4,QFill,QFill,Qx}},
	{"+++o+ooo",{Qx,Qx,Qx,QFill,Qx,QFill,QFill,QFill}},
	{"+++o+ooh",{Qx,Qx,Q4,QFill,Q4,QFill,QFill,QFill}},
	{"+++oo+++",{Qx,Q3,Q3d,QFill,QFill,Q3d,Q3,Qx}},
	{"+++oo++o",{Qx,Q3,Q3,QFill,QFill,Q3,Qx,QFill}},
	{"+++oo++h",{Qx,Q3,Q3d,QFill,QFill,Q3d,Q3,QFill}},
	{"+++oo+o+",{Qx,Qx,Q4,QFill,QFill,Q4,QFill,Qx}},
	{"+++oo+oo",{Qx,Qx,Qx,QFill,QFill,Qx,QFill,QFill}},
	{"+++oo+oh",{Qx,Qx,Q4,QFill,QFill,Q4,QFill,QFill}},
	{"+++ooo++",{Qx,Q4,Q4d,QFill,QFill,QFill,Q4,Qx}},
	{"+++ooo+o",{Qx,Qx,Q4,QFill,QFill,QFill,Qx,QFill}},
	{"+++ooo+h",{Qx,Q4,Q4d,QFill,QFill,QFill,Q4,QFill}},
	{"+++oooo+",{Qx,Qx,Q5,QFill,QFill,QFill,QFill,Qx}},
	{"+++ooooo",{Qx,Qx,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"+++ooooh",{Qx,Qx,Q5,QFill,QFill,QFill,QFill,QFill}},
	{"++o+++++",{Qx,Q2,QFill,Q2d,Q2d,Q2d,Q2,Qx}},
	{"++o++++o",{Qx,Q2,QFill,Q2,Q2,Q2,Qx,QFill}},
	{"++o++++h",{Qx,Q2,QFill,Q2d,Q2d,Q2d,Q2,QFill}},
	{"++o+++o+",{Qx,Qx,QFill,Q3,Q3,Q3,QFill,Qx}},
	{"++o+++oo",{Qx,Qx,QFill,Qx,Qx,Qx,QFill,QFill}},
	{"++o+++oh",{Qx,Q3,QFill,Q3,Q3,Q3,QFill,QFill}},
	{"++o++o++",{Qx,Q3,QFill,Q3d,Q3d,QFill,Q3,Qx}},
	{"++o++o+o",{Qx,Q3,QFill,Q3,Q3,QFill,Qx,QFill}},
	{"++o++o+h",{Qx,Q3,QFill,Q3d,Q3d,QFill,Q3,QFill}},
	{"++o++oo+",{Qx,Qx,QFill,Q4,Q4,QFill,QFill,Qx}},
	{"++o++ooo",{Qx,Qx,QFill,Qx,Qx,QFill,QFill,QFill}},
	{"++o++ooh",{Qx,Qx,QFill,Q4,Q4,QFill,QFill,QFill}},
	{"++o+o+++",{Qx,Q3,QFill,Q3d,QFill,Q3d,Q3,Qx}},
	{"++o+o++o",{Qx,Q3,QFill,Q3,QFill,Q3,Qx,QFill}},
	{"++o+o++h",{Qx,Q3,QFill,Q3d,QFill,Q3d,Q3,QFill}},
	{"++o+o+o+",{Qx,Qx,QFill,Q4,QFill,Q4,QFill,Qx}},
	{"++o+o+oo",{Qx,Qx,QFill,Qx,QFill,Qx,QFill,QFill}},
	{"++o+o+oh",{Qx,Qx,QFill,Q4,QFill,Q4,QFill,QFill}},
	{"++o+oo++",{Qx,Q4,QFill,Q4d,QFill,QFill,Q4,Qx}},
	{"++o+oo+o",{Qx,Q4,QFill,Q4,QFill,QFill,Qx,QFill}},
	{"++o+oo+h",{Qx,Q4,QFill,Q4d,QFill,QFill,Q4,QFill}},
	{"++o+ooo+",{Qx,Qx,QFill,Q5,QFill,QFill,QFill,Qx}},
	{"++o+oooo",{Qx,Qx,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"++o+oooh",{Qx,Qx,QFill,Q5,QFill,QFill,QFill,QFill}},
	{"++oo++++",{Qx,Q3,QFill,QFill,Q3d,Q3d,Q3,Qx}},
	{"++oo+++o",{Qx,Q3,QFill,QFill,Q3,Q3,Qx,QFill}},
	{"++oo+++h",{Qx,Qx,QFill,QFill,Q3d,Q3d,Q3,QFill}},
	{"++oo++o+",{Qx,Qx,QFill,QFill,Q4,Q4,QFill,Qx}},
	{"++oo++oo",{Qx,Qx,QFill,QFill,Qx,Qx,QFill,QFill}},
	{"++oo++oh",{Qx,Qx,QFill,QFill,Q4,Q4,QFill,QFill}},
	{"++oo+o++",{Qx,Q4,QFill,QFill,Q4d,QFill,Q4,Qx}},
	{"++oo+o+o",{Qx,Q4,QFill,QFill,Q4,QFill,Qx,QFill}},
	{"++oo+o+h",{Qx,Qx,QFill,QFill,Q4,QFill,Q4,QFill}},
	{"++oo+oo+",{Qx,Qx,QFill,QFill,Q5,QFill,QFill,Qx}},
	{"++oo+ooo",{Qx,Qx,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"++oo+ooh",{Qx,Qx,QFill,QFill,Q5,QFill,QFill,QFill}},
	{"++ooo+++",{Qx,Q4,QFill,QFill,QFill,Q4d,Q4,Qx}},
	{"++ooo++o",{Qx,Q4,QFill,QFill,QFill,Q4,Qx,QFill}},
	{"++ooo++h",{Qx,Q4,QFill,QFill,QFill,Q4d,Q4,QFill}},
	{"++ooo+o+",{Qx,Qx,QFill,QFill,QFill,Q5,QFill,Qx}},
	{"++ooo+oo",{Qx,Qx,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"++ooo+oh",{Qx,Qx,QFill,QFill,QFill,Q5,QFill,QFill}},
	{"++oooo++",{Qx,Q5,QFill,QFill,QFill,QFill,Q5,Qx}},
	{"++oooo+o",{Qx,Q5,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"++oooo+h",{Qx,Q5,QFill,QFill,QFill,QFill,Q5,QFill}},
	{"++ooooo+",{Qx,QDead,QFill,QFill,QFill,QFill,QFill,QDead}},
	{"++oooooo",{Qx,QDead,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"++oooooh",{Qx,QDead,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"+o++++++",{Qx,QFill,Q2,Q2,Q2,Q2,Qx,Qx}},
	{"+o+++++o",{Qx,QFill,Q2,Q2,Q2,Q2,Qx,QFill}},
	{"+o+++++h",{Qx,QFill,Q2,Q2,Q2,Q2,QLong,QFill}},
	{"+o++++o+",{Qx,QFill,Qx,Qx,Qx,Qx,QFill,Qx}},
	{"+o++++oo",{Qx,QFill,Qx,Qx,Qx,Qx,QFill,QFill}},
	{"+o++++oh",{Qx,QFill,Qx,Qx,Qx,QLong,QFill,QFill}},
	{"+o+++o++",{Qx,QFill,Q3,Q3,Q3,QFill,Qx,Qx}},
	{"+o+++o+o",{Qx,QFill,Q3,Q3,Q3,QFill,Qx,QFill}},
	{"+o+++o+h",{Qx,QFill,Q3,Q3,Q3,QFill,QLong,QFill}},
	{"+o+++oo+",{Qx,QFill,Qx,Qx,Qx,QFill,QFill,Qx}},
	{"+o+++ooo",{Qx,QFill,Qx,Qx,Qx,QFill,QFill,QFill}},
	{"+o+++ooh",{Qx,QFill,Qx,Qx,QLong,QFill,QFill,QFill}},
	{"+o++o+++",{Qx,QFill,Qx,Qx,QFill,Qx,Qx,Qx}},
	{"+o++o++o",{Qx,QFill,Q3,Q3,QFill,Q3,Qx,QFill}},
	{"+o++o++h",{Qx,QFill,Q3,Q3,QFill,Q3,QLong,QFill}},
	{"+o++o+o+",{Qx,QFill,Qx,Qx,QFill,Qx,QFill,Qx}},
	{"+o++o+oo",{Qx,QFill,Qx,Qx,QFill,Qx,QFill,QFill}},
	{"+o++o+oh",{Qx,QFill,Qx,Qx,QFill,QLong,QFill,QFill}},
	{"+o++oo++",{Qx,QFill,Q4,Q4,QFill,QFill,Qx,Qx}},
	{"+o++oo+o",{Qx,QFill,Q4,Q4,QFill,QFill,Qx,QFill}},
	{"+o++oo+h",{Qx,QFill,Q4,Q4,QFill,QFill,QLong,QFill}},
	{"+o++ooo+",{Qx,QFill,Qx,Qx,QFill,QFill,QFill,Qx}},
	{"+o++oooo",{Qx,QFill,Qx,Qx,QFill,QFill,QFill,QFill}},
	{"+o++oooh",{Qx,QFill,Qx,QLong,QFill,QFill,QFill,QFill}},
	{"+o+o++++",{Qx,QFill,Qx,QFill,Qx,Qx,Qx,Qx}},
	{"+o+o+++o",{Qx,QFill,Q3,QFill,Q3,Q3,Qx,QFill}},
	{"+o+o+++h",{Qx,QFill,Q3,QFill,Q3,Q3,QLong,QFill}},
	{"+o+o++o+",{Qx,QFill,Qx,QFill,Qx,Qx,QFill,Qx}},
	{"+o+o++oo",{Qx,QFill,Qx,QFill,Qx,Qx,QFill,QFill}},
	{"+o+o++oh",{Qx,QFill,Qx,QFill,Qx,QLong,QFill,QFill}},
	{"+o+o+o++",{Qx,QFill,Q4,QFill,Q4,QFill,Qx,Qx}},
	{"+o+o+o+o",{Qx,QFill,Q4,QFill,Q4,QFill,Qx,QFill}},
	{"+o+o+o+h",{Qx,QFill,Q4,QFill,Q4,QFill,QLong,QFill}},
	{"+o+o+oo+",{Qx,QFill,Qx,QFill,Qx,QFill,QFill,Qx}},
	{"+o+o+ooo",{Qx,QFill,Qx,QFill,Qx,QFill,QFill,QFill}},
	{"+o+o+ooh",{Qx,QFill,Qx,QFill,QLong,QFill,QFill,QFill}},
	{"+o+oo+++",{Qx,QFill,Q4,QFill,QFill,Q4,Qx,Qx}},
	{"+o+oo++o",{Qx,QFill,Q4,QFill,QFill,Q4,Qx,QFill}},
	{"+o+oo++h",{Qx,QFill,Q4,QFill,QFill,Q4,QLong,QFill}},
	{"+o+oo+o+",{Qx,QFill,Qx,QFill,QFill,Qx,QFill,Qx}},
	{"+o+oo+oo",{Qx,QFill,Qx,QFill,QFill,Qx,QFill,QFill}},
	{"+o+oo+oh",{Qx,QFill,Qx,QFill,QFill,QLong,QFill,QFill}},
	{"+o+ooo++",{Qx,QFill,Q5,QFill,QFill,QFill,Qx,Qx}},
	{"+o+ooo+o",{Qx,QFill,Qx,QFill,QFill,QFill,Qx,QFill}},
	{"+o+ooo+h",{Qx,QFill,Q5,QFill,QFill,QFill,QLong,QFill}},
	{"+o+oooo+",{Qx,QFill,QDead,QFill,QFill,QFill,QFill,Qx}},
	{"+o+ooooo",{Qx,QFill,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"+o+ooooh",{Qx,QFill,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"+oo+++++",{Qx,QFill,QFill,Q3,Q3,Q3,Qx,Qx}},
	{"+oo++++o",{Qx,QFill,QFill,Q3,Q3,Q3,Qx,QFill}},
	{"+oo++++h",{Qx,QFill,QFill,Q3,Q3,Q3,QLong,QFill}},
	{"+oo+++o+",{Qx,QFill,QFill,Qx,Qx,Qx,QFill,Qx}},
	{"+oo+++oo",{Qx,QFill,QFill,Qx,Qx,Qx,QFill,QFill}},
	{"+oo+++oh",{Qx,QFill,QFill,Qx,Qx,QLong,QFill,QFill}},
	{"+oo++o++",{Qx,QFill,QFill,Q4,Q4,QFill,Qx,Qx}},
	{"+oo++o+o",{Qx,QFill,QFill,Q4,Q4,QFill,Qx,QFill}},
	{"+oo++o+h",{Qx,QFill,QFill,Q4,Q4,QFill,QLong,QFill}},
	{"+oo++oo+",{Qx,QFill,QFill,Qx,Qx,QFill,QFill,Qx}},
	{"+oo++ooo",{Qx,QFill,QFill,Qx,Qx,QFill,QFill,QFill}},
	{"+oo++ooh",{Qx,QFill,QFill,Qx,QLong,QFill,QFill,QFill}},
	{"+oo+o+++",{Qx,QFill,QFill,Q4,QFill,Q4,Qx,Qx}},
	{"+oo+o++o",{Qx,QFill,QFill,Q4,QFill,Q4,Qx,QFill}},
	{"+oo+o++h",{Qx,QFill,QFill,Q4,QFill,Q4,QLong,QFill}},
	{"+oo+o+o+",{Qx,QFill,QFill,Qx,QFill,Qx,QFill,Qx}},
	{"+oo+o+oo",{Qx,QFill,QFill,Qx,QFill,Qx,QFill,QFill}},
	{"+oo+o+oh",{Qx,QFill,QFill,Qx,QFill,QLong,QFill,QFill}},
	{"+oo+oo++",{Qx,QFill,QFill,Q5,QFill,QFill,Qx,Qx}},
	{"+oo+oo+o",{Qx,QFill,QFill,Q5,QFill,QFill,Qx,QFill}},
	{"+oo+oo+h",{Qx,QFill,QFill,Q5,QFill,QFill,QLong,QFill}},
	{"+oo+ooo+",{Qx,QFill,QFill,QDead,QFill,QFill,QFill,Qx}},
	{"+oo+oooo",{Qx,QFill,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"+oo+oooh",{Qx,QFill,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"+ooo++++",{Qx,QFill,QFill,QFill,Q4,Q4,Qx,Qx}},
	{"+ooo+++o",{Qx,QFill,QFill,QFill,Q4,Q4,Qx,QFill}},
	{"+ooo+++h",{Qx,QFill,QFill,QFill,Q4,Q4,QLong,QFill}},
	{"+ooo++o+",{Qx,QFill,QFill,QFill,Qx,Qx,QFill,Qx}},
	{"+ooo++oo",{Qx,QFill,QFill,QFill,Qx,Qx,QFill,QFill}},
	{"+ooo++oh",{Qx,QFill,QFill,QFill,Qx,QLong,QFill,QFill}},
	{"+ooo+o++",{Qx,QFill,QFill,QFill,Q5,QFill,Qx,Qx}},
	{"+ooo+o+o",{Qx,QFill,QFill,QFill,Q5,QFill,Qx,QFill}},
	{"+ooo+o+h",{Qx,QFill,QFill,QFill,Q5,QFill,QLong,QFill}},
	{"+ooo+oo+",{Qx,QFill,QFill,QFill,QDead,QFill,QFill,Qx}},
	{"+ooo+ooo",{Qx,QFill,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"+ooo+ooh",{Qx,QFill,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"+oooo+++",{Qx,QFill,QFill,QFill,QFill,Q5,Qx,Qx}},
	{"+oooo++o",{Qx,QFill,QFill,QFill,QFill,Q5,Qx,QFill}},
	{"+oooo++h",{Qx,QFill,QFill,QFill,QFill,Q5,QLong,QFill}},
	{"+oooo+o+",{Qx,QFill,QFill,QFill,QFill,QDead,QFill,Qx}},
	{"+oooo+oo",{Qx,QFill,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"+oooo+oh",{Qx,QFill,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"+ooooo++",{QDead,QFill,QFill,QFill,QFill,QFill,QDead,Qx}},
	{"+ooooo+o",{QDead,QFill,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"+ooooo+h",{Qx,QFill,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"+oooooo+",{QDead,QFill,QFill,QFill,QFill,QFill,QFill,QDead}},
	{"+ooooooo",{QDead,QFill,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"+ooooooh",{QDead,QFill,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"o+++++++",{QFill,Qx,Q1,Q1,Q1,Q1,Q1,Qx}},
	{"o++++++o",{QFill,Q1,Qx,Qx,Qx,Qx,Q1,QFill}},
	{"o++++++h",{QFill,Qx,Q1,Q1,Q1,Q1,Q1,QFill}},
	{"o+++++o+",{QFill,Qx,Q2,Q2,Q2,Q2,QFill,Qx}},
	{"o+++++oo",{QFill,Q1,Qx,Qx,Qx,Qx,QFill,QFill}},
	{"o+++++oh",{QFill,Qx,Q2,Q2,Q2,Q2,QFill,QFill}},
	{"o++++o++",{QFill,Qx,Q2,Q2,Q2,QFill,Q2,Qx}},
	{"o++++o+o",{QFill,Q1,Qx,Qx,Qx,QFill,Qx,QFill}},
	{"o++++o+h",{QFill,Qx,Q2,Q2,Q2,QFill,Q2,QFill}},
	{"o++++oo+",{QFill,Qx,Q3,Q3,Q3,QFill,QFill,Qx}},
	{"o++++ooo",{QFill,Q1,Qx,Qx,Qx,QFill,QFill,QFill}},
	{"o++++ooh",{QFill,Qx,Q3,Q3,Q3,QFill,QFill,QFill}},
	{"o+++o+++",{QFill,Qx,Q2,Q2,QFill,Q2,Q2,Qx}},
	{"o+++o++o",{QFill,Qx,Qx,Qx,QFill,Qx,Qx,QFill}},
	{"o+++o++h",{QFill,Qx,Q2,Q2,QFill,Q2,Q2,QFill}},
	{"o+++o+o+",{QFill,Qx,Q3,Q3,QFill,Q3,QFill,Qx}},
	{"o+++o+oo",{QFill,Qx,Qx,Qx,QFill,Qx,QFill,QFill}},
	{"o+++o+oh",{QFill,Qx,Q3,Q3,QFill,Q3,QFill,QFill}},
	{"o+++oo++",{QFill,Q3,Q3d,Q3d,QFill,QFill,Q3d,Qx}},
	{"o+++oo+o",{QFill,Qx,Qx,Qx,QFill,QFill,Qx,QFill}},
	{"o+++oo+h",{QFill,Qx,Q3,Q3,QFill,QFill,Q3,QFill}},
	{"o+++ooo+",{QFill,Qx,Q4,Q4,QFill,QFill,QFill,Qx}},
	{"o+++oooo",{QFill,Qx,Qx,Qx,QFill,QFill,QFill,QFill}},
	{"o+++oooh",{QFill,Qx,Q4,Q4,QFill,QFill,QFill,QFill}},
	{"o++o++++",{QFill,Qx,Q2,QFill,Q2,Q2,Q2,Qx}},
	{"o++o+++o",{QFill,Qx,Qx,QFill,Qx,Qx,Qx,QFill}},
	{"o++o+++h",{QFill,Qx,Q2,QFill,Q2,Q2,Q2,QFill}},
	{"o++o++o+",{QFill,Qx,Q3,QFill,Q3,Q3,QFill,Qx}},
	{"o++o++oo",{QFill,Qx,Qx,QFill,Qx,Qx,QFill,QFill}},
	{"o++o++oh",{QFill,Qx,Q3,QFill,Q3,Q3,QFill,QFill}},
	{"o++o+o++",{QFill,Qx,Q3,QFill,Q3,QFill,Q3,Qx}},
	{"o++o+o+o",{QFill,Qx,Qx,QFill,Qx,QFill,Qx,QFill}},
	{"o++o+o+h",{QFill,Qx,Q3,QFill,Q3,QFill,Q3,QFill}},
	{"o++o+oo+",{QFill,Qx,Q4,QFill,Q4,QFill,QFill,Qx}},
	{"o++o+ooo",{QFill,Qx,Qx,QFill,Qx,QFill,QFill,QFill}},
	{"o++o+ooh",{QFill,Qx,Q4,QFill,Q4,QFill,QFill,QFill}},
	{"o++oo+++",{QFill,Qx,Q3,QFill,QFill,Q3,Q3,Qx}},
	{"o++oo++o",{QFill,Qx,Qx,QFill,QFill,Qx,Qx,QFill}},
	{"o++oo++h",{QFill,Qx,Q3,QFill,QFill,Q3,Q3,QFill}},
	{"o++oo+o+",{QFill,Qx,Q4,QFill,QFill,Q4,QFill,Qx}},
	{"o++oo+oo",{QFill,Qx,Qx,QFill,QFill,Qx,QFill,QFill}},
	{"o++oo+oh",{QFill,Qx,Q4,QFill,QFill,Q4,QFill,QFill}},
	{"o++ooo++",{QFill,Qx,Q4,QFill,QFill,QFill,Q4,Qx}},
	{"o++ooo+o",{QFill,Qx,Qx,QFill,QFill,QFill,Qx,QFill}},
	{"o++ooo+h",{QFill,Qx,Q4,QFill,QFill,QFill,Q4,QFill}},
	{"o++oooo+",{QFill,Qx,Q5,QFill,QFill,QFill,QFill,Qx}},
	{"o++ooooo",{QFill,Qx,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"o++ooooh",{QFill,Qx,Q5,QFill,QFill,QFill,QFill,QFill}},
	{"o+o+++++",{QFill,Qx,QFill,Q2,Q2,Q2,Q2,Qx}},
	{"o+o++++o",{QFill,Qx,QFill,Qx,Qx,Qx,Qx,QFill}},
	{"o+o++++h",{QFill,Qx,QFill,Q2,Q2,Q2,Q2,QFill}},
	{"o+o+++o+",{QFill,Qx,QFill,Q3,Q3,Q3,QFill,Qx}},
	{"o+o+++oo",{QFill,Qx,QFill,Qx,Qx,Qx,QFill,QFill}},
	{"o+o+++oh",{QFill,Qx,QFill,Q3,Q3,Q3,QFill,QFill}},
	{"o+o++o++",{QFill,Qx,QFill,Q3,Q3,QFill,Q3,Qx}},
	{"o+o++o+o",{QFill,Qx,QFill,Qx,Qx,QFill,Qx,QFill}},
	{"o+o++o+h",{QFill,Qx,QFill,Q3,Q3,QFill,Q3,QFill}},
	{"o+o++oo+",{QFill,Qx,QFill,Q4,Q4,QFill,QFill,Qx}},
	{"o+o++ooo",{QFill,Qx,QFill,Qx,Qx,QFill,QFill,QFill}},
	{"o+o++ooh",{QFill,Qx,QFill,Q4,Q4,QFill,QFill,QFill}},
	{"o+o+o+++",{QFill,Qx,QFill,Q3,QFill,Q3,Q3,Qx}},
	{"o+o+o++o",{QFill,Qx,QFill,QDead,QFill,Qx,Qx,QFill}},
	{"o+o+o++h",{QFill,Qx,QFill,Q3,QFill,Q3,Q3,QFill}},
	{"o+o+o+o+",{QFill,Qx,QFill,Q4,QFill,Q4,QFill,Qx}},
	{"o+o+o+oo",{QFill,Qx,QFill,Qx,QFill,Qx,QFill,QFill}},
	{"o+o+o+oh",{QFill,Qx,QFill,Q4,QFill,Q4,QFill,QFill}},
	{"o+o+oo++",{QFill,Qx,QFill,Q4,QFill,QFill,Q4,Qx}},
	{"o+o+oo+o",{QFill,Qx,QFill,QLong,QFill,QFill,Qx,QFill}},
	{"o+o+oo+h",{QFill,Qx,QFill,Q4,QFill,QFill,Q4,QFill}},
	{"o+o+ooo+",{QFill,Qx,QFill,Q5,QFill,QFill,QFill,Qx}},
	{"o+o+oooo",{QFill,Qx,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"o+o+oooh",{QFill,Qx,QFill,Q5,QFill,QFill,QFill,QFill}},
	{"o+oo++++",{QFill,Qx,QFill,QFill,Q3,Q3,Q3,Qx}},
	{"o+oo+++o",{QFill,Qx,QFill,QFill,Qx,Qx,Qx,QFill}},
	{"o+oo+++h",{QFill,Qx,QFill,QFill,Q3,Q3,Q3,QFill}},
	{"o+oo++o+",{QFill,Qx,QFill,QFill,Q4,Q4,QFill,Qx}},
	{"o+oo++oo",{QFill,Qx,QFill,QFill,Qx,Qx,QFill,QFill}},
	{"o+oo++oh",{QFill,Qx,QFill,QFill,Q4,Q4,QFill,QFill}},
	{"o+oo+o++",{QFill,Qx,QFill,QFill,Q4,QFill,Q4,Qx}},
	{"o+oo+o+o",{QFill,Qx,QFill,QFill,QLong,QFill,Qx,QFill}},
	{"o+oo+o+h",{QFill,Qx,QFill,QFill,Q4,QFill,Q4,QFill}},
	{"o+oo+oo+",{QFill,Qx,QFill,QFill,Q5,QFill,QFill,Qx}},
	{"o+oo+ooo",{QFill,Qx,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"o+oo+ooh",{QFill,Qx,QFill,QFill,Q5,QFill,QFill,QFill}},
	{"o+ooo+++",{QFill,Qx,QFill,QFill,QFill,Q4,Q4,Qx}},
	{"o+ooo++o",{QFill,Qx,QFill,QFill,QFill,QLong,Qx,QFill}},
	{"o+ooo++h",{QFill,Qx,QFill,QFill,QFill,Q4,Q4,QFill}},
	{"o+ooo+o+",{QFill,Qx,QFill,QFill,QFill,Q5,QFill,Qx}},
	{"o+ooo+oo",{QFill,Qx,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"o+ooo+oh",{QFill,Qx,QFill,QFill,QFill,Q5,QFill,QFill}},
	{"o+oooo++",{QFill,Qx,QFill,QFill,QFill,QFill,Q5,Qx}},
	{"o+oooo+o",{QFill,Qx,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"o+oooo+h",{QFill,Qx,QFill,QFill,QFill,QFill,Q5,QFill}},
	{"o+ooooo+",{QFill,QDead,QFill,QFill,QFill,QFill,QFill,QDead}},
	{"o+oooooo",{QFill,QDead,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"o+oooooh",{QFill,QDead,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"oo++++++",{QFill,QFill,Qx,Qx,Qx,Qx,Qx,Q1}},
	{"oo+++++o",{QFill,QFill,Qx,Qx,Qx,Qx,Qx,QFill}},
	{"oo+++++h",{QFill,QFill,Qx,Qx,Qx,QLong,QLong,QFill}},
	{"oo++++o+",{QFill,QFill,Qx,Qx,Qx,Qx,QFill,Qx}},
	{"oo++++oo",{QFill,QFill,Qx,Qx,Qx,Qx,QFill,QFill}},
	{"oo++++oh",{QFill,QFill,Qx,Qx,Qx,QLong,QFill,QFill}},
	{"oo+++o++",{QFill,QFill,Qx,Qx,Qx,QFill,Qx,Qx}},
	{"oo+++o+o",{QFill,QFill,Qx,Qx,Qx,QFill,Qx,QFill}},
	{"oo+++o+h",{QFill,QFill,Qx,Qx,QLong,QFill,QLong,QFill}},
	{"oo+++oo+",{QFill,QFill,Qx,Qx,Qx,QFill,QFill,Qx}},
	{"oo+++ooo",{QFill,QFill,Qx,Qx,Qx,QFill,QFill,QFill}},
	{"oo+++ooh",{QFill,QFill,Qx,Qx,QLong,QFill,QFill,QFill}},
	{"oo++o+++",{QFill,QFill,Qx,Qx,QFill,Qx,Qx,Qx}},
	{"oo++o++o",{QFill,QFill,Qx,Qx,QFill,Qx,Qx,QFill}},
	{"oo++o++h",{QFill,QFill,Qx,Qx,QFill,QLong,QLong,QFill}},
	{"oo++o+o+",{QFill,QFill,Qx,Qx,QFill,Qx,QFill,Qx}},
	{"oo++o+oo",{QFill,QFill,Qx,Qx,QFill,Qx,QFill,QFill}},
	{"oo++o+oh",{QFill,QFill,Qx,Qx,QFill,QLong,QFill,QFill}},
	{"oo++oo++",{QFill,QFill,Qx,Qx,QFill,QFill,Qx,Qx}},
	{"oo++oo+o",{QFill,QFill,Qx,Qx,QFill,QFill,Qx,QFill}},
	{"oo++oo+h",{QFill,QFill,Qx,QLong,QFill,QFill,QLong,QFill}},
	{"oo++ooo+",{QFill,QFill,Qx,Qx,QFill,QFill,QFill,Qx}},
	{"oo++oooo",{QFill,QFill,Qx,Qx,QFill,QFill,QFill,QFill}},
	{"oo++oooh",{QFill,QFill,Qx,QLong,QFill,QFill,QFill,QFill}},
	{"oo+o++++",{QFill,QFill,Qx,QFill,Qx,Qx,Qx,Qx}},
	{"oo+o+++o",{QFill,QFill,Qx,QFill,Qx,Qx,Qx,QFill}},
	{"oo+o+++h",{QFill,QFill,Qx,QFill,Qx,QLong,QLong,QFill}},
	{"oo+o++o+",{QFill,QFill,Qx,QFill,Qx,Qx,QFill,Qx}},
	{"oo+o++oo",{QFill,QFill,Qx,QFill,Qx,Qx,QFill,QFill}},
	{"oo+o++oh",{QFill,QFill,Qx,QFill,Qx,QLong,QFill,QFill}},
	{"oo+o+o++",{QFill,QFill,Qx,QFill,Qx,QFill,Qx,Qx}},
	{"oo+o+o+o",{QFill,QFill,Qx,QFill,Qx,QFill,Qx,QFill}},
	{"oo+o+o+h",{QFill,QFill,Qx,QFill,QLong,QFill,QLong,QFill}},
	{"oo+o+oo+",{QFill,QFill,Qx,QFill,Qx,QFill,QFill,Qx}},
	{"oo+o+ooo",{QFill,QFill,Qx,QFill,Qx,QFill,QFill,QFill}},
	{"oo+o+ooh",{QFill,QFill,Qx,QFill,QLong,QFill,QFill,QFill}},
	{"oo+oo+++",{QFill,QFill,Qx,QFill,QFill,Qx,Qx,Qx}},
	{"oo+oo++o",{QFill,QFill,Qx,QFill,QFill,Qx,Qx,QFill}},
	{"oo+oo++h",{QFill,QFill,Qx,QFill,QFill,QLong,QLong,QFill}},
	{"oo+oo+o+",{QFill,QFill,Qx,QFill,QFill,Qx,QFill,Qx}},
	{"oo+oo+oo",{QFill,QFill,Qx,QFill,QFill,Qx,QFill,QFill}},
	{"oo+oo+oh",{QFill,QFill,Qx,QFill,QFill,QLong,QFill,QFill}},
	{"oo+ooo++",{QFill,QFill,Qx,QFill,QFill,QFill,Qx,Qx}},
	{"oo+ooo+o",{QFill,QFill,Qx,QFill,QFill,QFill,Qx,QFill}},
	{"oo+ooo+h",{QFill,QFill,Qx,QFill,QFill,QFill,QLong,QFill}},
	{"oo+oooo+",{QFill,QFill,QDead,QFill,QFill,QFill,QFill,Qx}},
	{"oo+ooooo",{QFill,QFill,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"oo+ooooh",{QFill,QFill,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"ooo+++++",{QFill,QFill,QFill,Qx,Qx,Qx,Qx,Qx}},
	{"ooo++++o",{QFill,QFill,QFill,Qx,Qx,Qx,Qx,QFill}},
	{"ooo++++h",{QFill,QFill,QFill,Qx,Qx,QLong,QLong,QFill}},
	{"ooo+++o+",{QFill,QFill,QFill,Qx,Qx,Qx,QFill,Qx}},
	{"ooo+++oo",{QFill,QFill,QFill,Qx,Qx,Qx,QFill,QFill}},
	{"ooo+++oh",{QFill,QFill,QFill,Qx,Qx,QLong,QFill,QFill}},
	{"ooo++o++",{QFill,QFill,QFill,Qx,Qx,QFill,Qx,Qx}},
	{"ooo++o+o",{QFill,QFill,QFill,Qx,Qx,QFill,Qx,QFill}},
	{"ooo++o+h",{QFill,QFill,QFill,Qx,QLong,QFill,QLong,QFill}},
	{"ooo++oo+",{QFill,QFill,QFill,Qx,Qx,QFill,QFill,Qx}},
	{"ooo++ooo",{QFill,QFill,QFill,Qx,Qx,QFill,QFill,QFill}},
	{"ooo++ooh",{QFill,QFill,QFill,Qx,QLong,QFill,QFill,QFill}},
	{"ooo+o+++",{QFill,QFill,QFill,Qx,QFill,Qx,Qx,Qx}},
	{"ooo+o++o",{QFill,QFill,QFill,Qx,QFill,Qx,Qx,QFill}},
	{"ooo+o++h",{QFill,QFill,QFill,Qx,QFill,QLong,QLong,QFill}},
	{"ooo+o+o+",{QFill,QFill,QFill,Qx,QFill,Qx,QFill,Qx}},
	{"ooo+o+oo",{QFill,QFill,QFill,Qx,QFill,Qx,QFill,QFill}},
	{"ooo+o+oh",{QFill,QFill,QFill,Qx,QFill,QLong,QFill,QFill}},
	{"ooo+oo++",{QFill,QFill,QFill,Qx,QFill,QFill,Qx,Qx}},
	{"ooo+oo+o",{QFill,QFill,QFill,Qx,QFill,QFill,Qx,QFill}},
	{"ooo+oo+h",{QFill,QFill,QFill,QDead,QFill,QFill,QLong,QFill}},
	{"ooo+ooo+",{QFill,QFill,QFill,QDead,QFill,QFill,QFill,Qx}},
	{"ooo+oooo",{QFill,QFill,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"ooo+oooh",{QFill,QFill,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"oooo++++",{QFill,QFill,QFill,QFill,Qx,Qx,Qx,Qx}},
	{"oooo+++o",{QFill,QFill,QFill,QFill,Qx,Qx,Qx,QFill}},
	{"oooo+++h",{QFill,QFill,QFill,QFill,Qx,QLong,QLong,QFill}},
	{"oooo++o+",{QFill,QFill,QFill,QFill,Qx,Qx,QFill,Qx}},
	{"oooo++oo",{QFill,QFill,QFill,QFill,QDead,QDead,QFill,QFill}},
	{"oooo++oh",{QFill,QFill,QFill,QFill,Qx,QLong,QFill,QFill}},
	{"oooo+o++",{QFill,QFill,QFill,QFill,QDead,QFill,Qx,Qx}},
	{"oooo+o+o",{QFill,QFill,QFill,QFill,QDead,QFill,Qx,QFill}},
	{"oooo+o+h",{QFill,QFill,QFill,QFill,QDead,QFill,QLong,QFill}},
	{"oooo+oo+",{QFill,QFill,QFill,QFill,QDead,QFill,QFill,Qx}},
	{"oooo+ooo",{QFill,QFill,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"oooo+ooh",{QFill,QFill,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"ooooo+++",{QFill,QFill,QFill,QFill,QFill,QDead,Qx,Qx}},
	{"ooooo++o",{QFill,QFill,QFill,QFill,QFill,QDead,Qx,QFill}},
	{"ooooo++h",{QFill,QFill,QFill,QFill,QFill,QDead,QLong,QFill}},
	{"ooooo+o+",{QFill,QFill,QFill,QFill,QFill,QDead,QFill,Qx}},
	{"ooooo+oo",{QFill,QFill,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"ooooo+oh",{QFill,QFill,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"oooooo++",{QFill,QFill,QFill,QFill,QFill,QFill,QDead,Qx}},
	{"oooooo+o",{QFill,QFill,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"oooooo+h",{QFill,QFill,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"ooooooo+",{QFill,QFill,QFill,QFill,QFill,QFill,QFill,QDead}},
	{"oooooooo",{QFill,QFill,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"oooooooh",{QFill,QFill,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"h+++++++",{QFill,Q1,Q1,Q1,Q1,Q1,Q1,Qx}},
	{"h++++++o",{QFill,Q1,Q1,Q1,Q1,Q1,Qx,QFill}},
	{"h++++++h",{QFill,Q1,Q1,Q1,Q1,Q1,Q1,QFill}},
	{"h+++++o+",{QFill,QLong,Q2,Q2,Q2,Q2,QFill,Qx}},
	{"h+++++oo",{QFill,QLong,QLong,Qx,Qx,Qx,QFill,QFill}},
	{"h+++++oh",{QFill,QLong,Q2,Q2,Q2,Q2,QFill,QFill}},
	{"h++++o++",{QFill,Q2,Q2d,Q2d,Q2d,QFill,Q2,Qx}},
	{"h++++o+o",{QFill,Q2,Q2,Q3,Q2,QFill,Qx,QFill}},
	{"h++++o+h",{QFill,Q2,Q2d,Q2d,Q2d,QFill,Q2,QFill}},
	{"h++++oo+",{QFill,QLong,Q3,Q3,Q3,QFill,QFill,Qx}},
	{"h++++ooo",{QFill,QLong,QLong,Qx,Qx,QFill,QFill,QFill}},
	{"h++++ooh",{QFill,QLong,Q3,Q3,Q3,QFill,QFill,QFill}},
	{"h+++o+++",{QFill,Q2,Q2d,Q2d,QFill,Q2d,Q2,Qx}},
	{"h+++o++o",{QFill,Q2,Q2,Q2,QFill,Q2,Qx,QFill}},
	{"h+++o++h",{QFill,Q2,Q2d,Q2d,QFill,Q2d,Q2,QFill}},
	{"h+++o+o+",{QFill,QLong,Q3,Q3,QFill,Q3,QFill,Qx}},
	{"h+++o+oo",{QFill,QLong,QLong,Qx,QFill,Qx,QFill,QFill}},
	{"h+++o+oh",{QFill,QLong,Q3,Q3,QFill,Q3,QFill,QFill}},
	{"h+++oo++",{QFill,Q3,Q3d,Q3d,QFill,QFill,Qx,Qx}},
	{"h+++oo+o",{QFill,Q3,Q3,Q3,QFill,QFill,Qx,QFill}},
	{"h+++oo+h",{QFill,Q3,Q3d,Q3d,QFill,QFill,Q3,QFill}},
	{"h+++ooo+",{QFill,QLong,Q4,Q4,QFill,QFill,QFill,Qx}},
	{"h+++oooo",{QFill,QLong,QLong,Qx,QFill,QFill,QFill,QFill}},
	{"h+++oooh",{QFill,QLong,Q4,Q4,QFill,QFill,QFill,QFill}},
	{"h++o++++",{QFill,Q2,Q2d,QFill,Q2d,Q2d,Q2,Qx}},
	{"h++o+++o",{QFill,Q2,Q2,QFill,Q2,Q2,Qx,QFill}},
	{"h++o+++h",{QFill,Q2,Q2d,QFill,Q2d,Q2d,Q2,QFill}},
	{"h++o++o+",{QFill,QLong,Q3,QFill,Q3,Q3,QFill,Qx}},
	{"h++o++oo",{QFill,QLong,QLong,QFill,Qx,Qx,QFill,QFill}},
	{"h++o++oh",{QFill,QLong,Q3,QFill,Q3,Q3,QFill,QFill}},
	{"h++o+o++",{QFill,Q3,Q3d,QFill,Q3d,QFill,Q3,Qx}},
	{"h++o+o+o",{QFill,Q3,Q3,QFill,Q3,QFill,Qx,QFill}},
	{"h++o+o+h",{QFill,Q3,Q3d,QFill,Q3d,QFill,Q3,QFill}},
	{"h++o+oo+",{QFill,QLong,Q4,QFill,Q4,QFill,QFill,Qx}},
	{"h++o+ooo",{QFill,QLong,QLong,QFill,Qx,QFill,QFill,QFill}},
	{"h++o+ooh",{QFill,QLong,Q4,QFill,Q4,QFill,QFill,QFill}},
	{"h++oo+++",{QFill,Q3,Q3d,QFill,QFill,Q3d,Q3,Qx}},
	{"h++oo++o",{QFill,Q3,Q3,QFill,QFill,Q3,Qx,QFill}},
	{"h++oo++h",{QFill,Q3,Q3d,QFill,QFill,Q3d,Q3,QFill}},
	{"h++oo+o+",{QFill,QLong,Q4,QFill,QFill,Q4,QFill,Qx}},
	{"h++oo+oo",{QFill,QLong,QLong,QFill,QFill,Qx,QFill,QFill}},
	{"h++oo+oh",{QFill,QLong,Q4,QFill,QFill,Q4,QFill,QFill}},
	{"h++ooo++",{QFill,Q4,Q4d,QFill,QFill,QFill,Q4,Q4}},
	{"h++ooo+o",{QFill,Q4,Q4,QFill,QFill,QFill,Qx,QFill}},
	{"h++ooo+h",{QFill,Q4,Q4d,QFill,QFill,QFill,Q4,QFill}},
	{"h++oooo+",{QFill,QLong,Q5,QFill,QFill,QFill,QFill,Qx}},
	{"h++ooooo",{QFill,QLong,QLong,QFill,QFill,QFill,QFill,QFill}},
	{"h++ooooh",{QFill,QLong,Q5,QFill,QFill,QFill,QFill,QFill}},
	{"h+o+++++",{QFill,Q2,QFill,Q2d,Q2d,Q2d,Q2,Qx}},
	{"h+o++++o",{QFill,Q2,QFill,Q2,Q2,Q2,Qx,QFill}},
	{"h+o++++h",{QFill,Q2,QFill,Q2d,Q2d,Q2d,Q2,QFill}},
	{"h+o+++o+",{QFill,QLong,QFill,Q2,Q2,Q2,QFill,Qx}},
	{"h+o+++oo",{QFill,QLong,QFill,QLong,Qx,Qx,QFill,QFill}},
	{"h+o+++oh",{QFill,QLong,QFill,Q2,Q2,Q2,QFill,QFill}},
	{"h+o++o++",{QFill,Q3,QFill,Q3d,Q3d,QFill,Q3,Qx}},
	{"h+o++o+o",{QFill,Q3,QFill,Q3,Q3,QFill,Qx,QFill}},
	{"h+o++o+h",{QFill,Q3,QFill,Q3d,Q3d,QFill,Q3,QFill}},
	{"h+o++oo+",{QFill,QLong,QFill,Q4,Q4,QFill,QFill,Qx}},
	{"h+o++ooo",{QFill,QLong,QFill,QLong,Qx,QFill,QFill,QFill}},
	{"h+o++ooh",{QFill,QLong,QFill,Q4,Q4,QFill,QFill,QFill}},
	{"h+o+o+++",{QFill,Q3,QFill,Q3d,QFill,Q3d,Q3,Qx}},
	{"h+o+o++o",{QFill,Q3,QFill,Q3,QFill,Q3,Qx,QFill}},
	{"h+o+o++h",{QFill,Q3,QFill,Q3d,QFill,Q3d,Q3,QFill}},
	{"h+o+o+o+",{QFill,QLong,QFill,Q4,QFill,Q4,QFill,Qx}},
	{"h+o+o+oo",{QFill,QLong,QFill,QLong,QFill,Qx,QFill,QFill}},
	{"h+o+o+oh",{QFill,QLong,QFill,Q4,QFill,Q4,QFill,QFill}},
	{"h+o+oo++",{QFill,Q4,QFill,Q4d,QFill,QFill,Q4,Qx}},
	{"h+o+oo+o",{QFill,Q4,QFill,Q4,QFill,QFill,Qx,QFill}},
	{"h+o+oo+h",{QFill,Q4,QFill,Q4d,QFill,QFill,Q4,QFill}},
	{"h+o+ooo+",{QFill,QLong,QFill,Q5,QFill,QFill,QFill,Qx}},
	{"h+o+oooo",{QFill,QLong,QFill,QLong,QFill,QFill,QFill,QFill}},
	{"h+o+oooh",{QFill,QLong,QFill,Q5,QFill,QFill,QFill,QFill}},
	{"h+oo++++",{QFill,Q3,QFill,QFill,Q3d,Q3d,Q3,Qx}},
	{"h+oo+++o",{QFill,Q3,QFill,QFill,Q3,Q3,Qx,QFill}},
	{"h+oo+++h",{QFill,Q3,QFill,QFill,Q3d,Q3d,Q3,QFill}},
	{"h+oo++o+",{QFill,QLong,QFill,QFill,Q4,Q4,QFill,Qx}},
	{"h+oo++oo",{QFill,QLong,QFill,QFill,QLong,Qx,QFill,QFill}},
	{"h+oo++oh",{QFill,QLong,QFill,QFill,Q4,Q4,QFill,QFill}},
	{"h+oo+o++",{QFill,Q4,QFill,QFill,Q4d,QFill,Q4,Qx}},
	{"h+oo+o+o",{QFill,Q4,QFill,QFill,Q4,QFill,Qx,QFill}},
	{"h+oo+o+h",{QFill,Q4,QFill,QFill,Q4d,QFill,Q4,QFill}},
	{"h+oo+oo+",{QFill,QLong,QFill,QFill,Q5,QFill,QFill,Qx}},
	{"h+oo+ooo",{QFill,QLong,QFill,QFill,QLong,QFill,QFill,QFill}},
	{"h+oo+ooh",{QFill,QLong,QFill,QFill,Q5,QFill,QFill,QFill}},
	{"h+ooo+++",{QFill,Q4,QFill,QFill,QFill,Q4d,Q4,Qx}},
	{"h+ooo++o",{QFill,Q4,QFill,QFill,QFill,Q4,Qx,QFill}},
	{"h+ooo++h",{QFill,Q4,QFill,QFill,QFill,Q4d,Q4,QFill}},
	{"h+ooo+o+",{QFill,QLong,QFill,QFill,QFill,Q5,QFill,Qx}},
	{"h+ooo+oo",{QFill,QLong,QFill,QFill,QFill,QLong,QFill,QFill}},
	{"h+ooo+oh",{QFill,QLong,QFill,QFill,QFill,Q5,QFill,QFill}},
	{"h+oooo++",{QFill,Q5,QFill,QFill,QFill,QFill,Q5,Qx}},
	{"h+oooo+o",{QFill,Q5,QFill,QFill,QFill,QFill,QLong,QFill}},
	{"h+oooo+h",{QFill,Q5,QFill,QFill,QFill,QFill,Q5,QFill}},
	{"h+ooooo+",{QFill,QLong,QFill,QFill,QFill,QFill,QFill,QLong}},
	{"h+oooooo",{QFill,QLong,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"h+oooooh",{QFill,QLong,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"ho++++++",{QFill,QFill,Q2,Q2,Q2,Q2,Q1,Q1}},
	{"ho+++++o",{QFill,QFill,Q2,Q2,Q2,Q2,Q2,QFill}},
	{"ho+++++h",{QFill,QFill,Q2,Q2,Q2,Q2,QLong,QFill}},
	{"ho++++o+",{QFill,QFill,QLong,Qx,Qx,Qx,QFill,Qx}},
	{"ho++++oo",{QFill,QFill,QLong,Qx,Qx,Qx,QFill,QFill}},
	{"ho++++oh",{QFill,QFill,QLong,QLong,QLong,QLong,QFill,QFill}},
	{"ho+++o++",{QFill,QFill,Q3,Q3,Q3,QFill,Qx,Qx}},
	{"ho+++o+o",{QFill,QFill,Q3,Q3,Q3,QFill,Qx,QFill}},
	{"ho+++o+h",{QFill,QFill,Q3,Q3,Q3,QFill,QLong,QFill}},
	{"ho+++oo+",{QFill,QFill,QLong,Qx,Qx,QFill,QFill,Qx}},
	{"ho+++ooo",{QFill,QFill,QLong,Qx,Qx,QFill,QFill,QFill}},
	{"ho+++ooh",{QFill,QFill,QLong,QLong,QLong,QFill,QFill,QFill}},
	{"ho++o+++",{QFill,QFill,Q3,Q3,QFill,Q3,Qx,Qx}},
	{"ho++o++o",{QFill,QFill,Q3,Q3,QFill,Q3,Qx,QFill}},
	{"ho++o++h",{QFill,QFill,Q3,Q3,QFill,Q3,QLong,QFill}},
	{"ho++o+o+",{QFill,QFill,QLong,Qx,QFill,Qx,QFill,Qx}},
	{"ho++o+oo",{QFill,QFill,QLong,Qx,QFill,Qx,QFill,QFill}},
	{"ho++o+oh",{QFill,QFill,QLong,QLong,QFill,QLong,QFill,QFill}},
	{"ho++oo++",{QFill,QFill,Q4,Q4,QFill,QFill,Qx,Qx}},
	{"ho++oo+o",{QFill,QFill,Q4,Q4,QFill,QFill,Qx,QFill}},
	{"ho++oo+h",{QFill,QFill,Q4,Q4,QFill,QFill,QLong,QFill}},
	{"ho++ooo+",{QFill,QFill,QLong,Qx,QFill,QFill,QFill,Qx}},
	{"ho++oooo",{QFill,QFill,QLong,Qx,QFill,QFill,QFill,QFill}},
	{"ho++oooh",{QFill,QFill,QLong,QLong,QFill,QFill,QFill,QFill}},
	{"ho+o++++",{QFill,QFill,Q3,QFill,Q3,Q3,Qx,Qx}},
	{"ho+o+++o",{QFill,QFill,Q3,QFill,Q3,Q3,Qx,QFill}},
	{"ho+o+++h",{QFill,QFill,Q3,QFill,Q3,Q3,QLong,QFill}},
	{"ho+o++o+",{QFill,QFill,QLong,QFill,Qx,Qx,QFill,Qx}},
	{"ho+o++oo",{QFill,QFill,QLong,QFill,Qx,Qx,QFill,QFill}},
	{"ho+o++oh",{QFill,QFill,QLong,QFill,QLong,QLong,QFill,QFill}},
	{"ho+o+o++",{QFill,QFill,Q4,QFill,Q4,QFill,Qx,Qx}},
	{"ho+o+o+o",{QFill,QFill,Q4,QFill,Q4,QFill,Qx,QFill}},
	{"ho+o+o+h",{QFill,QFill,Q4,QFill,Q4,QFill,QLong,QFill}},
	{"ho+o+oo+",{QFill,QFill,QLong,QFill,Qx,QFill,QFill,Qx}},
	{"ho+o+ooo",{QFill,QFill,QLong,QFill,Qx,QFill,QFill,QFill}},
	{"ho+o+ooh",{QFill,QFill,QLong,QFill,QLong,QFill,QFill,QFill}},
	{"ho+oo+++",{QFill,QFill,Q4,QFill,QFill,Q4,Qx,Qx}},
	{"ho+oo++o",{QFill,QFill,Q4,QFill,QFill,Q4,Qx,QFill}},
	{"ho+oo++h",{QFill,QFill,Q4,QFill,QFill,Q4,QLong,QFill}},
	{"ho+oo+o+",{QFill,QFill,QLong,QFill,QFill,Qx,QFill,Qx}},
	{"ho+oo+oo",{QFill,QFill,QLong,QFill,QFill,Qx,QFill,QFill}},
	{"ho+oo+oh",{QFill,QFill,QLong,QFill,QFill,QLong,QFill,QFill}},
	{"ho+ooo++",{QFill,QFill,Q5,QFill,QFill,QFill,Qx,Qx}},
	{"ho+ooo+o",{QFill,QFill,Q5,QFill,QFill,QFill,Qx,QFill}},
	{"ho+ooo+h",{QFill,QFill,Q5,QFill,QFill,QFill,QLong,QFill}},
	{"ho+oooo+",{QFill,QFill,QDead,QFill,QFill,QFill,QFill,Qx}},
	{"ho+ooooo",{QFill,QFill,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"ho+ooooh",{QFill,QFill,QDead,QFill,QFill,QFill,QFill,QFill}},
	{"hoo+++++",{QFill,QFill,QFill,Q3,Q3,Q3,Qx,Qx}},
	{"hoo++++o",{QFill,QFill,QFill,Q3,Q3,Q3,Qx,QFill}},
	{"hoo++++h",{QFill,QFill,QFill,Q3,Q3,Q3,QLong,QFill}},
	{"hoo+++o+",{QFill,QFill,QFill,QLong,Qx,Qx,QFill,Qx}},
	{"hoo+++oo",{QFill,QFill,QFill,QLong,Qx,Qx,QFill,QFill}},
	{"hoo+++oh",{QFill,QFill,QFill,QLong,QLong,QLong,QFill,QFill}},
	{"hoo++o++",{QFill,QFill,QFill,Q4,Q4,QFill,Qx,Qx}},
	{"hoo++o+o",{QFill,QFill,QFill,Q4,Q4,QFill,Qx,QFill}},
	{"hoo++o+h",{QFill,QFill,QFill,Q4,Q4,QFill,QLong,QFill}},
	{"hoo++oo+",{QFill,QFill,QFill,QLong,Qx,QFill,QFill,Qx}},
	{"hoo++ooo",{QFill,QFill,QFill,QLong,Qx,QFill,QFill,QFill}},
	{"hoo++ooh",{QFill,QFill,QFill,QLong,QLong,QFill,QFill,QFill}},
	{"hoo+o+++",{QFill,QFill,QFill,Q4,QFill,Q4,Qx,Qx}},
	{"hoo+o++o",{QFill,QFill,QFill,Q4,QFill,Q4,Qx,QFill}},
	{"hoo+o++h",{QFill,QFill,QFill,Q4,QFill,Q4,QLong,QFill}},
	{"hoo+o+o+",{QFill,QFill,QFill,QLong,QFill,Qx,QFill,Qx}},
	{"hoo+o+oo",{QFill,QFill,QFill,QLong,QFill,Qx,QFill,QFill}},
	{"hoo+o+oh",{QFill,QFill,QFill,QLong,QFill,QLong,QFill,QFill}},
	{"hoo+oo++",{QFill,QFill,QFill,Q5,QFill,QFill,Qx,Qx}},
	{"hoo+oo+o",{QFill,QFill,QFill,Q5,QFill,QFill,Qx,QFill}},
	{"hoo+oo+h",{QFill,QFill,QFill,Q5,QFill,QFill,QLong,QFill}},
	{"hoo+ooo+",{QFill,QFill,QFill,QDead,QFill,QFill,QFill,Qx}},
	{"hoo+oooo",{QFill,QFill,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"hoo+oooh",{QFill,QFill,QFill,QDead,QFill,QFill,QFill,QFill}},
	{"hooo++++",{QFill,QFill,QFill,QFill,Q4,Q4,Qx,Qx}},
	{"hooo+++o",{QFill,QFill,QFill,QFill,Q4,Q4,Qx,QFill}},
	{"hooo+++h",{QFill,QFill,QFill,QFill,Q4,Q4,QLong,QFill}},
	{"hooo++o+",{QFill,QFill,QFill,QFill,QLong,Qx,QFill,Qx}},
	{"hooo++oo",{QFill,QFill,QFill,QFill,QLong,Qx,QFill,QFill}},
	{"hooo++oh",{QFill,QFill,QFill,QFill,QLong,QLong,QFill,QFill}},
	{"hooo+o++",{QFill,QFill,QFill,QFill,Q5,QFill,Qx,Qx}},
	{"hooo+o+o",{QFill,QFill,QFill,QFill,Q5,QFill,Qx,QFill}},
	{"hooo+o+h",{QFill,QFill,QFill,QFill,Q5,QFill,QLong,QFill}},
	{"hooo+oo+",{QFill,QFill,QFill,QFill,QDead,QFill,QFill,Qx}},
	{"hooo+ooo",{QFill,QFill,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"hooo+ooh",{QFill,QFill,QFill,QFill,QDead,QFill,QFill,QFill}},
	{"hoooo+++",{QFill,QFill,QFill,QFill,QFill,Q5,Qx,Qx}},
	{"hoooo++o",{QFill,QFill,QFill,QFill,QFill,Q5,Qx,QFill}},
	{"hoooo++h",{QFill,QFill,QFill,QFill,QFill,Q5,QLong,QFill}},
	{"hoooo+o+",{QFill,QFill,QFill,QFill,QFill,QDead,QFill,Qx}},
	{"hoooo+oo",{QFill,QFill,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"hoooo+oh",{QFill,QFill,QFill,QFill,QFill,QDead,QFill,QFill}},
	{"hooooo++",{QFill,QFill,QFill,QFill,QFill,QFill,QDead,Qx}},
	{"hooooo+o",{QFill,QFill,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"hooooo+h",{QFill,QFill,QFill,QFill,QFill,QFill,QDead,QFill}},
	{"hoooooo+",{QFill,QFill,QFill,QFill,QFill,QFill,QFill,QDead}},
	{"hooooooo",{QFill,QFill,QFill,QFill,QFill,QFill,QFill,QFill}},
	{"hooooooh",{QFill,QFill,QFill,QFill,QFill,QFill,QFill,QFill}}
};

/************************************************************************/
/*  ������������                                                        */
/************************************************************************/
#ifdef TEST_EDIT 
/*����x��λģʽ���*/
void Q8Pattern::putall(int l)
{
	static ofstream fp("Q8Pattern.txt");
	static char pattern[10]="xxxxxxxx";
	static int max=8;

	if(l==0){
		pattern[l]='h';
		putall(l+1);
		pattern[l]='+';
		putall(l+1);
		pattern[l]='o';
		putall(l+1);
	}else if(l<max-1 && l>0){
		pattern[l]='+';
		putall(l+1);
		pattern[l]='o';
		putall(l+1);
	}else if(l==max-1){
		int i;
		pattern[l]='h';
		fp<<pattern<<endl;
		fp<<"{";
		for(i=0;i<max;i++){
			if(pattern[i]=='+') fp<<"x";
			else fp<<"f";
			if(i!=max-1) fp<<",";
		}
		fp<<"}"<<endl<<endl;


		pattern[l]='+';
		fp<<pattern<<endl;
		fp<<"{";
		for(i=0;i<max;i++){
			if(pattern[i]=='+') fp<<"x";
			else fp<<"f";
			if(i!=max-1) fp<<",";
		}
		fp<<"}"<<endl<<endl;


		pattern[l]='o';
		fp<<pattern<<endl;
		fp<<"{";
		for(i=0;i<max;i++){
			if(pattern[i]=='+') fp<<"x";
			else fp<<"f";
			if(i!=max-1) fp<<",";
		}
		fp<<"}"<<endl<<endl;	
	}else{
		assert(0);
	}
}
UINT_16 qtype[16];
void Q8Pattern::parse(char *str)
{
	str[strlen(str)-1]=',';
	string strtmp=&str[1];
	string tmp[8];

	int nr=0;
	string::size_type prepos=0,pos=0;	
	while((pos=strtmp.find_first_of(',',pos))!=string::npos)
	{
		if(prepos==pos)
		{
			prepos=++pos;
			continue;
		}
		tmp[nr++]=strtmp.substr(prepos,pos-prepos);
		prepos=++pos;
	}

	for(int i=0;i<8;i++)
	{
		unsigned short type;
		if(tmp[i]=="1"){
			type=Q1;
		}else if(tmp[i]=="2"){
			type=Q2;
		}else if(tmp[i]=="3"){
			type=Q3;
		}else if(tmp[i]=="2'"){
			type=Q2S;
		}else if(tmp[i]=="3d"){
			type=Q3d;
		}else if(tmp[i]=="3d'"){
			type=Q3dS;
		}else if(tmp[i]=="4"){
			type=Q4;
		}else if(tmp[i]=="4'"){
			type=Q4S;
		}else if(tmp[i]=="4d"){
			type=Q4d;
		}else if(tmp[i]=="5"){
			type=Q5;
		}else if(tmp[i]=="L"){
			type=QLong;
		}else if(tmp[i]=="D"){
			type=QDead;
		}else if(tmp[i]=="x"){
			type=Qx;
		}else if(tmp[i]=="f"){
			type=QFill;
		}else{
			assert(0);
		}
		qtype[i]=type;
	}		
}

/*�����ı��ļ��ɱ�������*/
void Q8Pattern::parsefile(char *file)
{
	int nr=0;
	ifstream fpin(file);
	ofstream fpout("out.txt");

	char pattern[16];
	char value[64];

	fpout<<"{\n";
	while(1){
		if(fpin.eof()) break;

		fpin>>pattern;
		fpin>>value;
		parse(value);
		
		fpout<<"\t{";
		//-----
		fpout<<"\"";
		fpout<<pattern;
		fpout<<"\",";

		//----
		fpout<<"{";
		for(int j=0;j<8;j++)
		{
			fpout<<qtype[j];
			if(j<7) fpout<<",";
		}
		fpout<<"}";

		fpout<<"}";
		nr++;
		if(nr<576) fpout<<","<<endl;
		else fpout<<endl;
	}
	fpout<<"}";

	fpin.close();	
}

#endif



