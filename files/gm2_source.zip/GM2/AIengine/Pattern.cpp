#include "StdAfx.h"

#include "Pattern.h"

#include <iostream>
#include <cassert>

using namespace std;

//Pattern patternQ; /*ֱ������Ϊȫ�ֱ�����������ʱ����*/

/*������������*/
char staticstr[16];

/*��һ������ģʽת��Ϊ�ַ���ģʽ*/
char* PatternToStr(int p)
{
	int offset=14;
	for(int i=0;i<8;i++,offset=offset-2){
		switch((p>>offset)&0x3) {
		case Pattern::BLACK:
			staticstr[i]='o';
			break;
		case Pattern::NONE:
			staticstr[i]='+';
			break;
		case Pattern::WHITE:
			staticstr[i]='h';
			break;
		case Pattern::ANY:
			staticstr[i]='x';
			break;
		default:
			assert(0);
		}		
	}
	staticstr[8]=0;
	return staticstr;
}
/*��һ���ַ���ģʽת��Ϊ����ģʽ*/
int StrToPattern(char *str)
{
	int p=0;
	if(strlen(str)<8) return 0;
	for(int i=0;i<8;i++)
	{
		switch(str[i]) {
		case 'o':
			p=S(p)|Pattern::BLACK;
			break;
		case 'h':
			p=S(p)|Pattern::WHITE;
			break;
		case '+':
			p=S(p)|Pattern::NONE;
			break;
		case 'x':
			p=S(p)|Pattern::ANY;
			break;
		default:
			assert(0);
		}		
	}
	return p;
}

/*��ӡģʽ��Ϣ*/
void PatternItem::PrintPattern()
{
	int p=pattern;
	cout<<PatternToStr(p);
	cout<<"\t";
	switch(type) {
	case Pattern::Q5:
		cout<<"Q5";
		break;
	case Pattern::Q4d:
		cout<<"Q4d";
		break;
	case Pattern::Q4:
		cout<<"Q4";
		break;
	case Pattern::Q3d:
		cout<<"Q3d";
		break;
	case Pattern::Q3:
		cout<<"Q3";
		break;
	case Pattern::Q2d:
		cout<<"Q2d";
		break;
	case Pattern::QLong:
		cout<<"QLong";
		break;
	default:
		assert(0);
	}	
	cout<<"\t";
	if(keypos1>-1) cout<<(int)keypos1<<" ";
	if(keypos2>-1) cout<<(int)keypos2<<" ";
	cout<<endl;
}


Pattern::Pattern():pattern_nr(0)
{
	init();
}

Pattern::~Pattern()
{
	
	
}

void Pattern::AddItem(char pos[8],int type,int ktype,int keypos1,int keypos2,int index,int pattern)
{
	if(index<7)
	{
		switch(pos[index]) {
		case '?':
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|NONE);
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|WHITE);
			break;
		case 'o':
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|BLACK);
			break;
		case 'h':
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|WHITE);
			break;
		case '+':
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|NONE);
			break;
		case 'x':
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|NONE);
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|WHITE);
			AddItem(pos,type,ktype,keypos1,keypos2,index+1,S(pattern)|BLACK);
			break;
		default:
			assert(0);
		}
	}else{
		switch(pos[index]) {
		case '?':
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|NONE;
			pattern_nr++;
			
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|WHITE;
			pattern_nr++;
			break;
		case 'o':
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|BLACK;
			pattern_nr++;
			break;
		case 'h':
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|WHITE;
			pattern_nr++;
			break;
		case '+':
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|NONE;
			pattern_nr++;
			break;
		case 'x':
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|NONE;
			pattern_nr++;
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|WHITE;
			pattern_nr++;
			pattern_table[pattern_nr].keypos1=keypos1;
			pattern_table[pattern_nr].keypos2=keypos2;
			pattern_table[pattern_nr].type=type;
			pattern_table[pattern_nr].ktype=ktype;
			pattern_table[pattern_nr].pattern=S(pattern)|BLACK;
			pattern_nr++;
			break;
		default:
			assert(0);
		}
	}
}

/*����ģʽ*/
void Pattern::AddPattern(char pos[8],int type,int ktype,int keypos1,int keypos2,bool resort)
{
	AddItem(pos,type,ktype,keypos1,keypos2,0,0);
	if(resort) Sort();
}

/*��ģʽ�������Ա���ֲ���*/
void Pattern::Sort()
{
	/*����ֻ���ڳ���������ʱ����ã����Բ��ñ�׾��ð�ݷ���������*/
	/*����С��������*/
	PatternItem tmp;
	
	for(int i=pattern_nr;i>0;i--)
	{
		for(int j=1;j<i;j++){
			if(pattern_table[j-1].pattern>pattern_table[j].pattern)
			{
				/*����*/
				tmp=pattern_table[j];
				pattern_table[j]=pattern_table[j-1];
				pattern_table[j-1]=tmp;
			}
		}
	}
}


/*��ʼ��ģʽ��*/
void Pattern::init()
{
/*
========
������ 
?ooooo?  
========
	*/
	char *str1="?ooooo?x";
	AddPattern(str1,Q5,Q5,-1,-1);
	
	/*
	========
	����	
	?+oooo+?
	^    ^
	========
	*/
	char *str2="?+oooo+?";
	AddPattern(str2,Q4d,Q5,1,6);
	
	/*
	========
	����
	?+ooooh	?o+ooo?	?oo+oo?	?ooo+o? hoooo+?  
	^        ^        ^        ^        ^ 
	========
	*/
	char *str3="?+oooohx";AddPattern(str3,Q4,Q5,1,-1);
	char *str4="?o+ooo?x";AddPattern(str4,Q4,Q5,2,-1);
	char *str5="?oo+oo?x";AddPattern(str5,Q4,Q5,3,-1);
	char *str6="?ooo+o?x";AddPattern(str6,Q4,Q5,4,-1);
	char *str7="hoooo+?x";AddPattern(str7,Q4,Q5,5,-1);
	
	/*
	========
	����
	?+ooo++? ?++ooo+? ?+o+oo+? ?+oo+o+?		
	^	   ^         ^         ^
	========
	*/
	char *str8="?+ooo++?";AddPattern(str8,Q3d,Q4d,5,-1);
	char *str9="?++ooo+?";AddPattern(str9,Q3d,Q4d,2,-1);
	char *str10="?+o+oo+?";AddPattern(str10,Q3d,Q4d,3,-1);
	char *str11="?+oo+o+?";AddPattern(str11,Q3d,Q4d,4,-1);
	
	/*
	========
	��
	hooo++? hoo+o+? ho+oo+? ?++oooh ?+o+ooh ?+oo+oh ?o+o+o? ?oo++o? ?o++oo? h+ooo+h //������Ϲ�ʽC5,3
	^^	   ^ ^    ^  ^   ^^      ^ ^     ^  ^     ^ ^      ^^     ^^     ^   ^
	========
	*/
	char *str12="hooo++?x";AddPattern(str12,Q3,Q4,4,5);
	char *str13="hoo+o+?x";AddPattern(str13,Q3,Q4,3,5);
	char *str14="ho+oo+?x";AddPattern(str14,Q3,Q4,2,5);
	char *str15="?++ooohx";AddPattern(str15,Q3,Q4,1,2);
	char *str16="?+o+oohx";AddPattern(str16,Q3,Q4,1,3);
	char *str17="?+oo+ohx";AddPattern(str17,Q3,Q4,1,4);
	char *str18="?o+o+o?x";AddPattern(str18,Q3,Q4,2,4);
	char *str19="?oo++o?x";AddPattern(str19,Q3,Q4,3,4);
	char *str20="?o++oo?x";AddPattern(str20,Q3,Q4,2,3);
	char *str21="h+ooo+hx";AddPattern(str21,Q3,Q4,1,5);
	
	/*
	========
	���
	?++oo++? ?+oo+++? ?+++oo+? ?+o+o++? ?++o+o+? ?+o++o+?	//������Ϲ�ʽC4,2
	^  ^       ^^     ^^        ^ ^     ^ ^       ^^ 
	========
	*/
	char *str22="?++oo++?";AddPattern(str22,Q2d,Q3d,2,5);
	char *str23="?+oo+++?";AddPattern(str23,Q2d,Q3d,4,5);
	char *str24="?+++oo+?";AddPattern(str24,Q2d,Q3d,3,4);
	char *str25="?+o+o++?";AddPattern(str25,Q2d,Q3d,3,5);
	char *str26="?++o+o+?";AddPattern(str26,Q2d,Q3d,2,4);
	char *str27="?+o++o+?";AddPattern(str27,Q2d,Q3d,3,4);	
	
	/*
	==========
	��������
	oooooo
	==========
	*/
	char *str28="ooooooxx";AddPattern(str28,QLong,QLong,-1,-1);
	
	/*������������ΪҪ���ж��ֲ���*/
	Sort();
}

/*ģʽƥ�䣬��ѯ���ͣ���������ģʽ��*/
PatternItem* Pattern::MatchPattern(int pattern)
{
	/*���ö�������*/
	int start=0;
	int end=pattern_nr-1;
	int middle=pattern_nr/2;

	for(;;)
	{
		if(pattern_table[middle].pattern==pattern)
		{
			return &pattern_table[middle];
		}
		else if(pattern_table[middle].pattern<pattern)
		{
			if(middle==end)
			{
				return NULL;
			}
			start=middle+1;
			middle=(start+end)/2;
			continue;
		}
		else
		{
			if(start==middle)
			{
				return NULL;
			}
			end=middle-1;
			middle=(start+end)/2;
			continue;
		}
	}
}

/*ģʽƥ�䣬��ѯ���ͣ������ַ���ģʽ��*/
PatternItem* Pattern::MatchPattern(char *strp)
{
	int p=StrToPattern(strp);
	return MatchPattern(p);
}

/*��ӡ���ģʽ��*/
void Pattern::Dump()
{
	for(int i=0;i<pattern_nr;i++)
	{
		cout<<i<<"\t";
		pattern_table[i].PrintPattern();
	}
}

/*��ñ�����������ģʽ*/
int Pattern::GetAllPattern(int *buf)
{
	for(int i=0;i<pattern_nr;i++)
	{
		buf[i]=pattern_table[i].pattern;
	}
	return pattern_nr;
}
