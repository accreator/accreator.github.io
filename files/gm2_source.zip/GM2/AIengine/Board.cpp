#include "StdAfx.h"

#include "Board.h"
#include "AIengine.h"
#include "OpenBook.h"

#include <iostream>
#include <cstdlib>
#include <cassert>
#include <iomanip>


using namespace std;


Board board;

#define TESTVALID(x,y) (x>=0 && x<15 && y>=0 && y<15)


/************************************************************************/
/*  ���졢��������                                                      */
/************************************************************************/
Board::Board()
{
	init();
}


Board::~Board()
{
	
}

/************************************************************************/
/*  ��ʼ��                                                              */
/************************************************************************/
void Board::inithashTable()
{
	hash_pattern.GenerateHash();
}

void Board::init()
{
	int i,j;

	/*����*/
	for(i=0;i<15;i++)
	{
		for(j=0;j<14;j++){
			unit[i][j].base_net.right=&unit[i][j+1];
			unit[i][j+1].base_net.left=&unit[i][j];
		}
	}
	/*����*/
	for(j=0;j<15;j++)
	{
		for(i=0;i<14;i++){
			unit[i][j].base_net.down=&unit[i+1][j];
			unit[i+1][j].base_net.up=&unit[i][j];
		}
	}

	/*б����*/
	for(i=0;i<15;i++)
	{
		for(j=0;j<15;j++){
			int ii=i+1;
			int jj=j+1;

			if(TESTVALID(ii,jj))
			{
				unit[i][j].base_net.dright=&unit[ii][jj];
				unit[ii][jj].base_net.uleft=&unit[i][j];
			}
		}
	}

	/*б����*/
	for(i=0;i<15;i++)
	{
		for(j=0;j<15;j++){
			int ii=i-1;
			int jj=j+1;

			if(TESTVALID(ii,jj))
			{
				unit[i][j].base_net.uright=&unit[ii][jj];
				unit[ii][jj].base_net.dleft=&unit[i][j];
			}
		}
	}
	/*��Ҫ�ǳ�ʼ��unit����*/
	for(i=0;i<15;i++)
	{
		for(j=0;j<15;j++){
			unit[i][j].init();
			unit[i][j].pi=i;
			unit[i][j].pj=j;
		}
	}

	/*��ʼ������Ϊ��*/
	for(i=0;i<T4::cate;i++)
	{
		glistH[i].reset();
		glistW[i].reset();
		llistH[i].reset();
		llistW[i].reset();
	}

	/*�ص���һ��*/
	step=0;
	stepmax=0;

}
/************************************************************************/
/*  ��λ                                                                */
/************************************************************************/
void Board::reset()
{
	init();
}
/************************************************************************/
/*  ����                                                                */
/************************************************************************/
void Board::Putone(int i,int j)
{
	/*ż����Ϊ���ӣ�BLACK�ĵ�0λΪ0*/
	if(step&0x1) unit[i][j].Put(CType::WHITE);
	else unit[i][j].Put(CType::BLACK);

	steps[step][0]=i;
	steps[step][1]=j;
	step++;
	stepmax=step;

	fout<<"======================================="<<GetCurrentStep()<<endl;
	dumpqtypeH();
	dumpqtypeW();
	//dumpGlobalList();
}

/************************************************************************/
/*  ����                                                                */
/************************************************************************/
void Board::Back()
{
	assert(step>=0);
	if(step>0){
		step--;
		if(step&0x1) unit[steps[step][0]][steps[step][1]].BackS(CType::WHITE);
		else unit[steps[step][0]][steps[step][1]].BackS(CType::BLACK);
	}
}

/************************************************************************/
/*  ǰ��һ����                                                          */
/************************************************************************/
bool Board::StepForward()			/*ǰ��һ����*/
{
	if(step<stepmax)
	{
		int stepmax_back=stepmax;
		Putone(steps[step][0],steps[step][1]);
		stepmax=stepmax_back;
	}
	else return false;

	return true;
}

/************************************************************************/
/*  ����һ����                                                          */
/************************************************************************/
bool Board::StepBack()
{
	if(step>0)
	{
		Back();
		return true;
	}
	else return false;
}

/************************************************************************/
/*  AIѡ������                                                          */
/************************************************************************/
void Board::AiGo()
{
	if(step==0)
	{
		Putone(7,7);
		return ;
	}
	else if(step==1)
	{
		CPos pos=openbook.GetHand2(CPos(7,7));
		Putone(pos.i,pos.j);
		return ;
	}
	else if(step==2)
	{	
		CPos pos=openbook.GetHand3(CPos(steps[1][0],steps[1][1]));
		Putone(pos.i,pos.j);
		return ;
	}
	
	/*ʹ��AI*/
	int i;
	int depth=2;
	int alpha=-100000000;
	int beta=100000000;
	int val;
	SmartUnit* solve=0;
	SmartUnit* queue;
	
	


	for(i=0;i<=T4::Q3d;i++)
	{
		queue=board.glistH[i].plistH_G->next;
		while(queue)
		{
			board.Putone(queue->pi,queue->pj);
			val=-AIer.AlphabetaSearch_W(depth-1,-beta,-alpha);
			board.Back();
			if(val>=beta){
				solve=queue;
				goto Solve;
			}
			else if(val>alpha){
				solve=queue;
				alpha=val; 
			} 
			queue=queue->plistH_G->next;
		}
	}
	
	for(i=0;i<=T4::Q3d;i++)
	{
		queue=board.glistW[i].plistW_G->next;
		while(queue)
		{
			board.Putone(queue->pi,queue->pj);
			val=-AIer.AlphabetaSearch_W(depth-1,-beta,-alpha);
			board.Back();
			if(val>=beta){
				solve=queue;
				goto Solve;
			}
			else if(val>alpha){ 
				solve=queue;
				alpha=val; 
			} 
			queue=queue->plistW_G->next;
		}
	}
	


	if(solve==0)
	{
		int min=-100000000;
		//for(i=0;i<=T4::Q2;i++)
		for(i=0;i<15;i++)
		{
			for(int j=0;j<15;j++)
			{
				if(unit[i][j].current->isFill) continue;
				
				board.Putone(i,j);
				val=StaticEvaluate();
				fout<<"("<<i<<","<<j<<") : "<<val<<"\t\t";
				//if((i==6 && j==10)||(i==7 && j==9)) fout<<"\n====="<<val<<"====\n";
				board.Back();
				if(val>min){				
					solve=&unit[i][j];
					min=val;
				}		
			}
		}
	}
	assert(solve!=0);

Solve:
	Putone(solve->pi,solve->pj);
}

/************************************************************************/
/*  �Ƿ�����                                                            */
/************************************************************************/
bool Board::IsFill(int i,int j)
{
	return unit[i][j].current->isFill;
}

/************************************************************************/
/*  ��λ����                                                            */
/************************************************************************/
void Board::Hflip()
{
	CPos pos[225];
	for(int k=0;k<step;k++)
	{
		pos[k].i=steps[k][0];
		pos[k].j=steps[k][1];
	}
	CommonOp::Mirror(pos,step);
	for(k=0;k<step;k++)
	{
		steps[k][0]=pos[k].i;
		steps[k][1]=pos[k].j;
	}
}
void Board::Vflip()
{
	CPos pos[225];
	for(int k=0;k<step;k++)
	{
		pos[k].i=steps[k][0];
		pos[k].j=steps[k][1];
	}
	CommonOp::RotateClock(pos,step);
	CommonOp::RotateClock(pos,step);
	CommonOp::Mirror(pos,step);
	for(k=0;k<step;k++)
	{
		steps[k][0]=pos[k].i;
		steps[k][1]=pos[k].j;
	}
}
void Board::Rotate()
{
	CPos pos[225];
	for(int k=0;k<step;k++)
	{
		pos[k].i=steps[k][0];
		pos[k].j=steps[k][1];
	}
	CommonOp::RotateClock(pos,step);
	for(k=0;k<step;k++)
	{
		steps[k][0]=pos[k].i;
		steps[k][1]=pos[k].j;
	}
}

/************************************************************************/
/*  ��̬��������                                                        */
/************************************************************************/
/*
 *	������ľ�̬����������(���жȴ���Q3d��)�����������ļ�Ȩƽ��������������
 *  �����㸺����
 *  ��ĸ����ܶ�ʱ���ܷ��ʵ���С��
 */
int Board::StaticEvaluate()
{
	int score1=0;
	/*
		Q5,		 //��     
		Q4d,	 //����
		Q43,	 //����	
		Q3d_d,   //˫��������ר��
		Q4,		 //����
		Q3d,	 //����
	*/
	SmartUnit *queue;

	/*����*/
	int nr=0;
	int nrr=0;	
	for(int i=0;i<=T4::Q3d;i++)
	{
		nr=0;
		queue=glistH[i].plistH_G->next;
		while(queue){
			queue=queue->plistH_G->next;
			nr++;
		}
		nrr+=nr;
		score1+=(nr*T4::score[i]);
	}
	
	/*����*/
	int score2=0;
	for(i=0;i<=T4::Q3d;i++)
	{
		nr=0;
		queue=glistW[i].plistW_G->next;
		while(queue){
			queue=queue->plistW_G->next;
			nr++;
		}
		nrr+=nr;
		score2-=(nr*T4::score[i]);
	}
	
	return (score1+score2);
}


/************************************************************************/
/*  ��ʽ���                                                            */
/************************************************************************/
void Board::dumpboard()
{
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			unit[i][j].printQ();
		}
		cout<<endl;
	}
	cout<<endl;
}

void Board::dumpqtypeH()
{
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			unit[i][j].printQtypeH();
		}
		fout<<endl;
	}
	fout<<endl;
}
void Board::dumpqtypeW()
{
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			unit[i][j].printQtypeW();
		}
		fout<<endl;
	}
	fout<<endl;
}

void Board::dumpqtypeHC()
{
	for(int i=4;i<12;i++)
	{
		for(int j=4;j<12;j++)
		{
			unit[i][j].printQtypeH();
		}
		cout<<endl;
	}
	cout<<endl;
}
void Board::dumpqtypeWC()
{
	for(int i=4;i<12;i++)
	{
		for(int j=4;j<12;j++)
		{
			unit[i][j].printQtypeW();
		}
		cout<<endl;
	}
	cout<<endl;
}

void Board::checkUnits()
{
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			assert(unit[i][j].pi==i && unit[i][j].pj==j);
		}
	}
}

void Board::dumpGlobalList()
{
	fout<<"===H_list===\n";
	for(int i=0;i<T4::cate;i++)
	{
		fout<<setw(6)<<T4::alias[i]<<":";
		PSmartUnit queue=glistH[i].plistH_G->next;
		while(queue)
		{
			fout<<"("<<queue->pi<<","<<queue->pj<<") ";
			queue=queue->plistH_G->next;
		}
		fout<<endl;
	}
	fout<<"===W_list===\n";
	for(i=0;i<T4::cate;i++)
	{
		fout<<setw(6)<<T4::alias[i]<<":";
		PSmartUnit queue=glistW[i].plistW_G->next;
		while(queue)
		{
			fout<<"("<<queue->pi<<","<<queue->pj<<") ";
			queue=queue->plistW_G->next;
		}
		fout<<endl;
	}
}
void Board::dumpLocalList()
{

}


