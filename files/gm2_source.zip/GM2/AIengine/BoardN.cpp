#include "StdAfx.h"
#include "BoardN.h"
#include "HashPattern.h"
#include "OpenBook.h"
#include "History_Table.h"

#include <iostream>
#include <cstdlib>
#include <cassert>
#include <iomanip> 



using namespace std;


BoardN boardN;

/************************************************************************/
/*  AIѡ������                                                          */
/************************************************************************/
void BoardN::AiGo()
{
	bAISearch=true;
	searched=0;

	/*AI*/
	search_depth=0;
	CPos pos;
	bool result=false;


	if(step==0)
	{
		Putone(7,7);
		goto RETURN;
	}
	else if(step==1)
	{
		CPos pos=openbook.GetHand2(CPos(7,7));
		Putone(pos.i,pos.j);
		goto RETURN;
	}
	else if(step==2)
	{	
		CPos pos=openbook.GetHand3(CPos(steps[1][0],steps[1][1]));
		Putone(pos.i,pos.j);
		goto RETURN;
	}
	
	
#ifdef BOARD_STATISTIC
	ResetBoardNr();
#endif


#if SEARCH_TO_FILE
	fout<<"======"<<step+1<<"======="<<endl;
	dumpqtypeH();
	dumpqtypeW();
#endif
	

#ifdef USE_HISTORYTBL
	history_tbl->Clear();
#endif
	
	/************************************************************************/
	/* ����                                                                 */
	/************************************************************************/
	if(step&0x1)
	{
		int dp=1;
		while((!result) && (dp<=GLOBAL_DEPTH)){
			result=AttackW(dp,pos);
			dp=dp+2;
		}
	}
	/************************************************************************/
	/* ����                                                                 */
	/************************************************************************/
	else{
		int dp=1;
		while((!result) && (dp<=GLOBAL_DEPTH)){
			result=AttackH(dp,pos);
			dp=dp+2;
		}
	}
	
	
#ifdef BOARD_STATISTIC
	DumpBoardNr();
#endif
	if(result)
	{
		PutOne(pos.i,pos.j);
	}else{
		AISearch(pos);
		assert(TESTVALID(pos.i,pos.j));
		if(TESTVALID(pos.i,pos.j)==false) fout<<" pos foul:"<<pos.i<<","<<pos.j<<endl;

		PutOne(pos.i,pos.j);
					
		bAISearch=false;
		fout<<" >>>> searched nodes = "<<searched<<endl;
	}

RETURN:

	return;
}


/************************************************************************/
/*  ���졢��������                                                      */
/************************************************************************/
void BoardN::inithashTable()
{
	hash_pattern.GenerateHash();
	nodes=new AlyNode[NodeNumber];

#ifdef USE_HISTORYTBL
	//��ʼ���û���
	History_Table::Singleton();
#endif
}

BoardN::BoardN()
{

}


BoardN::~BoardN()
{
	init();
}


void BoardN::init()
{
	int i,j;

	for(i=0;i<15+2;i++)
	{
		for(j=0;j<15+2;j++){
			if(i==0 || i==16 || j==0 || j==16)
			{
				boardT[0][i][j]=1;
				boardT[1][i][j]=1;			
			}
			else
			{
				boardT[0][i][j]=0;
				boardT[1][i][j]=0;
			}
		}
	}

	for(i=0;i<15;i++)
	{
		for(j=0;j<15;j++){
			qType[0][i][j].Reset();
			qType[1][i][j].Reset();
		}
	}

	for(i=0;i<STACK_DEPTH;i++)
	{
		qTypeGroup[0][i].Clear();
		qTypeGroup[1][i].Clear();
	}


	/*
	for(i=0;i<T4::cate;i++)
	{
		glistH[i].Reset();
		glistW[i].Reset();
		llistH[i].Reset();
		llistW[i].Reset();
	}
	for(i=0;i<15;i++)
	{
		for(j=0;j<15;j++){
			listmapH[i][j].Reset();
			listmapW[i][j].Reset();
		}
	}
	*/

	/*�ص���һ��*/
	step=0;
	stepmax=0;
	current=0;
	gameover=false;
	blackfoul=false;

}
/************************************************************************/
/*  ��λ                                                                */
/************************************************************************/
void BoardN::reset()
{
	init();
}



/************************************************************************/
/*  ����                                                                */
/************************************************************************/
int xl[4]={-1,-1,0,1};
int yl[4]={0,1,1,1};
int xr[4]={1,1,0,-1};
int yr[4]={0,-1,-1,-1};
void BoardN::PutOne(int i,int j){
	/*�ж�ʱ����Ϸ����*/
	if((step&0x1)==0){
		if(qType[0][i][j].qTYPE==T4::Q5){
			gameover=true;
		}
		if(qType[0][i][j].qTYPE==T4::Qfoul){ /*������֣�*/
			gameover=true;
			blackfoul=true;
		}
	}else{
		if(qType[1][i][j].qTYPE==T4::Q5){
			gameover=true;
		}
	}
	Putone(i,j);
}

void BoardN::Putone(int i,int j)
{
//	if(TESTVALID(i,j)==false){
//		return;
//	}
	assert(TESTVALID(i,j));


#if SEARCH_TO_FILE
	fout<<step+1<<"-"<<current+1<<":"<<i<<","<<j<<" : ";
	fout<<T4::alias[qType[step&0x1][i][j].qTYPE]<<endl;
#endif
#ifdef BOARD_STATISTIC
	boardNr[i][j]++;
#endif

	if(boardT[0][i+1][j+1]!=0 || boardT[1][i+1][j+1]!=0) fout<<" overlap : "<<step+1<<"("<<i<<","<<j<<")"<<endl;
	assert(boardT[0][i+1][j+1]==0 && boardT[1][i+1][j+1]==0);

	/*
	 ע�⣺boardT�����i,j�Ǵ�1��15��������鶼��0��14
	 */
	QTYPE_FORWARD();
	qTypeGroup[0][current].Clear();
	qTypeGroup[1][current].Clear(); 

	int r1;
	int r2;
	int s_i;
	int s_j;
	int x,y;
	int hash;
	HashItem *it;

	/*ż����Ϊ����*/
	int t;
	if(step&0x1) t=1;
	else t=0;
	
	/* ���� */
	boardT[t][i+1][j+1]=1;
	qType[0][i][j].qBACK=qType[0][i][j].qTYPE;
	qType[0][i][j].qTYPE=T4::Qfill;
	qType[1][i][j].qBACK=qType[1][i][j].qTYPE;
	qType[1][i][j].qTYPE=T4::Qfill;
	for(int d=0;d<4;d++)
	{
		/*-----------------------����-------------------*/
		if(qType[t][i][j].qtype[d]==T1::QNohope) goto GOON1;
		/*ɨ�����*/
		x=i+1;
		y=j+1;
		for(r1=0;;r1++)
		{
			x+=xl[d];
			y+=yl[d];
			/*������Է��赲������*/
			if(boardT[1-t][x][y]) break;
		}
		x=i+1;
		y=j+1;
		/*ɨ���Ҳ�*/
		for(r2=0;;r2++)
		{
			x+=xr[d];
			y+=yr[d];
			/*������Է��赲������*/
			if(boardT[1-t][x][y]) break;
		}
		/*�ܳ���*/
		int len;
		len=r1+r2+1;
		int k;
		if(len>=5)
		{
			hash=0;
			/*�������Ҽ���hashֵ*/
			for(s_i=i+1+r1*xl[d],s_j=j+1+r1*yl[d],k=0;k<len;s_i=s_i+xr[d],s_j=s_j+yr[d],k++)
			{
				hash=(hash<<1)+boardT[t][s_i][s_j];
			}
			it=hash_pattern.Query(hash,len);
			/*�������Ҹ���*/
			for(s_i=i+r1*xl[d],s_j=j+r1*yl[d],k=0;k<len;s_i=s_i+xr[d],s_j=s_j+yr[d],k++)
			{
				/*�����ǿ�λ*/
				if(boardT[t][s_i+1][s_j+1]==0)
				{
					QTYPE_REFRESH(t,s_i,s_j,d,it->qtype[k]);
				}
			}
		}

GOON1:
		/*-----------------------�Է�-------------------*/
		if(qType[1-t][i][j].qtype[d]==T1::QNohope) goto GOON2;
		/* a�ࣨ��ࣩ */
		x=i+1;
		y=j+1;
		for(r1=0;;r1++)
		{
			x+=xl[d];
			y+=yl[d];
			if(boardT[t][x][y]) break;		
		}
		if(r1>=1)
		{
			hash=0;
			for(s_i=i+1+xl[d],s_j=j+1+yl[d],k=0;k<r1;s_i=s_i+xl[d],s_j=s_j+yl[d],k++)
			{
				hash=(hash<<1)+boardT[1-t][s_i][s_j];
			}	
			it=hash_pattern.Query(hash,r1);
			for(s_i=i+xl[d],s_j=j+yl[d],k=0;k<r1;s_i=s_i+xl[d],s_j=s_j+yl[d],k++)
			{
				if(boardT[1-t][s_i+1][s_j+1]==0)
				{
					QTYPE_REFRESH(1-t,s_i,s_j,d,it->qtype[k]);
				}
			}
		}
//		else if(r1>0)
//		{
//			for(s_i=i+xl[d],s_j=j+yl[d],k=0;k<r1;s_i=s_i+xl[d],s_j=s_j+yl[d],k++)
//			{
//				if(boardT[1-t][s_i+1][s_j+1]==0)
//				{
//					QTYPE_REFRESH(1-t,s_i,s_j,d,T1::QNohope);
//				}
//			}
//		}
		/* b�� */
		x=i+1;
		y=j+1;
		for(r1=0;;r1++)
		{
			x+=xr[d];
			y+=yr[d];
			if(boardT[t][x][y]) break;
		}
		if(r1>=1)
		{
			hash=0;
			for(s_i=i+1+xr[d],s_j=j+1+yr[d],k=0;k<r1;s_i=s_i+xr[d],s_j=s_j+yr[d],k++)
			{
				hash=(hash<<1)+boardT[1-t][s_i][s_j];
			}	
			it=hash_pattern.Query(hash,r1);
			for(s_i=i+xr[d],s_j=j+yr[d],k=0;k<r1;s_i=s_i+xr[d],s_j=s_j+yr[d],k++)
			{
				if(boardT[1-t][s_i+1][s_j+1]==0)
				{
					QTYPE_REFRESH(1-t,s_i,s_j,d,it->qtype[k]);
				}
			}
		}
//		else if(r1>0)
//		{
//			for(s_i=i+xr[d],s_j=j+yr[d],k=0;k<r1;s_i=s_i+xr[d],s_j=s_j+yr[d],k++)
//			{
//				if(boardT[1-t][s_i+1][s_j+1]==0)
//				{
//					QTYPE_REFRESH(1-t,s_i,s_j,d,T1::QNohope);
//				}
//			}
//		}
		
GOON2:
		continue;
	}

	/*���¼��㱻Ӱ��ĵ�*/
	Recal();

#if BOARD_TO_FILE
	dumpqtypeH();
	dumpqtypeW();
	//dumpboard_d();
#endif

	steps[step][0]=i;
	steps[step][1]=j;
	step++;
	search_depth++;
	stepmax=step;

	searched++;//����ͳ�ƣ�������������

#ifdef USE_HISTORYTBL
/*******************************����hashֵ*******************************/
	if(bAISearch){
		if(search_depth==1){
			if((step&0x1)==0){
				acc1[1]=POS(steps[step-1][0],steps[step-1][1]);
				a_hash1[1]=POS(steps[step-1][0],steps[step-1][1]);
				acc2[1]=1;
				a_hash2[1]=0;
			}else{
				acc1[1]=1;
				a_hash1[1]=0;
				acc2[1]=POS(steps[step-1][0],steps[step-1][1]);
				a_hash2[1]=POS(steps[step-1][0],steps[step-1][1]);
			}
		}else if(search_depth>1){
			if((step&0x1)==0){
				acc1[search_depth]=acc1[search_depth-1]*POS(steps[step-1][0],steps[step-1][1]);
				a_hash1[search_depth]=a_hash1[search_depth-1]+POS(steps[step-1][0],steps[step-1][1]);
				acc2[search_depth]=acc2[search_depth-1];
				a_hash2[search_depth]=a_hash2[search_depth-1];
				
			}else{
				acc2[search_depth]=acc2[search_depth-1]*POS(steps[step-1][0],steps[step-1][1]);
				a_hash2[search_depth]=a_hash2[search_depth-1]+POS(steps[step-1][0],steps[step-1][1]);
				acc1[search_depth]=acc1[search_depth-1];
				a_hash1[search_depth]=a_hash1[search_depth-1];
			}
		}
	}
/************************************************************************/
#endif	
}

/************************************************************************/
/*  ���¼���������                                                    */
/************************************************************************/
void BoardN::Recal()
{
	int i;
	QTypeGroup &qG0=qTypeGroup[0][current];
	for(i=0;i<qG0.nr;i++)
	{
		qType[0][qG0.p[i][0]][qG0.p[i][1]].RecalH();
	}
	QTypeGroup &qG1=qTypeGroup[1][current];
	for(i=0;i<qG1.nr;i++)
	{
		qType[1][qG1.p[i][0]][qG1.p[i][1]].RecalW();
	}
}

/************************************************************************/
/*  ����                                                                */
/************************************************************************/
void BoardN::Back()
{
	QTYPE_RECOVER();
	QTYPE_BACK();
	step--;
	search_depth--;
	int i,j;
	i=steps[step][0];
	j=steps[step][1];
	assert(qType[0][i][j].qBACK!=T4::Qfill);
	assert(qType[1][i][j].qBACK!=T4::Qfill);
	qType[0][i][j].qTYPE=qType[0][i][j].qBACK;
	qType[1][i][j].qTYPE=qType[1][i][j].qBACK;
	boardT[0][i+1][j+1]=0;
	boardT[1][i+1][j+1]=0;

#if BOARD_TO_FILE
	//dumpboard_d();
	dumpqtypeH();
	dumpqtypeW();
#endif
}


/************************************************************************/
/* ��ý���б�                                                         */
/************************************************************************/
void  BoardN::GetH_L(int c) /*���ָ���㼶�ľֲ������ѡ*/
{
	int i,j,t,k;
	/* ��ǰ���� */
	int xx=steps[c-1][0];
	int yy=steps[c-1][1];

	for(t=0;t<T4::Q2;t++)
	{
		listNnr[0][c][t]=0;
	}
	for(k=0;k<qTypeGroup[0][c].nr;k++)
	{
		i=qTypeGroup[0][c].p[k][0];
		j=qTypeGroup[0][c].p[k][1];
		/*���ǰѾֲ���������һ���ӵİ˸������ƫ��4֮��*/
		if(i-xx>4 || xx-i>4 || j-yy>4 || yy-j>4) continue;

		//VALID(i,j);
		assert(TESTVALID(i,j));
		t=qType[0][i][j].qTYPE;
		if(t<T4::Q2) listN[0][c][t][listNnr[0][c][t]++]=CPos(i,j);
	}	
}

#define OFF_SET 7
void BoardN::GetH_G(int c,bool all)
{
	int i,j,t;

	/*�ֲ���Ӧ������ȫ�ֵ�*/
	for(t=0;t<T4::Q2;t++) listNnr[0][c][t]=0;
//	if(all==false) GetH_L(c);
//	int nrtmp[T4::Q3];
//	for(t=0;t<T4::Q3;t++) nrtmp[t]=listNnr[0][c][t];
	
	int x1,x2,y1,y2,xx,yy;
	xx=steps[c-1][0];
	yy=steps[c-1][1];
	if(all==false)
	{
		x1=(xx-OFF_SET>=0)?xx-OFF_SET:0;
		x2=(xx+OFF_SET<=14)?xx+OFF_SET:14;
		y1=(yy-OFF_SET>=0)?yy-OFF_SET:0;
		y2=(yy+OFF_SET<=14)?yy+OFF_SET:14;
	}else{
		x1=0;
		x2=14;
		y1=0;
		y2=14;
	}
	for(i=x1;i<=x2;i++)
	{
		for(j=y1;j<=y2;j++)
		{	
			//VALID(i,j);
			assert(TESTVALID(i,j));
			t=qType[0][i][j].qTYPE;
			if(t<T4::Q3){  
				/*�����ظ�*/
//				for(int r=0;r<nrtmp[r];r++){
//					if(listN[0][c][t][r]==CPos(i,j)) 
//						goto Continue;
// 				}
				listN[0][c][t][listNnr[0][c][t]++]=CPos(i,j);
//Continue:
//				continue;
			}
		}
	}
}

void BoardN::GetW_L(int c) /*���ָ���㼶�ľֲ������ѡ*/
{
	int i,j,t,k;
	/* ��ǰ���� */
	int xx=steps[c-1][0];
	int yy=steps[c-1][1];
	
	for(t=0;t<T4::Q2;t++)
	{
		listNnr[1][c][t]=0;
	}
	for(k=0;k<qTypeGroup[1][c].nr;k++)
	{
		i=qTypeGroup[1][c].p[k][0];
		j=qTypeGroup[1][c].p[k][1];

		/*���ǰѾֲ���������һ���ӵİ˸������ƫ��4֮��*/
		if(i-xx>4 || xx-i>4 || j-yy>4 || yy-j>4) continue;

		//VALID(i,j);
		assert(TESTVALID(i,j));
		t=qType[1][i][j].qTYPE;
		if(t<T4::Q2)  listN[1][c][t][listNnr[1][c][t]++]=CPos(i,j);
	}
}

void BoardN::GetW_G(int c,bool all)
{
	int i,j,t;
	
	/*�ֲ���Ӧ������ȫ�ֵ�*/
	for(t=0;t<T4::Q2;t++) listNnr[1][c][t]=0;
//	if(all==false) GetW_L(c);
//	int nrtmp[T4::Q3];
//	for(t=0;t<T4::Q3;t++) nrtmp[t]=listNnr[1][c][t];

	int x1,x2,y1,y2,xx,yy;
	xx=steps[c-1][0];
	yy=steps[c-1][1];
	if(all==false)
	{
		x1=(xx-OFF_SET>=0)?xx-OFF_SET:0;
		x2=(xx+OFF_SET<=14)?xx+OFF_SET:14;
		y1=(yy-OFF_SET>=0)?yy-OFF_SET:0;
		y2=(yy+OFF_SET<=14)?yy+OFF_SET:14;
	}else{
		x1=0;
		x2=14;
		y1=0;
		y2=14;
	}
	for(i=x1;i<=x2;i++)
	{
		for(j=y1;j<=y2;j++)
		{
			//VALID(i,j);
			assert(TESTVALID(i,j));
			t=qType[1][i][j].qTYPE;
			if(t<T4::Q3){
				/*�����ظ�*/
//				for(int r=0;r<nrtmp[r];r++){
//					if(listN[1][c][t][r]==CPos(i,j)) 
//						goto Continue;
//				}
				listN[1][c][t][listNnr[1][c][t]++]=CPos(i,j);
//Continue:
//				continue;
			}
		}
	}
}

/*��������ķ��ص�,������xx[],yy[]�У������϶�Ϊ3*/
void BoardN::GetSkip3(int t,int i,int j,int xx[],int yy[],int &nr)
{
	int d;	
	xx[0]=i;
	yy[0]=j;
	/*�ҵ����ĵķ���*/
	for(d=0;d<4;d++)
	{
		if(qType[t][i][j].qtype[d]==T1::Q4d) break;;
	}
	if(d==4){
		/*������˫��Ҳ�м������ص㣬��������ȡ��ǿ��*/
		nr=1;	
		return;
	}

	xx[1]=xx[0]+1*xl[d];
	yy[1]=yy[0]+1*yl[d];
	for(;boardT[t][xx[1]+1][yy[1]+1];xx[1]+=xl[d],yy[1]+=yl[d]);
	
	xx[2]=xx[0]+1*xr[d];
	yy[2]=yy[0]+1*yr[d];
	for(;boardT[t][xx[2]+1][yy[2]+1];xx[2]+=xr[d],yy[2]+=yr[d]);	
	
	nr=3;
}

/************************************************************************/
/*  ǰ��һ����                                                          */
/************************************************************************/
bool BoardN::StepForward()			/*ǰ��һ����*/
{
	if(step<stepmax)
	{
		int stepmax_back=stepmax;
		Putone(steps[step][0],steps[step][1]);
		stepmax=stepmax_back;
	}
	else return false;

	return true;
}

/************************************************************************/
/*  ����һ����                                                          */
/************************************************************************/
bool BoardN::StepBack()
{
	gameover=false;
	blackfoul=false;
	if(step>0)
	{
		Back();
		return true;
	}
	else return false;
}


/************************************************************************/
/*  �Ƿ�����                                                            */
/************************************************************************/
bool BoardN::IsFill(int i,int j)
{
	return (boardT[0][i+1][j+1] || boardT[1][i+1][j+1]);
}

/************************************************************************/
/*  ��λ����                                                            */
/************************************************************************/
void BoardN::Hflip()
{
	CPos pos[225];
	for(int k=0;k<stepmax;k++)
	{
		pos[k].i=steps[k][0];
		pos[k].j=steps[k][1];
	}
	CommonOp::Mirror(pos,step);
	int steptmp=step;
	while(StepBack());
	for(k=0;k<stepmax;k++)
	{
		steps[k][0]=pos[k].i;
		steps[k][1]=pos[k].j;
	}
	for(k=0;k<steptmp;k++) Putone(pos[k].i,pos[k].j);
}
void BoardN::Vflip()
{
	CPos pos[225];
	for(int k=0;k<stepmax;k++)
	{
		pos[k].i=steps[k][0];
		pos[k].j=steps[k][1];
	}
	CommonOp::RotateClock(pos,step);
	CommonOp::RotateClock(pos,step);
	CommonOp::Mirror(pos,step);
	int steptmp=step;
	while(StepBack());
	for(k=0;k<stepmax;k++)
	{
		steps[k][0]=pos[k].i;
		steps[k][1]=pos[k].j;
	}
	for(k=0;k<steptmp;k++) Putone(pos[k].i,pos[k].j);
}
void BoardN::Rotate()
{
	CPos pos[225];
	for(int k=0;k<stepmax;k++)
	{
		pos[k].i=steps[k][0];
		pos[k].j=steps[k][1];
	}
	CommonOp::RotateClock(pos,step);
	int steptmp=step;
	while(StepBack());
	for(k=0;k<stepmax;k++)
	{
		steps[k][0]=pos[k].i;
		steps[k][1]=pos[k].j;
	}
	for(k=0;k<steptmp;k++) Putone(pos[k].i,pos[k].j);
}

/************************************************************************/
/*  ��ʽ���                                                            */
/************************************************************************/

void BoardN::dumpboard()
{
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			if(boardT[0][i+1][j+1])
			{
				fout<<setw(2)<<"*";
			}
			else if(boardT[1][i+1][j+1])
			{
				fout<<setw(2)<<"+";
			}
			else fout<<setw(2)<<"";
		}
		fout<<endl;
	}
	fout<<endl;
}

void BoardN::dumpboard_d()
{
	dumpboard();
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			if(boardT[0][i+1][j+1]) 
			{
				fout<<setw(6)<<T4::alias[qType[0][i][j].qTYPE];
				/*
				if(qType[0][i][j].qTYPE!=T4::Qfill)
				{
					fout<<setw(6)<<T4::alias[qType[0][i][j].qTYPE];
					//assert(0);
				}*/
			}
			else if(boardT[1][i+1][j+1])
			{
				fout<<setw(6)<<T4::alias[qType[1][i][j].qTYPE];
				/*
				if(qType[1][i][j].qTYPE!=T4::Qfill)
				{
					fout<<setw(6)<<T4::alias[qType[1][i][j].qTYPE];
					//assert(0);
				}
				*/
			}
			else fout<<setw(6)<<"";
		}
		fout<<endl;
	}
	fout<<endl;
}
    
void BoardN::dumpqtypeH()
{
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			if(boardT[0][i+1][j+1]) 
			{
				if(qType[0][i][j].qTYPE!=T4::Qfill)
				{
					assert(0);
				}
				fout<<setw(6)<<(char)('*');
			}
			else if(boardT[1][i+1][j+1])
			{
				if(qType[1][i][j].qTYPE!=T4::Qfill)
				{
					assert(0);
				}
				fout<<setw(6)<<(char)('+');
			}
			else fout<<setw(6)<<T4::alias[qType[0][i][j].qTYPE];
		}
		fout<<endl;
	}
	fout<<endl;
} 

void BoardN::dumpqtypeW()
{
	for(int i=0;i<15;i++)
	{
		for(int j=0;j<15;j++)
		{
			if(boardT[0][i+1][j+1]) 
			{
				if(qType[0][i][j].qTYPE!=T4::Qfill)
				{
					assert(0);
				}
				fout<<setw(6)<<(char)('*');
			}
			else if(boardT[1][i+1][j+1])
			{
				if(qType[1][i][j].qTYPE!=T4::Qfill)
				{
					assert(0);
				}
				fout<<setw(6)<<(char)('+');
			}
			else fout<<setw(6)<<T4::alias[qType[1][i][j].qTYPE];
		}
		fout<<endl;
	}
	fout<<endl;
}      

void BoardN::ResetBoardNr()
{
	for(int xxx=0;xxx<15;xxx++) 
		for(int yyy=0;yyy<15;yyy++) 
			boardNr[xxx][yyy]=0; 
}

void BoardN::DumpBoardNr()
{
	for(int xxx=0;xxx<15;xxx++){
		for(int yyy=0;yyy<15;yyy++){ 
			if(boardT[0][xxx+1][yyy+1]) fout<<setw(4)<<"*"; 
			else if(boardT[1][xxx+1][yyy+1]) fout<<setw(4)<<"+";  
			else if((qType[0][xxx][yyy].qTYPE<=T4::Q3d) || (qType[1][xxx][yyy].qTYPE<=T4::Q3d))
				fout<<setw(4)<<"";
			else if(boardNr[xxx][yyy]==0) fout<<setw(4)<<""; 
			else fout<<setw(4)<<boardNr[xxx][yyy];} 
		fout<<endl;
	} 	
}

