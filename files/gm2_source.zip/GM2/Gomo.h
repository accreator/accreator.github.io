// Gomo.h : main header file for the GOMO application
//

#if !defined(AFX_GOMO_H__DE7527D3_1A33_46D2_981D_F59B268C3CBE__INCLUDED_)
#define AFX_GOMO_H__DE7527D3_1A33_46D2_981D_F59B268C3CBE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CGomoApp:
// See Gomo.cpp for the implementation of this class
//

class CGomoApp : public CWinApp
{
public:
	CGomoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGomoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CGomoApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GOMO_H__DE7527D3_1A33_46D2_981D_F59B268C3CBE__INCLUDED_)
