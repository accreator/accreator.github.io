// GomoDoc.cpp : implementation of the CGomoDoc class
//

#include "stdafx.h"
#include "Gomo.h"

#include "GomoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGomoDoc

IMPLEMENT_DYNCREATE(CGomoDoc, CDocument)

BEGIN_MESSAGE_MAP(CGomoDoc, CDocument)
	//{{AFX_MSG_MAP(CGomoDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGomoDoc construction/destruction

CGomoDoc::CGomoDoc()
{
}

CGomoDoc::~CGomoDoc()
{
}

BOOL CGomoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGomoDoc serialization

void CGomoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGomoDoc diagnostics

#ifdef _DEBUG
void CGomoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGomoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGomoDoc commands
