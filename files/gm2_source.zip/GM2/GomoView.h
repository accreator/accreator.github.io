// GomoView.h : interface of the CGomoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GOMOVIEW_H__4F102E01_D64A_430A_A3E8_F9464051C89B__INCLUDED_)
#define AFX_GOMOVIEW_H__4F102E01_D64A_430A_A3E8_F9464051C89B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGomoView : public CFormView
{
/************************************************************************/
/*      �Զ������                                                      */
/************************************************************************/
private:
	CString m_filepath;
	/*UI���Ʊ���*/
	CRect rc_control;//�������rc
	CBrush  m_ControlBrush;   
	CPen m_ControlPen;
	COLORREF m_ControlColor;
	COLORREF  m_TextColor; 
/************************************************************************/


protected: // create from serialization only
	CGomoView();
	DECLARE_DYNCREATE(CGomoView)

public:
	//{{AFX_DATA(CGomoView)
	enum{ IDD = IDD_GOMO_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CGomoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGomoView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGomoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGomoView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnFileNew();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMoveFirst();
	afx_msg void OnMoveLast();
	afx_msg void OnMoveNext();
	afx_msg void OnMovePre();
	afx_msg void OnViewHflip();
	afx_msg void OnViewRotate();
	afx_msg void OnViewVflip();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileSave();
	afx_msg void OnMoveAigo();
	afx_msg void OnMoveAuto();
	afx_msg void OnCpBoad();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GomoView.cpp
inline CGomoDoc* CGomoView::GetDocument()
   { return (CGomoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GOMOVIEW_H__4F102E01_D64A_430A_A3E8_F9464051C89B__INCLUDED_)
