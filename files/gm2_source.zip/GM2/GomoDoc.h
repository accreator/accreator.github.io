// GomoDoc.h : interface of the CGomoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GOMODOC_H__ACF2756F_4A38_4712_9C77_A61DFC28F938__INCLUDED_)
#define AFX_GOMODOC_H__ACF2756F_4A38_4712_9C77_A61DFC28F938__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGomoDoc : public CDocument
{
protected: // create from serialization only
	CGomoDoc();
	DECLARE_DYNCREATE(CGomoDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGomoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGomoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGomoDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GOMODOC_H__ACF2756F_4A38_4712_9C77_A61DFC28F938__INCLUDED_)
