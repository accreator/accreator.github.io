 // GomoView.cpp : implementation of the CGomoView class
//

#include "stdafx.h"
#include "Gomo.h"

#include "GomoDoc.h"
#include "GomoView.h"

/************************************************************************/
/*      ����ͷ�ļ�		                                                */
/************************************************************************/
#include "WinBoard/WinBoard.h" /*WinBoard����*/
#include "WinBoard/GameCtrl.h"
/************************************************************************/

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGomoView

IMPLEMENT_DYNCREATE(CGomoView, CFormView)

BEGIN_MESSAGE_MAP(CGomoView, CFormView)
	//{{AFX_MSG_MAP(CGomoView)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_MOVE_FIRST, OnMoveFirst)
	ON_COMMAND(ID_MOVE_LAST, OnMoveLast)
	ON_COMMAND(ID_MOVE_NEXT, OnMoveNext)
	ON_COMMAND(ID_MOVE_PRE, OnMovePre)
	ON_COMMAND(ID_VIEW_HFLIP, OnViewHflip)
	ON_COMMAND(ID_VIEW_ROTATE, OnViewRotate)
	ON_COMMAND(ID_VIEW_VFLIP, OnViewVflip)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_MOVE_AIGO, OnMoveAigo)
	ON_COMMAND(ID_MOVE_AUTO, OnMoveAuto)
	ON_COMMAND(ID_CP_BOAD, OnCpBoad)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGomoView construction/destruction

CGomoView::CGomoView()
	: CFormView(CGomoView::IDD)
{
	//{{AFX_DATA_INIT(CGomoView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

}

CGomoView::~CGomoView()
{
}

void CGomoView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGomoView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CGomoView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFormView::PreCreateWindow(cs);
}

void CGomoView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CGomoView diagnostics

#ifdef _DEBUG
void CGomoView::AssertValid() const
{
	CFormView::AssertValid();
}

void CGomoView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGomoDoc* CGomoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGomoDoc)));
	return (CGomoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGomoView message handlers

int CGomoView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here

	/************************************************************************/
	/*   OnCreate.   ��ʼ��WinBoard                                         */
	/************************************************************************/
	CRect rc1,rc2;
	CDC *dc;
	this->GetClientRect(&rc1);
	dc=this->GetDC();
	rc2=rc1;
	//����
	rc2.right-=rc1.Width()-rc1.Height();

	//�����ڴ滺����
	winBoard.SetClient(dc,&rc2);

	//�������rc
	rc_control=rc1;
	rc_control.left=rc1.Height();

	//�ͷ�dc
	this->ReleaseDC(dc);

	/*����*/
	OnFileNew();
	/************************************************************************/
	
	return 0;
}

void CGomoView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	/************************************************************************/
	/*   OnPaint.   WinBoard���Ƽ�������                                    */
	/************************************************************************/
	//������
	gameCtrl.Paint(&dc);
	
	/************************************************************************/
	
	// Do not call CFormView::OnPaint() for painting messages
}

void CGomoView::OnFileNew() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/*   ���¿�ʼ                                                           */
	/************************************************************************/
	m_filepath="";
	gameCtrl.Reset();
	this->Invalidate(FALSE);
	/************************************************************************/
}

void CGomoView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	/************************************************************************/
	/* ���������������                                                     */
	/************************************************************************/
	if(gameCtrl.IsGameOver()){
		CFormView::OnLButtonDown(nFlags, point);
		AfxMessageBox("�ѽ�����");
		return;
	}

	CPoint pos=winBoard.Coordinate(point);
	CDC *pdc=this->GetDC();
	if(pos!=CPoint(-1,-1)){
		//�Ѿ����ӵĵط������Ч
		if(gameCtrl.IsFill(pos.y,pos.x)) return;

		gameCtrl.Putone(pos.y,pos.x);
		gameCtrl.Paint(pdc);

		if(gameCtrl.Test(GameCtrl::AIAUTO) && (!gameCtrl.IsGameOver())) gameCtrl.AIgo();
		gameCtrl.Paint(pdc);
		
	}
	ReleaseDC(pdc);

	gameCtrl.AlertGameOver();
	/************************************************************************/
	
	CFormView::OnLButtonDown(nFlags, point);
}

void CGomoView::OnMoveFirst() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/*                                                                      */
	/************************************************************************/
	gameCtrl.MoveFirst();
	this->Invalidate(FALSE);
}

void CGomoView::OnMoveLast() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/*                                                                      */
	/************************************************************************/
	gameCtrl.MoveLast();
	this->Invalidate(FALSE);	
}

void CGomoView::OnMoveNext() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/*                                                                      */
	/************************************************************************/
	gameCtrl.MoveNext();
	this->Invalidate(FALSE);	
}

void CGomoView::OnMovePre() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/*                                                                      */
	/************************************************************************/
	gameCtrl.MovePre();
	this->Invalidate(FALSE);	
}

void CGomoView::OnViewHflip() 
{
	// TODO: Add your command handler code here
	gameCtrl.Hflip();
	this->Invalidate(FALSE);		
}

void CGomoView::OnViewRotate() 
{
	// TODO: Add your command handler code here
	gameCtrl.Rotate();
	this->Invalidate(FALSE);		
}

void CGomoView::OnViewVflip() 
{
	// TODO: Add your command handler code here
	gameCtrl.Vflip();
	this->Invalidate(FALSE);		
}

void CGomoView::OnFileOpen() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/* ������ļ�                                                         */
	/************************************************************************/
	CFileDialog dlg(TRUE,NULL,NULL,
		OFN_ALLOWMULTISELECT,
		_T("����ļ�(*.pos)|*.pos"),
		AfxGetMainWnd());
	if (dlg.DoModal()==IDOK)
	{
		m_filepath=dlg.GetPathName();
		gameCtrl.LoadGame(m_filepath);
	} 
	
	this->Invalidate(FALSE);	
	/************************************************************************/
}

void CGomoView::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/* �������                                                             */
	/************************************************************************/
	CFileDialog dlg(FALSE, NULL, NULL,
		OFN_HIDEREADONLY| OFN_OVERWRITEPROMPT,
		_T("����ļ�(*.pos)|*.pos")); 
	if ( dlg.DoModal()!=IDOK )
		return;
	//��ȡ�ļ��ľ���·��
	m_filepath=dlg.GetPathName();
	gameCtrl.SaveGame(m_filepath);
	/************************************************************************/

}

void CGomoView::OnFileSave() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/* �������                                                             */
	/************************************************************************/
	if(m_filepath==""){
		OnFileSaveAs();
	}else{
		gameCtrl.SaveGame(m_filepath);
	}
	/************************************************************************/	
}

void CGomoView::OnMoveAigo() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/* AI����                                                               */
	/************************************************************************/
	if(gameCtrl.IsGameOver()){
		AfxMessageBox("�ѽ�����");
		return;
	}
	
	gameCtrl.AIgo();
	this->Invalidate(FALSE);

	gameCtrl.AlertGameOver();
	/************************************************************************/
}

void CGomoView::OnMoveAuto() 
{
	// TODO: Add your command handler code here
	/************************************************************************/
	/*     �Զ������Զ��л�                                                 */
	/************************************************************************/
	bool ison=gameCtrl.Switch(GameCtrl::AIAUTO);

	/************************************************************************/
}

void CGomoView::OnCpBoad() 
{
	// TODO: Add your command handler code here
	gameCtrl.CopyBoad((CWnd *)this);
}
