//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Gomo.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_GOMO_FORM                   101
#define IDR_MAINFRAME                   128
#define IDR_GOMOTYPE                    129
#define ID_MOVE_NEXT                    32782
#define ID_MOVE_PRE                     32783
#define ID_MOVE_FIRST                   32784
#define ID_MOVE_LAST                    32785
#define ID_LEVEL_D3                     32786
#define ID_LEVEL_D2                     32787
#define ID_LEVEL_D1                     32788
#define ID_LEVEL_G2                     32790
#define ID_LEVEL_G4                     32791
#define ID_LEVEL_G6                     32792
#define ID_LEVEL_G10                    32793
#define ID_VIEW_HFLIP                   32794
#define ID_VIEW_VFLIP                   32795
#define ID_VIEW_ROTATE                  32796
#define ID_MOVE_AUTO                    32797
#define ID_MOVE_AIGO                    32798
#define ID_CP_BOAD                      32799
#define ID_STUDY                        32800
#define ID_LIB_BASE                     32801
#define ID_LIB_OPEN                     32802
#define ID_LIB_ADD                      32803
#define ID_LIB_VERIFY                   32804
#define ID_CFG_COLOR                    32805
#define ID_CFG_FOUL                     32806
#define ID_MENUITEM32807                32807
#define ID_CONFIG                       32808
#define ID_VCT                          32809

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
