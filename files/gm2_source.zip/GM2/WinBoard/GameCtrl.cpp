#include "StdAfx.h"

#include "WinBoard.h"
#include "GameCtrl.h"
#include "../AIengine/AIengineIF.h"

#include <iostream>
#include <fstream>
#include <string>


//#define TEST_TIME
//#define TEST_TIMES 100

using namespace std;

GameCtrl gameCtrl;


/************************************************************************/
/* ���졢��������                                                       */
/************************************************************************/
GameCtrl::GameCtrl()
{
	viewStyle.set(AIAUTO);
	
}
GameCtrl::~GameCtrl()
{

}

/************************************************************************/
/*  ��ʼһ����                                                          */
/************************************************************************/
void GameCtrl::Init()
{
	AI.InitHashTable();
}

/************************************************************************/
/* ˢ����ʾ                                                             */
/************************************************************************/
void GameCtrl::Paint(CDC *dc)
{
	//��������
	winBoard.DrawBoard();

	//��������
	int stone_number=AI.GetStoneNum();

	for(int k=0;k<stone_number-1;k++){
		CPos pos=AI.GetPos(k);
		if(k%2==0){//ż��
			winBoard.DrawStoneH(pos.j,pos.i,k+1);
		}else{
			winBoard.DrawStoneW(pos.j,pos.i,k+1);
		}
	}
	if(stone_number>0){
		CPos pos=AI.GetPos(stone_number-1);
		if(k%2==0){//ż��
			winBoard.DrawStoneH(pos.j,pos.i,stone_number,true);
		}else{
			winBoard.DrawStoneW(pos.j,pos.i,stone_number,true);
		}
	}

	//��������Ļ
	winBoard.Copyto(dc);
}

/************************************************************************/
/*   ��λ                                                               */
/************************************************************************/
void GameCtrl::Reset()	//��λ
{
	static init=0;
	if(init==0)
	{
		Init();
		init=1;
	}

	AI.ReSet();
	AI.PutStone(7,7);
}

/************************************************************************/
/* ��õ�ǰstep                                                         */
/************************************************************************/
int GameCtrl::GetCurrentStep()
{
	return AI.GetCurrentStep();
}

/************************************************************************/
/* ��������Ƿ����                                                     */
/************************************************************************/
bool GameCtrl::IsGameOver()
{
	bool gameover;
	bool blackfoul;
	GetGameState(gameover,blackfoul);
	return gameover;
}
void GameCtrl::AlertGameOver()
{
	int user=GetCurrentStep();
	bool gameover;
	bool blackfoul;
	GetGameState(gameover,blackfoul);
	if(user&0x1==0){ //����
		if(gameover){
			AfxMessageBox("����Ӯ��");
		}
	}else{
		if(gameover){
			if(blackfoul){
				AfxMessageBox("������֣�");
			}else{
				AfxMessageBox("����Ӯ��");
			}
		}
	}
}
/************************************************************************/
/*   ����                                                               */
/************************************************************************/
void GameCtrl::Putone(int i,int j)
{
	AI.PutStone(i,j);
}

/************************************************************************/
/*  AIѡ������                                                          */
/************************************************************************/
void GameCtrl::AIgo()		
{
#ifdef TEST_TIME
	int start=GetTickCount();
#ifdef TEST_TIMES
	for(int i=0;i<TEST_TIMES;i++)
	{
#endif
#endif
		AI.AIgo();
#ifdef TEST_TIME
#ifdef TEST_TIMES
		AI.Back();
	}
#endif
	AI.AIgo();
	int end=GetTickCount();
	CString str;str.Format("ʱ��: %dms",end-start);
	AfxMessageBox(str);
#endif
}

/************************************************************************/
/*  ��λ���Ƿ�����                                                      */
/************************************************************************/
bool GameCtrl::IsFill(int i,int j)
{
	return AI.IsFill(i,j);
}


/************************************************************************/
/* ����ĳ������ʱ��򿪣����磺�Զ��ػ�                                 */
/************************************************************************/
bool GameCtrl::Test(int i)
{
	return viewStyle.test(i);
}


/************************************************************************/
/*  ǰ��������                                                          */
/************************************************************************/
void GameCtrl::MoveFirst()
{
	while(AI.Back());
}
void GameCtrl::MoveLast()
{
	while(AI.Forward());
}
void GameCtrl::MoveNext()
{
	AI.Forward();
}
void GameCtrl::MovePre()
{
	AI.Back();
}

/************************************************************************/
/*   ϵͳ�Զ���Ӧ���أ�Ĭ��                                             */
/************************************************************************/
bool GameCtrl::Switch(int flip)
{
	viewStyle.flip(flip);
	if(viewStyle.test(flip))
	{
		return true;
	}
	else return false;
}

/************************************************************************/
/*  ��λ����                                                            */
/************************************************************************/
void GameCtrl::Hflip()
{
	AI.Hflip();
}
void GameCtrl::Vflip()
{
	AI.Vflip();
}
void GameCtrl::Rotate()
{
	AI.Rotate();
}


/************************************************************************/
/*  ���ر�������                                                      */
/************************************************************************/
void GameCtrl::LoadGame(const CString&  filepath)
{
	string sline("");
	ifstream infile(filepath); 	
	while(!infile.eof()){
		string str;
		infile>>str;
		sline+=str;
	}
	infile.close();
	int size=sline.size();
	//����
	AI.ReSet();
	//��������
	for(int i=0;i<size;i++){
		unsigned char pos=(unsigned char)(sline[i])-30;//��Ϊ�����ʱ��+1�����ڴ�Ҫ��1
		int i=pos/15;
		int j=pos%15;
		if(i<0 || i>14 || j<0 || j>14){
			AfxMessageBox("this file has been ruined!");
			Reset();
			return;
		}
		AI.PutStone(i,j);
	}
}

/************************************************************************/
/*  �������                                                            */
/************************************************************************/
void  GameCtrl::SaveGame(const CString&  filepath)
{
	//ȷ����׺��
	CString str=filepath.Right(4);
	if(str!=".pos"){
		str=filepath+".pos";
	}else{
		str=filepath;
	}

	//����ִ浽cline
	unsigned char cline[256];
	int stone_number=AI.GetStoneNum();
	for(int k=0;k<stone_number;k++){
		CPos line=AI.GetPos(k);
		cline[k]=(unsigned char)(line.i*15+line.j+30);//�������1��+32��Ϊ�˱���س�
	}
	cline[stone_number]=0;

	//����
	ofstream outfile(str); 	
	outfile<<cline;
	outfile.close();
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
void GameCtrl::CopyBoad(CWnd *wnd)
{
	winBoard.CopyBmptoClipboard(wnd);
}

/************************************************************************/
/* ������״̬                                                         */
/************************************************************************/
void GameCtrl::GetGameState(bool &gameover,bool &blackfoul)
{
	AI.GetGameState(gameover,blackfoul);
}