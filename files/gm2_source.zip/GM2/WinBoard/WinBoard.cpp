 #include "StdAfx.h"
#include "WinBoard.h"

#include <cassert>

using namespace std;

WinBoard winBoard;

/************************************************************************/
/*  ���캯��                                                            */
/************************************************************************/
WinBoard::WinBoard()
{
	//Ĭ�ϻ�����ź�����
	drawstyle.set(NUMERATION);
	drawstyle.set(COORDINATES);

	m_BoardRect.SetRect(0,0,15,15);

	//������ɫ
	//this->SetBackColor(RGB(252,248,252));
	this->SetBackColor(RGB(206,220,230));
	this->SetBackRimColor(RGB(240,236,240));
	this->SetBlackStoneColor(RGB(0,0,0));
	this->SetWhiteStoneColor(RGB(252,252,252));
	this->SetTextColor(RGB(0,100,100));
	//this->SetBoardColor(RGB(252,252,10));
	this->SetBoardColor(RGB(10,180,170));
	this->SetGridColor(RGB(100,100,100));
	this->SetScoreColor(RGB(220,20,40),RGB(40,20,220));
	this->SetCandidateColor(RGB(255,255,255));
}

WinBoard::~WinBoard()
{
}

/************************************************************************/
/*   ������ͼ����                                                       */
/************************************************************************/
void WinBoard::SetClient(CDC *dc,CRect *rc)
{
	m_rc=*rc;
	//�����ڴ�dc
	m_mdc.DeleteDC();
	VERIFY(m_mdc.CreateCompatibleDC(dc));
	
	//����λͼ����
	m_bmp.DeleteObject();
	VERIFY(m_bmp.CreateCompatibleBitmap(dc,m_rc.Width(),m_rc.Height()));

	m_mdc.SelectObject(m_bmp);

	//���̴�С
	m_scale=m_rc.Width()<=m_rc.Height()?m_rc.Width():m_rc.Height();
	m_boardscale=m_scale*6/7;
	m_interval=m_boardscale/14;
	m_boardscale=14*m_interval;

	//�������������������е�λ��
	m_sp=CPoint((m_rc.Width()/2-m_boardscale/2),(m_rc.Height()/2-m_boardscale/2));//���̣�0,0����λ��
	//m_sp=CPoint((m_rc.Width()/2-m_boardscale/2)*5/4,(m_rc.Height()/2-m_boardscale/2)*4/5);//���̣�0,0����λ��
}

/************************************************************************/
/*   DrawBoard ��������                                                 */
/************************************************************************/
void WinBoard::DrawBoard()
{
	assert(m_mdc.m_hDC!=NULL);
	
	//���Ʊ���
	m_mdc.SelectObject(&m_BackRimPen);
	m_mdc.SelectObject(&m_BoardBrush);
	m_mdc.Rectangle(CRect(0,0,m_rc.Width(),m_rc.Width()));
	m_mdc.SelectObject(&m_BackBrush);
	m_mdc.Rectangle(CRect(1,1,m_rc.Width()-1,m_rc.Width()-1));

	//��������
	int i;
	m_mdc.SetBkColor(m_BackColor);
	m_mdc.SetTextColor(m_TextColor);
	static string str1[15]={"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"};
	static string str2[15]={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O"};
	//ӳ������
	SetMapTras(&m_mdc,m_sp);
	// --����--
	m_mdc.SelectObject(&m_BoardPen);
	m_mdc.SelectObject(&m_BoardBrush);
	m_mdc.Rectangle(CRect(0,0,m_boardscale,m_boardscale));
	m_mdc.SelectObject(&m_GridPen);
	// --����--
	for(i=0;i<15;i++)
	{
		m_mdc.MoveTo(m_interval*i,0);
		m_mdc.LineTo(m_interval*i,m_boardscale);
		//������
		if(drawstyle.test(COORDINATES)){
			CRect rect(-10+m_interval*i,m_boardscale+10,10+m_interval*i,m_boardscale+30);
			m_mdc.DrawText(str2[i].c_str(),&rect,DT_CENTER|DT_VCENTER);
			rect.SetRect(-10+m_interval*i,-30,10+m_interval*i,-10);
			m_mdc.DrawText(str2[i].c_str(),&rect,DT_CENTER|DT_VCENTER);
		}
	}
	for(i=0;i<15;i++)
	{
		m_mdc.MoveTo(0,m_interval*i);
		m_mdc.LineTo(m_boardscale,m_interval*i);
		//������
		if(drawstyle.test(COORDINATES)){
			CRect rect(-30,-10+m_interval*i,-10,10+m_interval*i);
			m_mdc.DrawText(str1[14-i].c_str(),&rect,DT_CENTER|DT_VCENTER);
			rect.SetRect(m_boardscale+10,-10+m_interval*i,m_boardscale+30,10+m_interval*i);
			m_mdc.DrawText(str1[14-i].c_str(),&rect,DT_CENTER|DT_VCENTER);
		}
	}	
	//��λ
	m_mdc.SelectObject(&m_BlackStoneBrush);
	m_mdc.Ellipse(CRect(-2+m_interval*7,-2+m_interval*7,3+m_interval*7,3+m_interval*7));//��Ԫ
	m_mdc.Ellipse(CRect(-2+m_interval*3,-2+m_interval*3,3+m_interval*3,3+m_interval*3));
	m_mdc.Ellipse(CRect(-2+m_interval*11,-2+m_interval*11,3+m_interval*11,3+m_interval*11));
	m_mdc.Ellipse(CRect(-2+m_interval*3,-2+m_interval*11,3+m_interval*3,3+m_interval*11));
	m_mdc.Ellipse(CRect(-2+m_interval*11,-2+m_interval*3,3+m_interval*11,3+m_interval*3));
	//�ظ�ӳ��
	SetMap1to1(&m_mdc);
}

/************************************************************************/
/*    ��������                                                          */
/************************************************************************/
void WinBoard::DrawStoneH(int x,int y,int number,bool last)   //���ƺ��� �����ڲ���DrawStone����
{
	DrawStone(x,y,number,0,last);
}
void WinBoard::DrawStoneW(int x,int y,int number,bool last)   //���ư���
{
	DrawStone(x,y,number,1,last);
}
void WinBoard::DrawStone(int x,int y,int number,char user,bool last)
{
	//ӳ������
	SetMapTras(&m_mdc,m_sp);
	if(user==0){//��ʯ
		m_mdc.SelectObject(&m_BlackStoneBrush);
	}else{
		m_mdc.SelectObject(&m_WhiteStoneBrush);
	}
	CRect rect(-m_interval*4/9+x*m_interval,
		-m_interval*4/9+y*m_interval,
		m_interval*4/9+x*m_interval,
		m_interval*4/9+y*m_interval);
	m_mdc.Ellipse(&rect);
	
	CString str;
	rect.SetRect(-m_interval*3/8+x*m_interval,
		-8+y*m_interval,
		m_interval*3/8+x*m_interval,
		7+y*m_interval);
	//�������
	if(drawstyle.test(NUMERATION)){
		if(user==0){
			m_mdc.SetBkColor(m_BlackStoneColor);
			if(last){
				m_mdc.SetTextColor(RGB(255,0,0));
			}
			else m_mdc.SetTextColor(m_WhiteStoneColor);	
		}else{
			m_mdc.SetBkColor(m_WhiteStoneColor);
			if(last){
				m_mdc.SetTextColor(RGB(255,0,0));	
			}
			else m_mdc.SetTextColor(m_BlackStoneColor);	
		}
		
		str.Format("%d",number);
		m_mdc.DrawText(str,&rect,DT_CENTER|DT_VCENTER);
	}

	//�ظ�ӳ��
	SetMap1to1(&m_mdc);
}


/************************************************************************/
/*       ָ�����㴦����СԲ                                             */
/************************************************************************/
void WinBoard::DrawCycle(int i,int j,int size,COLORREF color)
{
	SetMapBoard();
	m_CandidateBrush.DeleteObject();
	m_CandidateBrush.CreateSolidBrush(color);
	m_CandidatePen.DeleteObject();
	m_CandidatePen.CreatePen(PS_SOLID,1,color);
	m_mdc.SelectObject(&m_CandidateBrush);
	m_mdc.SelectObject(&m_CandidatePen);
	m_mdc.Ellipse(CRect(-size+P(j),-size+P(i),size+1+P(j),size+1+P(i)));
	SetMap1to1();
}
/************************************************************************/
/*       ָ�����㴦д����                                               */
/************************************************************************/
void WinBoard::DrawText(int i,int j,CString text,COLORREF color)
{
	SetMapBoard();
	m_mdc.SetBkColor(m_BoardColor);
	m_mdc.SetTextColor(color);
	CRect rc(-m_interval/2+P(j),-8+P(i),m_interval/2+P(j),7+P(i));
	m_mdc.DrawText(text,&rc,DT_CENTER|DT_VCENTER);
	SetMap1to1();
}


/************************************************************************/
/*        ��������Ļ                                                    */
/************************************************************************/
void WinBoard::Copyto(CDC *dc)
{
	dc->BitBlt(m_rc.left,m_rc.top,m_rc.Width(),m_rc.Height(),&m_mdc,0,0,SRCCOPY);
}


/************************************************************************/
/*        ���Ƶ�������                                                  */
/************************************************************************/
void WinBoard::CopyBmptoClipboard(CWnd* wnd){
    wnd->OpenClipboard();  
    ::EmptyClipboard();   
    ::SetClipboardData(CF_BITMAP,m_bmp.m_hObject);   
    CloseClipboard();   	
}

/************************************************************************/
/*       ��λͼ�ϵ�����ӳ�䵽�����ϵĸ�λ                               */
/************************************************************************/
CPoint WinBoard::Coordinate(const CPoint &point)
{
	SetMapBoardX();
	CPoint p=point;
	m_mdc.DPtoLP(&p);
	SetMap1to1();
	
	//�ж����ĸ����
	int mx=(p.x+m_interval/2)/m_interval;
	int my=(p.y+m_interval/2)/m_interval;

	CPoint pnt(mx,my);
	if(m_BoardRect.PtInRect(pnt)==FALSE) pnt=CPoint(-1,-1);
	return pnt;
}


/************************************************************************/
/*      ��ɫ                                                             */
/************************************************************************/
void WinBoard::SetBackColor(COLORREF BackColor)
{
	m_BackColor=BackColor;
	m_BackBrush.DeleteObject();
	m_BackBrush.CreateSolidBrush(m_BackColor);
}
void WinBoard::SetBackRimColor(COLORREF BackRimColor)
{
	m_BackRimColor=BackRimColor;
	m_BackRimPen.DeleteObject();
	m_BackRimPen.CreatePen(PS_SOLID,1,m_BackRimColor);
}
void WinBoard::SetBoardColor(COLORREF BoardColor)
{
	m_BoardColor=BoardColor;
	m_BoardBrush.DeleteObject();
	m_BoardBrush.CreateSolidBrush(m_BoardColor);
}
void WinBoard::SetGridColor(COLORREF GridColor)
{
	m_GridColor=GridColor;
	m_GridPen.DeleteObject();
	m_GridPen.CreatePen(PS_SOLID,1,m_GridColor);
	m_BoardPen.DeleteObject();
	m_BoardPen.CreatePen(PS_SOLID,2,m_GridColor);
}
void WinBoard::SetBlackStoneColor(COLORREF BlackStoneColor)
{
	m_BlackStoneColor=BlackStoneColor;
	m_BlackStoneBrush.DeleteObject();
	m_BlackStoneBrush.CreateSolidBrush(m_BlackStoneColor);
}
void WinBoard::SetWhiteStoneColor(COLORREF WhiteStoneColor)
{
	m_WhiteStoneColor=WhiteStoneColor;
	m_WhiteStoneBrush.DeleteObject();
	m_WhiteStoneBrush.CreateSolidBrush(m_WhiteStoneColor);
}
void WinBoard::SetTextColor(COLORREF TextColor)
{
	m_TextColor=TextColor;
	m_TextPen.DeleteObject();
	m_TextPen.CreatePen(PS_SOLID,1,m_TextColor);
}
void WinBoard::SetScoreColor(COLORREF ScoreColorA,COLORREF ScoreColorB)
{
	m_ScoreColorA=ScoreColorA;
	m_ScoreColorB=ScoreColorB;
}
void WinBoard::SetCandidateColor(COLORREF CandidateColor)
{
	m_CandidateColor=CandidateColor;
	m_CandidateBrush.DeleteObject();
	m_CandidateBrush.CreateSolidBrush(m_CandidateColor);
	m_CandidatePen.DeleteObject();
	m_CandidatePen.CreatePen(PS_SOLID,1,m_CandidateColor);
}


/************************************************************************/
/*        ����ӳ��                                                      */
/************************************************************************/
void WinBoard::SetMap1to1(CDC *dc)//ԭλӳ��
{
	dc->SetMapMode(MM_ANISOTROPIC);
	dc->SetWindowExt(100,100);
	dc->SetWindowOrg(0,0);
	dc->SetViewportExt(100,100);
	dc->SetViewportOrg(0,0);
}
void WinBoard::SetMap1to1()
{
	m_mdc.SetMapMode(MM_ANISOTROPIC);
	m_mdc.SetWindowExt(100,100);
	m_mdc.SetWindowOrg(0,0);
	m_mdc.SetViewportExt(100,100);
	m_mdc.SetViewportOrg(0,0);
}
void WinBoard::SetMapTras(CDC *dc,const CPoint& pos,bool bflip)//ƽ��ӳ��
{
	dc->SetMapMode(MM_ANISOTROPIC);
	dc->SetWindowExt(100,100);
	dc->SetWindowOrg(0,0);
	if(bflip){
		dc->SetViewportExt(100,-100);
	}else{
		dc->SetViewportExt(100,100);
	}
	dc->SetViewportOrg(pos.x,pos.y);
}
void WinBoard::SetMapBoard()//
{
	m_mdc.SetMapMode(MM_ANISOTROPIC);
	m_mdc.SetWindowExt(100,100);
	m_mdc.SetWindowOrg(0,0);
	m_mdc.SetViewportExt(100,100);
	m_mdc.SetViewportOrg(m_sp.x,m_sp.y);
}
void WinBoard::SetMapBoardX()
{
	m_mdc.SetMapMode(MM_ANISOTROPIC);
	m_mdc.SetWindowExt(100,100);
	m_mdc.SetWindowOrg(0,0);
	m_mdc.SetViewportExt(100,100);
	m_mdc.SetViewportOrg(m_sp.x+m_rc.left,m_sp.y+m_rc.top);
}



